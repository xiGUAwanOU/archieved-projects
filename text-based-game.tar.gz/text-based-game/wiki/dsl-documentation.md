# DSL文档

## Component / Entity定义语言
为了方便定义游戏中的component与entity，我实现了一套很简单的用于定义类型的“语言”。使用方式如下：

```ruby
require_relative 'core/data/component'

Component.define "ExampleComponent" do
  attribute :example_string‚ string, default: "hello world"
  attribute :example_const_number, number, default: 42, readonly: true
  attribute :example_array, array(number), default: []
  attribute :example_optional_string, optional(string), default: nil
end

Component.define "AnotherComponent" do
  attribute :example_component, component(ExampleEntity), default: ExampleEntity.new(example_string: "hey there")
end
```

在上面的例子中，我们定义了两个类，一个为`ExampleComponent`，另一个为`AnotherComponent`。这两个类都会继承[`Component`](https://github.com/xiGUAwanOU/text-based-game/blob/master/src/core/data/component.rb)类，因而会自动具有`id`这个属性以及`clone`方法。一个component中可以包含若干个attributes，它们可以通过`attribute`这个方法来定义，方法一共有四个参数：

1. name规定了这个attribute的名称；
2. type规定了attribute的类型，可选的类型有：`string, number, bool, array(), component(), optional()`，其中带括号的类型必须与其它的类型组合；
3. default规定了attribute默认的值，这个值可以在初始化时覆盖，下面的例子中会详细阐明；
4. readonly规定了attribute是否为只读，若是，则类中不会有这个attribute的writer。

上面的两个类的使用方法大致如下：

```ruby
component1 = ExampleComponent.new(example_const_number: 1)
puts component1.example_const_number
# 1
```

这个例子说明了3点：

1. 我们可以通过标准的ruby语法来创建一个`ExampleComponent`类的对象；
2. 在`ExampleComponent`类的`new`方法中，我们可以对类中的attributes进行初始化，哪怕这个attribute是readonly的；
3. 我们可以通过`<component_object>.<attribute_name>`的方式来获取attribute的值。

我们当然也可以设置attribute的值：

```ruby
component1.example_string = "hello BOE"
puts component1.example_string
# hello BOE
component1.example_const_number = 256
# Error, because example_const_number is readonly!
component1.example_string = 42
# Ok, because type validation happens later.
```

这个例子说明了3点：

1. 我们可以通过`<component_object>.<attribute_name> = <value>`的方式来给attribute赋值；
2. 我们不可以给一个只读的attribute赋值；
3. 可以给attribute一个不是它的数据类型的值。

前面两点比较好理解。至于3.，这样做的原因是Ruby并不是一个强类型语言，在运行时每次赋值都检查值的类型会对整个系统的性能造成很大的影响。所以在定义component时给出的type其实是一个“软限制”，它只是一个meta data。当我们要把这个component保存到data pool里面的时候，那里我们会做类型相关的检查。下面的篇幅会提到这一点。

## Quest定义语言
为了尽可能地限制定义quest时会对整个游戏系统造成的影响，故决定使用不含有任何逻辑的JSON形式来定义quest。

它的定义如下：

```text
QuestDefinition ::=
{
  "id": <QuestId: integer>,
  "startCondition": <ConditionDefinition: object>,
  "globalModifiers": <[ModifierDefinition]: object*>,
  "completionCondition": <ConditionDefinition: object>,
  "questResults": <[QuestResult]: object*>
}

ConditionDefinition ::=
{
  "triggerEvent": {
    "type": <EventType: string>,
    *<EventAttributes: object>
  },
  "statePredicates": <[StatePredicate]: object*>
}

ModifierDefinition ::=
{
  "type": <ModifierType: string>,
  *<ModifierAttributes: object>
}

QuestResult ::=
{
  "type": <QuestResultType: string>,
  *<QuestResultAttributes: object>
}
```

下面是一个具体的JSON例子：

```json
{
  "id": 1,

  "startCondition": {
    "triggerEvent": {
      "type": "LocationReachedEvent",
      "locationId": 1
    },
    "statePredicates": [
      {
        "type": "HasItem",
        "itemId": 1,
        "itemAmount": 1
      },
      {
        "type": "QuestCompleted",
        "questId": 1
      }
    ]
  },

  "globalModifiers": [
    {
      "type": "ChangeNpcDialogTree",
      "npcId": 1,
      "dialogTreeId": 1,
      "override": false
    },
    {
      "type": "SpawnNpc",
      "npcId": 2,
      "locationId": 2
    }
  ],

  "completeCondition": {
    "triggerEvent": {
      "type": "DialogTreeChosenEvent",
      "npcId": 1,
      "dialogTreeId": 1
    },
    "statePredicates": [
      {
        "type": "HasItem",
        "itemId": 13,
        "itemAmount": 10
      },
      {
        "type": "NpcKilled",
        "npcId": 2
      }
    ]
  },

  "questResults": [
    {
      "type": "GiveItem",
      "itemId": 3,
      "itemAmount": 100
    },
    {
      "type": "GiveItem",
      "itemId": 42,
      "itemAmount": 1
    },
    {
      "type": "TakeItem",
      "itemId": 13,
      "itemAmount": 10
    }
  ]
}
```

## 公用的JSON数据结构

```text
StatePredicate ::=
{
  "type": <PredicateType: string>,
  *<PredicateAttributesL object>
}
```
