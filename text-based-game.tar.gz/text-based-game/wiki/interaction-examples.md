# Interaction Examples

## 基本的几个命令

```
[Global Actions] 1. Move 2. Look
> Look
[Location Introduction] This is the backyard of Whatever Magical School.
[Look List] 1. Master 2. Tree 3. Magical Well 4. Back
> Magical Well
[Look Information] This is just another magical well, same as many others in the magical school.
[Local Actions] 1. Back
> Back
[Location Introduction] This is the backyard of Whatever Magical School.
[Look List] 1. Master 2. Tree 3. Magical Well 4. Back
> Master
[Look Information] Whoever is one of the masters in Whatever Magical School.
[Local Actions] 1. Talk 2. Back
> Talk
[Dialog Content] Master: Hello, bla bla ...
[Dialog Actions] 1. Continue
> Continue
[Dialog Content] Master: So, what do you think?
[Dialog Actions] 1. I'm all OK! 2. Please tell me.
> Please tell me.
[Dialog Content] Master: Ok, let me tell you once again ...
[Dialog Actions] 1. Continue
> Continue
[Dialog Content] I: I got it ...
[Dialog Actions] 1. Continue
> Continue
[Dialog Content] Master: Goodbye then.
[Dialog Actions] 1. Continue
> Continue
[Dialog Content] I: Goodbye Master Whoever.
[Dialog Actions] 1. Continue
[Look Information] Whoever is one of the masters in Whatever Magical School.
[Local Actions] 1. Talk 2. Back
> Back
[Location Introduction] This is the backyard of Whatever Magical School.
[Look List] 1. Master 2. Tree 3. Magical Well 4. Back
> Back
[Global Actions] 1. Move 2. Look
> Move
[Localtion List] 1. Magical School Main Building
> Magical School Main Building
[Global Actions] 1. Move 2. Look
```

## 购买物品

```
[Look Information] A man selling drinks stands in front of you.
[Local Actions] 1. Buy 2. Back
> Buy
[Dialog Content] Drink seller: What do you want?
[Trade Items] 1. Cola (2) 2. Sprite (2) 3. Fanta (2) 4. Orange Juice (1.5) 5. Apple Juice (1.5)
> Cola
[Dialog Content] Drink seller: How many do you want?
> aaa
[Dialog Content] Drink seller: I said, how many do you want?
> 2
[Dialog Content] Drink seller: 2 bottles of cola for 4 euro, is it OK?
[Trade Confirmation] 1. Ok 2. Wait I changed my mind
> Ok
[Dialog Content] Here you are! Anything else?
[Local Actions] 1. Buy 2. Back
> Back
[Dialog Content] Goodbye!
```

## 全局命令插入流程中

```
[Dialog Content] Merchant: So, I hope you have enough Apple Juice ...
[Dialog Actions] 1. <Show 2 bottles of Apple Juice to the merchant> 2. I don't have any of them.
> Items
[Item List]
  1. Apple Juice x 4
  2. Orange Juice x 2
> I don't have any of them.
[Dialog Content] Merchant: Well, why your bag looks so heavy, like it is full of bottles ...
```

## 施舍（与任务无关的物品交换）

```
[Dialog Content] Begger: Please, spare me some coins ...
[Dialog Actions] 1. <Give him 1 coin> 2. <Go away>
> <Give him 1 coin>
```
