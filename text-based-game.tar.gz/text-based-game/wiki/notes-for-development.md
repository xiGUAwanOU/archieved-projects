# 开发注意事项

## 开发环境配置

开发这个工程需要`ruby`、`gem`与`bundler`三个工具，安装这些工具的教程略。请参考官方网站上的文档进行安装。

为了初始化开发环境，请运行以下命令：

```
$ bundle install
```

## 获取最新代码（重要！！）

请**务必**使用以下的git命令获取最新开发进度：

```
$ git pull --rebase
```

## Push之前的检查

在push之前，可以考虑运行以下命令进行单元测试与代码风格检查：

```
$ rake test
```

## 杂项

建议安装的Atom插件：
* linter
* linter-rubocop
* rubocop-auto-correct

## 代码风格指南

### 单元测试的辅助类

单元测试中的辅助类应当放在该测试文件中相应的module中。例如：

```ruby
module TypedAttributeClassBuilderSpec
  class DummyClass
    def initialize(id:)
      @id = id
    end

    attr_reader :id
  end
end
```
