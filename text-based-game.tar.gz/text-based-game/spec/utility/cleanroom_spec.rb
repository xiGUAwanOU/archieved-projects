require_relative "../../src/utility/cleanroom"

module CleanroomSpec
  class DslHandlerClass
    include Cleanroom

    def initialize
      @secret_attr = 42
    end

    def exposed_method
      return "hello world"
    end

    def secret_method
      return "password"
    end

    expose :exposed_method
  end
end

RSpec.describe "Cleanroom" do
  it "protects the instance from exposing the secret data" do
    expect(CleanroomSpec::DslHandlerClass.new.evaluate{ @secret_attr }).to be nil
    expect{ CleanroomSpec::DslHandlerClass.new.evaluate{ puts(secret_method) } }.to raise_error(NameError)
    expect{ CleanroomSpec::DslHandlerClass.new.evaluate{ __instance__.secret_method } }.to raise_error(NoMethodError)
  end

  it "allows valid usage" do
    expect(CleanroomSpec::DslHandlerClass.new.evaluate{ exposed_method }).to eq "hello world"
  end
end
