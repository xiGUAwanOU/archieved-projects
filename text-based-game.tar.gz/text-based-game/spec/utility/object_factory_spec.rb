require_relative "../../src/utility/object_factory"

module ObjectFactorySpec
  PROTOTYPE_NAME = "DummyClass".freeze
  ANOTHER_PROTOTYPE_NAME = "AnotherDummyClass".freeze
  USER_ID = "just another user ID".freeze
  ANOTHER_USER_ID = "yet another user ID".freeze
  VALUE = "Hello world".freeze

  class DummyClass
    def initialize(value)
      @value = value
    end

    attr_reader :value
  end
end

RSpec.describe "ObjectFactory" do
  after(:each) do
    Singleton.__init__(ObjectFactory)
  end

  it "always builds different instance-scoped object from prototype" do
    ObjectFactory.instance.define ObjectFactorySpec::PROTOTYPE_NAME, Scope::INSTANCE do
      return ObjectFactorySpec::DummyClass.new(ObjectFactorySpec::VALUE)
    end

    object1 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)
    object2 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)

    expect(object1.value).to(eq(ObjectFactorySpec::VALUE))
    expect(object1).not_to(be(object2))
  end

  it "always builds identical singleton-scoped objects" do
    ObjectFactory.instance.define ObjectFactorySpec::PROTOTYPE_NAME, Scope::SINGLETON do
      return ObjectFactorySpec::DummyClass.new(ObjectFactorySpec::VALUE)
    end

    object1 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)
    object2 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::ANOTHER_USER_ID)

    expect(object1).to(be(object2))
  end

  it "builds identical user-scoped objects with same user_id" do
    ObjectFactory.instance.define ObjectFactorySpec::PROTOTYPE_NAME, Scope::USER do
      return ObjectFactorySpec::DummyClass.new(ObjectFactorySpec::VALUE)
    end

    object1 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)
    object2 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)

    expect(object1).to(be(object2))
  end

  it "builds different user-scoped objects with different user_id" do
    ObjectFactory.instance.define ObjectFactorySpec::PROTOTYPE_NAME, Scope::USER do
      return ObjectFactorySpec::DummyClass.new(ObjectFactorySpec::VALUE)
    end

    object1 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)
    object2 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::ANOTHER_USER_ID)

    expect(object1).not_to(be(object2))
  end

  it "builds object with dependency" do
    ObjectFactory.instance.define ObjectFactorySpec::PROTOTYPE_NAME, Scope::USER do |user_id|
      return ObjectFactorySpec::DummyClass
          .new(ObjectFactory.instance.build(ObjectFactorySpec::ANOTHER_PROTOTYPE_NAME, user_id))
    end

    ObjectFactory.instance.define ObjectFactorySpec::ANOTHER_PROTOTYPE_NAME, Scope::USER do
      return ObjectFactorySpec::DummyClass.new(ObjectFactorySpec::VALUE)
    end

    object1 = ObjectFactory.instance.build(ObjectFactorySpec::PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)
    object2 = ObjectFactory.instance.build(ObjectFactorySpec::ANOTHER_PROTOTYPE_NAME, ObjectFactorySpec::USER_ID)

    expect(object1.value).to(be(object2))
  end
end
