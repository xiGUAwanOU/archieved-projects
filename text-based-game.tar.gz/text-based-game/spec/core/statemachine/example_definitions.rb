require "core/statemachine/state_machine_class"

StateMachineClass.define "StateMachineA" do
  states :state_a, :exit_a, :exit_b
  start_state :state_a
  final_states :exit_a, :exit_b

  transition :state_a, :exit_a do
    condition do |_context, input|
      return input == "a"
    end

    output do |interactor|
      interactor << "output a"
    end
  end

  transition :state_a, :exit_b do
    condition do |_context, input|
      return input == "b"
    end

    output do |interactor|
      interactor << "output b"
    end
  end
end

StateMachineClass.define "StateMachineB" do
  states :state_a, StateMachineA, :exit
  start_state :state_a
  final_states :exit

  transition :state_a, StateMachineA do
    condition do |_context, input|
      return input == "sub"
    end
  end

  transition StateMachineA, :state_a

  transition :state_a, :exit do
    condition do |_context, input|
      return input == "exit"
    end
  end
end
