require "core/statemachine/state_machine"
require_relative "./example_definitions"

RSpec.describe "StateMachine" do
  before :each do
    StateMachineA.class_eval do
      attr_reader :current_state, :context
    end

    StateMachineB.class_eval do
      attr_reader :current_state, :context
    end

    @state_machine_a = StateMachineA.new
    @state_machine_b = StateMachineB.new
  end

  it "is in reset state after initialized" do
    expect(@state_machine_a.current_state).to be(:state_a)
    expect(@state_machine_a.finished?).to be false
  end

  it "resets the state machine to the initial configuration with given context" do
    @state_machine_a.handle("a")
    expect(@state_machine_a.current_state).to be(:exit_a)
    expect(@state_machine_a.context).to be_empty

    @state_machine_a.reset(name: "John Doe", id: 42)
    expect(@state_machine_a.current_state).to be(:state_a)
    expect(@state_machine_a.finished?).to be false
    expect(@state_machine_a.context).to eq(name: "John Doe", id: 42)
  end

  it "handles input when the current state is normal state" do
    @state_machine_a.handle("a")
    expect(@state_machine_a.current_state).to be(:exit_a)

    @state_machine_a.reset

    @state_machine_a.handle("b")
    expect(@state_machine_a.current_state).to be(:exit_b)

    @state_machine_b.handle("sub")
    expect(@state_machine_b.current_state).to be StateMachineA
  end

  it "is finished when the current state is a final state" do
    @state_machine_a.handle("a")
    expect(@state_machine_a.current_state).to be(:exit_a)
    expect(@state_machine_a.finished?).to be true
  end

  it "forwards input to sub state machine and continues when the sub state machine is finished" do
    @state_machine_b.handle("sub")
    @state_machine_b.handle("a")
    expect(@state_machine_b.current_state).to be(:state_a)
  end
end
