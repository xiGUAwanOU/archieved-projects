require "core/statemachine/state_machine_class"
require_relative "./example_definitions"

RSpec.describe "StateMachineClass" do
  before :each do
    @state_machine_a = StateMachineA.new
  end

  it "builds a class with specific name and it inherits StateMachine class" do
    expect(StateMachineA).to be < StateMachine
  end

  it "builds a class with specified methods" do
    expect(@state_machine_a.methods).to include(:start_state, :final_states, :transitions)
  end

  it "builds a class with correct start_state method" do
    expect(@state_machine_a.start_state).to be :state_a
  end

  it "builds a class with correct final_states method" do
    expect(@state_machine_a.final_states).to eq [:exit_a, :exit_b]
  end

  describe "has a transition builder, which" do
    before :each do
      @transitions = @state_machine_a.transitions(:state_a)
    end

    it "builds correct number of transitions" do
      expect(@transitions.length).to be 2
    end

    it "builds correct test method" do
      expect(@transitions.first.test(nil, "a")).to be true
      expect(@transitions.first.test(nil, "b")).to be false
      expect(@transitions.last.test(nil, "b")).to be true
    end

    it "builds correct output method" do
      interactor = []
      @transitions.first.output(interactor)
      @transitions.last.output(interactor)
      expect(interactor).to eq ["output a", "output b"]
    end

    it "builds correct method returning next state" do
      expect(@transitions.first.next_state).to be :exit_a
      expect(StateMachineB.new.transitions(:state_a).first.next_state).to be StateMachineA
    end
  end
end
