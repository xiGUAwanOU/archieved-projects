require "core/text/template"

RSpec.describe "Template" do
  before :each do
    template_definitions = {
      player_reached_location: "Player <%= @player_name %> has reached <%= @location_name %>.",
      saw_object: "你看到了<%= @object_name %>。"
    }
    @template = Template.new(template_definitions)
    @template.add_localizations(a_dog: "一只狗")
    @template.add_common_substitutes(player_name: "John Doe")
  end

  it "builds text with substituted content" do
    text = @template.build_text(:player_reached_location, location_name: "Citadel")
    expect(text).to eq "Player John Doe has reached Citadel."
  end

  it "builds text with correct localization" do
    text = @template.build_text(:saw_object, object_name: :a_dog)
    expect(text).to eq "你看到了一只狗。"
  end
end
