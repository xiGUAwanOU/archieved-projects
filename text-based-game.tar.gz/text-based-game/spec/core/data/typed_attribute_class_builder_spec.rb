require "core/data/typed_attribute_class_builder"
require "core/data/type"

module TypedAttributeClassBuilderSpec
  class DummyClass
    def initialize(id:)
      @id = id
    end

    attr_reader :id
  end
end

RSpec.describe "TypedAttributeClassBuilder" do
  before :each do
    @class_builder = TypedAttributeClassBuilder.new(TypedAttributeClassBuilderSpec::DummyClass)
    @class_builder.add_typed_attribute(:string_attr, Type.string, default: "hello world")
    @class_builder.add_typed_attribute(:number_attr, Type.number, default: 42, readonly: true)
    @new_class = @class_builder.build
    @new_object = @new_class.new(id: 42)
  end

  it "builds a class with specified attributes" do
    expect(@new_object.instance_variables).to include(:@string_attr, :@number_attr)
  end

  it "builds a class with default values" do
    expect(@new_object.string_attr).to eq "hello world"
  end

  it "builds a class with readers and accessors for attributes" do
    expect(@new_object.methods).to include(:string_attr, :string_attr=, :number_attr)
    expect(@new_object.methods).not_to include(:number_attr=)
  end

  it "builds a class with a specified parent class" do
    expect(@new_object).to be_kind_of(TypedAttributeClassBuilderSpec::DummyClass)
  end

  it "builds a class that initialize the attributes with specified values" do
    another_object = @new_class.new(id: 42, string_attr: "hey there")

    expect(another_object.id).to be 42
    expect(another_object.string_attr).to eq "hey there"
  end

  it "builds a class that provides correct type info" do
    expect(@new_object.type_info).to eq(string_attr: [[String]], number_attr: [[Numeric]])
  end
end
