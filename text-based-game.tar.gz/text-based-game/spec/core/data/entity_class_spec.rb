require "core/data/entity_class"
require_relative "./example_definitions"

RSpec.describe "EntityClass" do
  it "raises error for invalid component name" do
    expect{
      EntityClass.define "ErrorEntity" do
        component "ComponentA", ComponentA
      end
    }.to(raise_error(TypeError).with_message("Component name must be a symbol"))
  end

  it "builds a class with specific name and it inherits Entity class" do
    expect(EntityA).to be < Entity
  end

  it "builds a class with correct default values" do
    expect(EntityA.new.component_a.array_attr).to eq [42]
    expect(EntityA.new.component_b.component_attr.array_attr).to eq [1]
  end

  it "builds a class with all components being readonly" do
    expect(EntityA.methods).not_to include(:component_a=, :componentB=)
  end
end
