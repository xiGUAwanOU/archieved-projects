require "core/data/component_class"
require "core/data/entity_class"

ComponentClass.define "ComponentA" do
  attribute :string_attr, string, default: "hello world"
  attribute :array_attr, array(number), default: []
  attribute :number_attr, number, default: 42, readonly: true
end

ComponentClass.define "ComponentB" do
  attribute :component_attr, component(ComponentA), default: ComponentA.new(array_attr: [1])
end

EntityClass.define "EntityA" do
  component :component_a, ComponentA, default: ComponentA.new(array_attr: [42])
  component :component_b, ComponentB
end
