require "core/data/data_pool"
require_relative "./example_definitions"

module DataPoolSpec
  class CollectionMock
    def initialize
      @upsert_component_calls = []
      @remove_component_calls = []
      @find_components_calls = []
      @find_components_result = []
    end

    attr_reader :upsert_component_calls, :remove_component_calls, :find_components_calls
    attr_writer :find_components_result

    def upsert_component(component)
      @upsert_component_calls << component
    end

    def remove_component(component)
      @remove_component_calls << component
    end

    def find_components(query)
      @find_components_calls << query
      return @find_components_result
    end
  end
end

RSpec.describe "DataPool" do
  before :each do
    @data_pool = DataPool.new
    @collection_mock_a = DataPoolSpec::CollectionMock.new
    @collection_mock_b = DataPoolSpec::CollectionMock.new
    @data_pool.add_collection(ComponentA, @collection_mock_a)
    @data_pool.add_collection(ComponentB, @collection_mock_b)

    @entity = EntityA.new
  end

  it "upserts an entity" do
    upserted_entity = @data_pool.upsert_entity(@entity)

    expect(upserted_entity).to be @entity

    expect(@collection_mock_a.upsert_component_calls.length).to be 1
    expect(@collection_mock_a.upsert_component_calls.first).to be @entity.component_a
    expect(@collection_mock_b.upsert_component_calls.length).to be 1
    expect(@collection_mock_b.upsert_component_calls.first).to be @entity.component_b
  end

  it "removes an entity" do
    upserted_entity = @data_pool.upsert_entity(@entity)
    removed_entity = @data_pool.remove_entity(@entity)

    expect(removed_entity).to be upserted_entity

    expect(@collection_mock_a.remove_component_calls.length).to be 1
    expect(@collection_mock_a.remove_component_calls.first).to be @entity.component_a
    expect(@collection_mock_b.remove_component_calls.length).to be 1
    expect(@collection_mock_b.remove_component_calls.first).to be @entity.component_b
  end

  it "finds correct entity by specifying match_all parameter" do
    @data_pool.upsert_entity(@entity)
    @collection_mock_a.find_components_result = [@entity.component_a]

    found_entities = @data_pool.find_entities(match_all: { ComponentA => [:query_name] })

    expect(found_entities.length).to be 1
    expect(found_entities.first.id).to eq @entity.id
    expect(found_entities.first).not_to be @entity
    expect(@collection_mock_a.find_components_calls.length).to be 1
    expect(@collection_mock_a.find_components_calls.first).to eq [:query_name]
  end

  it "returns empty array by specifying match_all parameter" do
    @data_pool.upsert_entity(@entity)
    @collection_mock_a.find_components_result = [@entity.component_a]

    found_entities = @data_pool
      .find_entities(match_all: { ComponentA => [:query_name], ComponentB => [:query_name] })

    expect(found_entities).to eq []
    expect(@collection_mock_a.find_components_calls.length).to be 1
    expect(@collection_mock_a.find_components_calls.first).to eq [:query_name]
    expect(@collection_mock_b.find_components_calls.length).to be 1
    expect(@collection_mock_b.find_components_calls.first).to eq [:query_name]
  end

  it "finds correct entity by specifying match_any parameter" do
    @data_pool.upsert_entity(@entity)
    @collection_mock_a.find_components_result = [@entity.component_a]

    found_entities = @data_pool
      .find_entities(match_any: { ComponentA => [:query_name], ComponentB => [:query_name] })

    expect(found_entities.length).to be 1
    expect(found_entities.first.id).to eq @entity.id
    expect(found_entities.first).not_to be @entity
    expect(@collection_mock_a.find_components_calls.length).to be 1
    expect(@collection_mock_a.find_components_calls.first).to eq [:query_name]
    expect(@collection_mock_b.find_components_calls.length).to be 1
    expect(@collection_mock_b.find_components_calls.first).to eq [:query_name]
  end

  it "returns empty array by specifying match_any parameter" do
    @data_pool.upsert_entity(@entity)
    @collection_mock_a.find_components_result = [@entity.component_a]

    found_entities = @data_pool.find_entities(match_any: { ComponentB => [:query_name] })

    expect(found_entities).to eq []
    expect(@collection_mock_b.find_components_calls.length).to be 1
    expect(@collection_mock_b.find_components_calls.first).to eq [:query_name]
  end
end
