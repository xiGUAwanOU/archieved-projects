require "core/data/type"

require_relative "./example_definitions"

RSpec.describe "Type" do
  it "builds correct type descriptions" do
    expect(Type.string).to eq [[String]]
    expect(Type.number).to eq [[Numeric]]
    expect(Type.array(Type.string)).to eq [[Array], [String]]
    expect(Type.array(Type.bool)).to eq [[Array], [TrueClass, FalseClass]]
    expect(Type.component(ComponentA)).to eq [[ComponentA]]
    expect(Type.array(Type.array(Type.string))).to eq [[Array], [Array], [String]]
    expect(Type.optional(Type.string)).to eq [[String, NilClass]]
    expect(Type.array(Type.optional(Type.string))).to eq [[Array], [String, NilClass]]
    expect(Type.optional(Type.array(Type.string))).to eq [[Array, NilClass], [String]]
  end

  it "raises an error putting non-component class into component method" do
    expect{ Type.component(EntityA) }.to raise_error(TypeError)
  end
end

RSpec.describe "TypeValidator" do
  it "raises error if there is type violations" do
    expect{ TypeValidator.validate(:wrong_type, 42, Type.string) }.to raise_error(TypeError)
    expect{ TypeValidator.validate(:wrong_type, [42], Type.array(Type.string)) }.to raise_error(TypeError)
    expect{ TypeValidator.validate(:wrong_type, ComponentB.new, Type.component(ComponentA)) }
      .to raise_error(TypeError)
    expect{ TypeValidator.validate(:wrong_type, [[42]], Type.array(Type.array(Type.string))) }.to raise_error(TypeError)

    component = ComponentA.new
    component.string_attr = 42
    expect{ TypeValidator.validate(:wrong_type, component, Type.component(ComponentA)) }.to raise_error(TypeError)
  end

  it "does not raise error if there is no violation" do
    TypeValidator.validate(:good_value, "hello", Type.string)
    TypeValidator.validate(:good_value, ["hello"], Type.array(Type.string))
    TypeValidator.validate(:good_value, ComponentA.new, Type.component(ComponentA))
    TypeValidator.validate(:good_value, [["hello"]], Type.array(Type.array(Type.string)))
  end
end
