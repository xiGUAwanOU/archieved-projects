require "core/data/data_pool"
require "core/data/collection"

RSpec.describe "DataPool and Collection" do
  before :each do
    @data_pool = DataPool.new
    @collection_a = Collection.new
    @collection_b = Collection.new
    @data_pool.add_collection(ComponentA, @collection_a)
    @data_pool.add_collection(ComponentB, @collection_b)

    @entity = EntityA.new

    @data_pool.upsert_entity(@entity)
  end

  it "work with each other" do
    found_entities = @data_pool.find_entities(
      match_any: {
        ComponentA => [:always_true],
        ComponentB => [:always_false]
      }
    )

    expect(found_entities.length).to be 1
    expect(found_entities.first.id).to eq @entity.id
    expect(found_entities.first).not_to be @entity
  end
end
