require "core/data/component_class"
require_relative "./example_definitions"

RSpec.describe "ComponentClass" do
  it "raises error for invalid attribute name" do
    expect{
      ComponentClass.define "ErrorComponent" do
        attribute 42, number
      end
    }.to(raise_error(TypeError).with_message("Attribute name must be a symbol"))
  end

  it "builds a class with specific name and it inherits Component class" do
    expect(ComponentA).to be < Component
  end
end
