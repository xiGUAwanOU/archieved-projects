require "core/data/game_data"

RSpec.describe "GameData" do
  it "generates a random ID" do
    game_data = GameData.new

    expect(game_data.id).to(match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/))
    expect(game_data.id).not_to(eq(GameData.new.id))
  end

  it "sets a specific ID" do
    game_data = GameData.new(id: "another ID")

    expect(game_data.id).to(eq("another ID"))
  end

  it "makes the ID immutable" do
    game_data = GameData.new
    original_id = game_data.id
    game_data.id << "something else"

    expect(game_data.id).to(eq(original_id))
  end

  it "clones itself" do
    game_data = GameData.new
    another_game_data = game_data.clone

    expect(another_game_data.id).to(eq(game_data.id))
    expect(another_game_data).not_to(be(game_data))
  end
end
