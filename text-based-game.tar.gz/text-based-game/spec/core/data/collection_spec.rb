require "core/data/collection"
require_relative "./example_definitions"

RSpec.describe "Collection" do
  before :each do
    @collection = Collection.new
    @component = ComponentA.new
    @collection.upsert_component(@component)
  end

  it "upserts and finds components correctly" do
    components_found = @collection.find_components([:always_true])

    expect(components_found.length).to be 1
    expect(components_found.first).to be @component
  end

  it "removes and finds components correctly" do
    @collection.remove_component(@component)
    components_found = @collection.find_components([:always_true])

    expect(components_found.length).to be 0
  end
end
