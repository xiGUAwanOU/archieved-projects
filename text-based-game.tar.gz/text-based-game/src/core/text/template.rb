require "erb"

class Template
  def initialize(template_definitions)
    @template_definitions = template_definitions
    @localization_definitions = {}
    @common_substitutes = {}
  end

  def add_localizations(localization_definitions)
    @localization_definitions.merge!(localization_definitions)
  end

  def add_common_substitutes(common_substitutes)
    @common_substitutes.merge!(common_substitutes)
  end

  def build_text(template_name, template_substitutes)
    context = Context.new
    context.add_substitues(@common_substitutes)
    context.add_substitues(localize_substitutes(template_substitutes))

    return ERB.new(@template_definitions[template_name]).result(context.binding_scope)
  end

  private

  def localize_substitutes(template_substitutes)
    localized_substitutes = {}
    template_substitutes.each_pair do |name, value|
      localized_substitutes[name] = @localization_definitions.has_key?(value) ? @localization_definitions[value] : value
    end

    return localized_substitutes
  end

  class Context
    def add_substitues(substitutes)
      substitutes.each_pair do |key, value|
        instance_variable_set("@#{key}", value)
      end
    end

    def binding_scope
      return binding
    end
  end
  private_constant :Context
end
