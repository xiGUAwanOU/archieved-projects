require "oj"
require "securerandom"

class GameData
  def initialize(id: nil)
    @id = id ? id : SecureRandom.uuid
  end

  def id
    return @id
  end

  def clone
    return Oj.load(Oj.dump(self))
  end
end
