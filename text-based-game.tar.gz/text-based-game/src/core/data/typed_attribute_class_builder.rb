require "oj"

class TypedAttributeClassBuilder
  def initialize(parent_class)
    @parent_class = parent_class
    @attributes = {}
  end

  def add_typed_attribute(name, type, default: nil, readonly: false)
    @attributes[name] = { type: type, default: default, readonly: readonly }
  end

  def build
    parameters = ["id:nil"]
    assignments = []
    readers = []
    accessors = []
    type_info = {}
    @attributes.each do |name, definition|
      parameters << "#{name}:nil"
      assignments << "@#{name} = #{name} ? #{name} : default_#{name}"
      readers << ":#{name}" if definition[:readonly]
      accessors << ":#{name}" unless definition[:readonly]
      type_info[name] = definition[:type]
    end

    new_class = Class.new(@parent_class)

    @attributes.each do |name, definition|
      new_class.class_eval do
        define_method(:"default_#{name}") do
          return Oj.load(Oj.dump(definition[:default]))
        end
        private :"default_#{name}"
      end
    end

    new_class.class_eval(<<~CLASS_DEFINITION, __FILE__, __LINE__ + 1)
      def initialize(#{parameters.join(",")})
        super(id: id)
        #{assignments.join(";")}
      end

      attr_accessor #{accessors.join(",")}
      attr_reader #{readers.join(",")}

      def type_info
        return #{type_info}
      end
    CLASS_DEFINITION

    return new_class
  end
end
