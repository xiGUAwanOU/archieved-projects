module Matcher
  def self.always_true(_component)
    return true
  end

  def self.always_false(_component)
    return false
  end
end
