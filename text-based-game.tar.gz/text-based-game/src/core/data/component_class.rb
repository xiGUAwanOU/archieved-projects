require "core/data/component"
require "core/data/typed_attribute_class_builder"
require "core/data/type"
require "utility/cleanroom"

module ComponentClass
  def self.define(component_class_name, &block)
    component_class_builder = ComponentClassBuilder.new
    component_class_builder.evaluate(&block)

    Object.const_set(component_class_name, component_class_builder.build)
  end

  class ComponentClassBuilder
    include Cleanroom

    def initialize
      @class_builder = TypedAttributeClassBuilder.new(Component)
    end

    def string; Type.string; end
    def number; Type.number; end
    def bool; Type.bool; end
    def array(item_class); Type.array(item_class); end
    def component(component_class); Type.component(component_class); end
    def optional(item_class); Type.optional(item_class); end

    def attribute(name, type, default: nil, readonly: false)
      raise(TypeError, "Attribute name must be a symbol") unless name.instance_of?(Symbol)
      @class_builder.add_typed_attribute(name, type, default: default, readonly: readonly)
    end

    def build
      return @class_builder.build
    end

    expose :string
    expose :number
    expose :bool
    expose :array
    expose :component
    expose :optional

    expose :attribute
  end
  private_constant :ComponentClassBuilder
end
