require "core/data/matcher"

class Collection
  def initialize
    @components = {}
  end

  def upsert_component(component)
    return @components[component.id] = component
  end

  def remove_component(component)
    return @components.delete(component.id)
  end

  def find_components(query)
    matcher, *parameters = query
    return @components.values.select{ |component| Matcher.public_send(matcher, component, *parameters) }
  end
end
