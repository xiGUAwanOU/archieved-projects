class DataPool
  def initialize
    @collections = Collections.new
    @entities = Entities.new
  end

  def add_collection(component_class, collection)
    @collections.add(component_class, collection)
  end

  def upsert_entity(entity)
    entity.type_info.each_key do |component_symbol|
      component = entity.public_send(component_symbol)
      @entities.add_entity_component(entity, component)
      @collections[component.class].upsert_component(component)
    end

    return @entities.add_entity(entity)
  end

  def remove_entity(entity)
    entity.type_info.each_key do |component_symbol|
      component = entity.public_send(component_symbol)
      @entities.remove_entity_component(entity, component)
      @collections[component.class].remove_component(component)
    end

    return @entities.remove_entity(entity)
  end

  def find_entity(id)
    return @entities.entity(id: id).clone
  end

  def find_entities(match_all: [], match_any: [])
    entities_matching_all = match_all.map{ |component_class, query|
      find_entities_by_query(component_class, query)
    }.reduce(:&) || Set.new
    entities_matching_any = match_any.map{ |component_class, query|
      find_entities_by_query(component_class, query)
    }.reduce(:|) || Set.new

    results = if !match_all.empty? && !match_any.empty?
                entities_matching_all & entities_matching_any
              elsif !match_all.empty?
                entities_matching_all
              elsif !match_any.empty?
                entities_matching_any
              else
                Set.new
              end

    return results.to_a.map(&:clone)
  end

  private

  def find_entities_by_query(component_class, query)
    return Set.new(@collections[component_class]
      .find_components(query).map{ |component| @entities.entity(component: component) })
  end

  class Entities
    def initialize
      @entities_by_id = {}
      @entities_by_component = {}
    end

    def add_entity(entity)
      return @entities_by_id[entity.id] = entity
    end

    def remove_entity(entity)
      return @entities_by_id.delete(entity.id)
    end

    def add_entity_component(entity, component)
      @entities_by_component[component.class] ||= {}
      @entities_by_component[component.class][component.id] = entity
    end

    def remove_entity_component(_entity, component)
      @entities_by_component[component.class] ||= {}
      @entities_by_component[component.class].delete(component.id)
    end

    def entity(id: nil, component: nil)
      return @entities_by_id[id] if id
      return @entities_by_component[component.class][component.id]
    end
  end
  private_constant :Entities

  class Collections
    def initialize
      @collections_by_component_class = {}
    end

    def add(component_class, collection)
      @collections_by_component_class[component_class] = collection
    end

    def [](component_class)
      unless @collections_by_component_class.has_key?(component_class)
        raise(RuntimeError, "Collection for #{component_class} does not exist")
      end
      return @collections_by_component_class[component_class]
    end
  end
  private_constant :Collections
end
