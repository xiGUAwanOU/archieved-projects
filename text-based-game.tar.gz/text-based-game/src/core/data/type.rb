require "core/data/component"

module Type
  def self.string
    return [[String]]
  end

  def self.number
    return [[Numeric]]
  end

  def self.bool
    return [[TrueClass, FalseClass]]
  end

  def self.array(item_class)
    return [[Array], *item_class]
  end

  def self.component(component_class)
    raise(TypeError, "#{component_class} must extend Component class") unless component_class < Component
    return [[component_class]]
  end

  def self.optional(item_class)
    item_class.first << NilClass unless item_class.first.include?(NilClass)
    return item_class
  end
end

module TypeValidator
  def self.validate(name, value, type)
    type_head, *type_tail = type

    unless any_kind_of?(value, type_head)
      raise(TypeError, "Type of #{name} must be #{type_head.join("|")}")
    end

    case value
    when Array
      value.each_with_index{ |item, index| validate("#{name}.#{index}", item, type_tail) }
    when Component
      value.type_info.each do |attr_name, attr_type|
        validate("#{name}.#{attr_name}", value.public_send(attr_name), attr_type)
      end
    end
  end

  private_class_method

  def self.any_kind_of?(value, classes)
    return classes.any?{ |klass| value.kind_of?(klass) }
  end
end
