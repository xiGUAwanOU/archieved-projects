require "core/data/game_data"
class Entity < GameData; end
