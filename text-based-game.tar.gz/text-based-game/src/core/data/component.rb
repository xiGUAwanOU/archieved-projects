require "core/data/game_data"
class Component < GameData; end
