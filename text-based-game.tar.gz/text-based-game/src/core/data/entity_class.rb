require "oj"

require "core/data/entity"
require "core/data/typed_attribute_class_builder"
require "core/data/type"
require "utility/cleanroom"

module EntityClass
  def self.define(entity_class_name, &block)
    entity_class_builder = EntityClassBuilder.new
    entity_class_builder.evaluate(&block)

    Object.const_set(entity_class_name, entity_class_builder.build)
  end

  class EntityClassBuilder
    include Cleanroom

    def initialize
      @class_builder = TypedAttributeClassBuilder.new(Entity)
    end

    def component(name, component_class, default: nil)
      raise(TypeError, "Component name must be a symbol") unless name.instance_of?(Symbol)
      @class_builder.add_typed_attribute(name, Type.component(component_class),
        default: default ? default : component_class.new, readonly: true)
    end

    def build
      return @class_builder.build
    end

    expose :component
  end
  private_constant :EntityClassBuilder
end
