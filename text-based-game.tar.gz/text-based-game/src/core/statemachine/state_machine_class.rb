require "core/statemachine/state_machine"
require "utility/cleanroom"

module StateMachineClass
  # rubocop:disable Style/TrivialAccessors

  def self.define(state_machine_class_name, &block)
    state_machine_class_builder = StateMachineClassBuilder.new
    state_machine_class_builder.evaluate(&block)

    Object.const_set(state_machine_class_name, state_machine_class_builder.build)
  end

  class StateMachineClassBuilder
    include Cleanroom

    def initialize
      @transitions = {}
    end

    def states(*state_list)
    end

    def start_state(state)
      @start_state = state
    end

    def final_states(*state_list)
      @final_states = state_list
    end

    def transition(current_state, next_state, &block)
      unless @transitions.has_key?(current_state)
        @transitions[current_state] = []
      end

      transition_builder = TransitionBuilder.new

      transition_builder.evaluate(&block) unless block.nil?
      transition_builder.next_state(next_state)

      @transitions[current_state] << transition_builder.build
    end

    def build
      start_state = @start_state
      final_states = @final_states
      transitions = @transitions

      new_class = Class.new(StateMachine)

      new_class.class_eval do
        define_method :start_state do
          return start_state
        end

        define_method :final_states do
          return final_states
        end

        define_method :transitions do |state|
          return transitions[state]
        end
      end

      return new_class
    end

    expose :states
    expose :start_state
    expose :final_states
    expose :transition
  end
  private_constant :StateMachineClassBuilder

  class TransitionBuilder
    include Cleanroom

    def condition(&block)
      @condition_block = block
    end

    def output(&block)
      @output_block = block
    end

    def next_state(state)
      @next_state = state
    end

    def build
      condition_block = @condition_block
      output_block = @output_block
      next_state = @next_state

      new_class = Class.new(Transition)

      unless condition_block.nil?
        new_class.class_eval do
          define_method :test, &condition_block
        end
      end

      unless output_block.nil?
        new_class.class_eval do
          define_method :output, &output_block
        end
      end

      new_class.class_eval do
        define_method :next_state do
          return next_state
        end
      end

      return new_class.new
    end

    expose :condition
    expose :output
  end
  private_constant :TransitionBuilder

  # rubocop:enable Style/TrivialAccessors
end
