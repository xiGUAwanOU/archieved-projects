class StateMachine
  def initialize
    reset
    @sub_state_machines = {}
  end

  def reset(context = {})
    @current_state = start_state
    @context = context
  end

  def handle(input)
    if @current_state.kind_of?(Class) && @current_state <= StateMachine
      forward_input(input)
    else
      handle_input(input)
    end
  end

  def finished?
    final_states.include?(@current_state)
  end

  private

  def handle_input(input)
    apply_transition(transitions(@current_state).find{ |transition| transition.test(@context, input) })
  end

  def forward_input(input)
    current_sub_state_machine = sub_state_machine(@current_state)
    current_sub_state_machine.handle(input)
    if current_sub_state_machine.finished?
      apply_transition(transitions(@current_state).first)
    end
  end

  def apply_transition(transition)
    transition.output("hello world")
    @current_state = transition.next_state
    if @current_state.kind_of?(Class) && @current_state <= StateMachine
      sub_state_machine(@current_state).reset
    end
  end

  def sub_state_machine(state)
    @sub_state_machines[state] = state.new unless @sub_state_machines.has_key?(state)
    return @sub_state_machines[state]
  end
end

class Transition
  def test(_context, _input)
    return true
  end

  def output(interactor)
  end

  def next_state
    return nil
  end
end
