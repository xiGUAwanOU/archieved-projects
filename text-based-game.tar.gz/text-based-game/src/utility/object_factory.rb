require "singleton"

class ObjectFactory
  include Singleton

  private def initialize
    @object_managers = {}
  end

  def define(name, scope, &block)
    object_provider = ObjectProvider.create(&block)

    case scope
    when Scope::SINGLETON
      @object_managers[name] = SingletonObjectManager.new(object_provider)
    when Scope::USER
      @object_managers[name] = UserObjectManager.new(object_provider)
    when Scope::INSTANCE
      @object_managers[name] = InstanceObjectManager.new(object_provider)
    end
  end

  def build(name, user_id)
    return @object_managers[name].build_object(user_id)
  end

  class ObjectProvider
    def self.create(&block)
      provider_class = Class.new do
        define_method :build, &block
      end

      return provider_class.new
    end
  end
  private_constant :ObjectProvider

  class ObjectManager
    def initialize(prototype)
      @prototype = prototype
    end

    def invoke_build_method(user_id)
      return @prototype.build(user_id) if @prototype.class.instance_method(:build).parameters.length == 1
      return @prototype.build
    end
  end
  private_constant :ObjectManager

  class SingletonObjectManager < ObjectManager
    def initialize(prototype)
      super
      @singleton_instance = nil
    end

    def build_object(user_id)
      @singleton_instance = invoke_build_method(user_id) if @singleton_instance.nil?
      return @singleton_instance
    end
  end
  private_constant :SingletonObjectManager

  class UserObjectManager < ObjectManager
    def initialize(prototype)
      super
      @instances = {}
    end

    def build_object(user_id)
      @instances[user_id] = invoke_build_method(user_id) unless @instances.include?(user_id)
      return @instances[user_id]
    end
  end
  private_constant :UserObjectManager

  class InstanceObjectManager < ObjectManager
    def initialize(prototype)
      super
    end

    def build_object(user_id)
      return invoke_build_method(user_id)
    end
  end
  private_constant :InstanceObjectManager
end

module Scope
  SINGLETON = :singleton_scope
  USER = :user_scope
  INSTANCE = :instance_scope
end
