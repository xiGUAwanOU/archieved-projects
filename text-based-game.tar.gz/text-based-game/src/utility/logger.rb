require "logger"

LOGGER = Logger.new("text-based-game.log", "monthly")
