module Cleanroom
  def self.included(base)
    base.send(:extend,  ClassMethods)
    base.send(:include, InstanceMethods)
  end

  module ClassMethods
    def expose(name)
      exposed_methods << name
    end

    def evaluate(instance, *args, &block)
      cleanroom.new(instance).instance_eval(*args, &block)
    end

    private

    def cleanroom
      exposed = exposed_methods
      parent = name || "Anonymous"

      # rubocop:disable Metrics/BlockLength
      Class.new(Object) do
        class << self
          def class_eval
            raise(NoMethodError, "undefined method `class_eval`")
          end

          def instance_eval
            raise(NoMethodError, "undefined method `instance_eval`")
          end
        end

        define_method(:initialize) do |instance|
          define_singleton_method(:__instance__) do
            unless caller.first.include?(__FILE__)
              raise(NoMethodError, "undefined method `__instance__`")
            end

            return instance
          end
        end

        exposed.each do |exposed_method|
          define_method(exposed_method) do |*args, &block|
            return __instance__.public_send(exposed_method, *args, &block)
          end
        end

        define_method(:class_eval) do
          raise Cleanroom::InaccessibleError.new(:class_eval, self)
        end

        define_method(:inspect) do
          "#<#{parent} (Cleanroom)>"
        end
        alias_method :to_s, :inspect
      end
      # rubocop:enable Metrics/BlockLength
    end

    def exposed_methods
      @exposed_methods ||= []
    end
  end

  module InstanceMethods
    def evaluate(*args, &block)
      return self.class.evaluate(self, *args, &block)
    end
  end
end
