package com.flaregames.trailTaskZihan;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestGame {
    private Game g;

    @BeforeMethod
    public void setUp() {
        g = new Game();
    }

    @Test
    public void testCompare() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_9));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_Q));
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_8));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_7));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_Q));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_J));

        Assert.assertTrue(g.compareHandPair(h1, h2) > 0);
    }

    @Test(expectedExceptions = RuntimeException.class)
    public void testCompareWithError1() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_T));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_9));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_Q));
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_8));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_7));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_Q));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_J));

        g.compareHandPair(h1, h2);
    }

    @Test(expectedExceptions = RuntimeException.class)
    public void testCompareWithError2() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_T));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_9));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_Q));
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_8));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_7));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_Q));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_J));

        g.compareHandPair(h1, h2);
    }
}
