package com.flaregames.trailTaskZihan;

import java.io.IOException;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestFileParser {
    private FileParser fp;

    @BeforeMethod
    public void setUp() {
        fp = new FileParser(this.getClass().getResource("test-input-01.txt").getPath());
    }

    @Test
    public void testParse() throws IOException, RuntimeException {
        List<Hand[]> handPairs = fp.parse();

        Assert.assertEquals(handPairs.size(), 2);
        Assert.assertEquals(handPairs.get(0)[0].toString(), "D2 ST H9 HQ D8");
        Assert.assertEquals(handPairs.get(0)[1].toString(), "S7 DQ S3 DA SJ");
        Assert.assertEquals(handPairs.get(1)[0].toString(), "S5 D7 H6 D6 SQ");
        Assert.assertEquals(handPairs.get(1)[1].toString(), "S8 H3 S9 SA SK");
    }

    @Test(expectedExceptions = IOException.class)
    public void testParseWithError() throws IOException, RuntimeException {
        fp = new FileParser("WrongPath");
        fp.parse();
    }

    @Test
    public void testParseLine() {
        Hand[] hp = fp.parseLine("D3 D5 C8 S7 SA : S8 H3 S9 SA SK");
        Assert.assertEquals(hp[0].toString(), "D3 D5 C8 S7 SA");
        Assert.assertEquals(hp[1].toString(), "S8 H3 S9 SA SK");
    }

    @Test(expectedExceptions = RuntimeException.class)
    public void testParseLineWithError1() {
        fp.parseLine("D3 D5 C8 S7 SA");
    }

    @Test(expectedExceptions = RuntimeException.class)
    public void testParseLineWithError2() {
        fp.parseLine("DZ D5 C8 S7 SA : S8 H3 S9 SA SK");
    }
    
    @Test(expectedExceptions = RuntimeException.class)
    public void testParseLineWithError3() {
        fp.parseLine("A3 D5 C8 S7 SA : S8 H3 S9 SA SK");
    }
    
    @Test(expectedExceptions = RuntimeException.class)
    public void testParseLineWithError4() {
        fp.parseLine("D10 D5 C8 S7 SA : S8 H3 S9 SA SK");
    }
}
