package com.flaregames.trailTaskZihan;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestHandsComparator {
    private HandsComparator hc;

    @BeforeMethod
    public void setUp() {
        hc = new HandsComparator();
    }

    @Test
    public void testCompare1() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_4));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_5));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_5));
        h2.add(new Card(Card.Suit.HEART, Card.Value.VALUE_8));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_T));
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_A));

        Assert.assertTrue(hc.compare(h1, h2) > 0, "Compare result: " + hc.compare(h1, h2));
    }

    @Test
    public void testCompare2() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_7));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_2));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_7));
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.HEART, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));

        Assert.assertTrue(hc.compare(h1, h2) < 0, "Compare result: " + hc.compare(h1, h2));
    }

    @Test
    public void testCompare3() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_T));
        h1.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_J));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_Q));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.HEART, Card.Value.VALUE_T));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_J));
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_K));

        Assert.assertTrue(hc.compare(h1, h2) < 0, "Compare result: " + hc.compare(h1, h2));
    }

    @Test
    public void testCompare4() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.HEART, Card.Value.VALUE_3));
        h1.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h2.add(new Card(Card.Suit.HEART, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));
        h2.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_A));

        Assert.assertTrue(hc.compare(h1, h2) < 0, "Compare result: " + hc.compare(h1, h2));
    }

    @Test
    public void testCompare5() {
        Hand h1 = new Hand();
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_4));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_5));
        h1.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        Hand h2 = new Hand();
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_A));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_K));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_Q));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_J));
        h2.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_T));

        Assert.assertTrue(hc.compare(h1, h2) == 0, "Compare result: " + hc.compare(h1, h2));
    }
}
