package com.flaregames.trailTaskZihan;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestHand {
    private Hand h;

    @BeforeMethod
    public void setUp() {
        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_A));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_T));
    }

    @Test
    public void testToString() {
        Assert.assertEquals(h.toString(), "C2 D3 H5 SA CT");
    }
}
