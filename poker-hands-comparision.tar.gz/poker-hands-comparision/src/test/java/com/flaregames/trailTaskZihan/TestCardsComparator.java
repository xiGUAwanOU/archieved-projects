package com.flaregames.trailTaskZihan;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestCardsComparator {
    private CardsComparator cc;
    private Hand h;

    @BeforeMethod
    public void setUp() {
        cc = new CardsComparator();

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_A));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_T));
    }

    @Test
    public void testCompare() {
        Assert.assertEquals(cc.compare(h.get(0), h.get(1)), -1);
    }

    @Test
    public void testSort() {
        cc.sort(h);
        Assert.assertEquals(h.get(4).getValue(), Card.Value.VALUE_A);
        Assert.assertEquals(h.get(3).getValue(), Card.Value.VALUE_T);
    }
}
