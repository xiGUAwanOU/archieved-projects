package com.flaregames.trailTaskZihan;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestCard {
    private Card c;

    @BeforeMethod
    public void setUp() {
        c = new Card(Card.Suit.HEART, Card.Value.VALUE_K);
    }

    @Test
    public void testGetScore() {
        Assert.assertEquals(c.getScore(), new Integer(13));
    }

    @Test
    public void testToString() {
        Assert.assertEquals(c.toString(), "HK");
    }

    @Test
    public void testGetSuit() {
        Assert.assertEquals(c.getSuit(), Card.Suit.HEART);
    }

    @Test
    public void testGetValue() {
        Assert.assertEquals(c.getValue(), Card.Value.VALUE_K);
    }
}
