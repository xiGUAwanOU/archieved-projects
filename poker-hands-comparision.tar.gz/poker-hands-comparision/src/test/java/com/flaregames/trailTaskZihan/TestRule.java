package com.flaregames.trailTaskZihan;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestRule {
    // TODO: Write tests for protected methods if needed.

    private Hand[] generateHands() {
        Hand[] result = new Hand[9];

        Hand h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_4));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        result[Rule.STRAIGHT_FLUSH.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_7));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_2));

        result[Rule.FOUR_OF_A_KIND.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_3));

        result[Rule.FULL_HOUSE.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_7));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_J));

        result[Rule.FLUSH.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_4));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        result[Rule.STRAIGHT.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        result[Rule.THREE_OF_A_KIND.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_3));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_6));

        result[Rule.TWO_PAIRS.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_T));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_J));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_Q));

        result[Rule.PAIR.getOrder()] = h;

        h = new Hand();
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_2));
        h.add(new Card(Card.Suit.DIAMOND, Card.Value.VALUE_5));
        h.add(new Card(Card.Suit.HEART, Card.Value.VALUE_8));
        h.add(new Card(Card.Suit.SPADE, Card.Value.VALUE_T));
        h.add(new Card(Card.Suit.CLUB, Card.Value.VALUE_A));

        result[Rule.HIGH_CARD.getOrder()] = h;

        return result;
    }

    private Hand[] hands;

    @BeforeMethod
    public void setUp() {
        hands = generateHands();
    }

    @Test(dataProvider = "dataMatch")
    public void testMatch(Rule r, Integer rank1, Integer rank2, Integer rank3, String appliedRule) {
        for (int i = 0; i < hands.length; i++) {
            Rule.MatchResult result = r.match(hands[i]);

            if (r.getOrder() == i) {
                Assert.assertTrue(result.isMatch());
                Assert.assertEquals(rank1, result.getRank1());
                Assert.assertEquals(rank2, result.getRank2());
                Assert.assertEquals(rank3, result.getRank3());
                Assert.assertEquals(hands[i].getAppliedRule(), appliedRule);
            } else {
                Assert.assertFalse(result.isMatch(), "Current order: " + i);
            }
        }
    }

    @DataProvider
    public Object[][] dataMatch() {
        return new Object[][] {
                { Rule.STRAIGHT_FLUSH, null, null, null, "Straight Flush" },
                { Rule.FOUR_OF_A_KIND, new Integer(2), null, null, "Four of a Kind" },
                { Rule.FULL_HOUSE, new Integer(2), null, null, "Full House" },
                { Rule.FLUSH, new Integer(11), null, null, "Flush" },
                { Rule.STRAIGHT, new Integer(6), null, null, "Straight" },
                { Rule.THREE_OF_A_KIND, new Integer(3), null, null, "Three of a Kind" },
                { Rule.TWO_PAIRS, new Integer(3), new Integer(2), new Integer(6), "Two Pairs" },
                { Rule.PAIR, new Integer(2), new Integer(12), null, "Pair" },
                { Rule.HIGH_CARD, new Integer(14), null, null, "High Card" }
        };
    }
}
