package com.flaregames.trailTaskZihan;

import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("The program takes one parameter as the input file path.");
            System.exit(1);
        }
        String filePath = args[0];

        FileParser fileParser = new FileParser(filePath);
        Game game = new Game();

        try {
            List<Hand[]> handPairs = fileParser.parse();

            for (Hand[] h : handPairs) {
                int result = game.compareHandPair(h[0], h[1]);

                StringBuilder sb = new StringBuilder();

                sb.append("Hand 1: ");
                sb.append(h[0].toString());
                sb.append(" - ");
                sb.append(h[0].getAppliedRule());
                sb.append("\n");

                sb.append("Hand 2: ");
                sb.append(h[1].toString());
                sb.append(" - ");
                sb.append(h[1].getAppliedRule());
                sb.append("\n");

                if (result > 0) {
                    sb.append("Hand 1 wins!");
                } else if (result < 0) {
                    sb.append("Hand 2 wins!");
                } else {
                    sb.append("Tie!");
                }

                System.out.println(sb.toString());
                System.out.println();
            }
        } catch (IOException e) {
            System.err.println("Cannot read file: " + filePath);
            System.exit(1);
        } catch (RuntimeException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }
}
