package com.flaregames.trailTaskZihan;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileParser {
    private File file;

    public FileParser(String filePath) {
        file = new File(filePath);
    }

    public List<Hand[]> parse() throws IOException, RuntimeException {
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;

        List<Hand[]> result = new ArrayList<Hand[]>();
        while ((line = br.readLine()) != null) {
            if (line.trim().equals("")) {
                continue;
            }
            Hand[] h = parseLine(line);
            result.add(h);
        }
        br.close();

        return result;
    }

    public Hand[] parseLine(String line) throws RuntimeException {
        String[] handStrings = line.split(":");
        if (handStrings.length != 2) {
            throw new RuntimeException("There must be two hands in one line: " + line);
        }

        Hand[] result = new Hand[2];
        result[0] = parseHand(handStrings[0].trim());
        result[1] = parseHand(handStrings[1].trim());

        return result;
    }

    public Hand parseHand(String handString) throws RuntimeException {
        String[] cardStrings = handString.split(" ");
        Hand result = new Hand();

        for (String cs : cardStrings) {
            if (cs.length() != 2) {
                throw new RuntimeException("Cannot parse card string: " + cs);
            }

            Card.Suit suit = null;
            for (Card.Suit s : Card.Suit.values()) {
                if (s.toString().equals(cs.substring(0, 1))) {
                    suit = s;
                    break;
                }
            }

            if (suit == null) {
                throw new RuntimeException("Cannot parse the suit of the card: " + cs);
            }

            Card.Value value = null;
            for (Card.Value v : Card.Value.values()) {
                if (v.toString().equals(cs.substring(1, 2))) {
                    value = v;
                    break;
                }
            }

            if (value == null) {
                throw new RuntimeException("Cannot parse the value of the card: " + cs);
            }

            result.add(new Card(suit, value));
        }

        return result;
    }
}
