package com.flaregames.trailTaskZihan;

public class Card {
    public enum Suit {
        CLUB("C"),
        DIAMOND("D"),
        HEART("H"),
        SPADE("S");

        private String string;

        private Suit(String string) {
            this.string = string;
        }

        @Override
        public String toString() {
            return string;
        }
    }

    public enum Value {
        VALUE_2("2", 2),
        VALUE_3("3", 3),
        VALUE_4("4", 4),
        VALUE_5("5", 5),
        VALUE_6("6", 6),
        VALUE_7("7", 7),
        VALUE_8("8", 8),
        VALUE_9("9", 9),
        VALUE_T("T", 10),
        VALUE_J("J", 11),
        VALUE_Q("Q", 12),
        VALUE_K("K", 13),
        VALUE_A("A", 14);

        private String string;
        private Integer score;

        private Value(String string, Integer score) {
            this.string = string;
            this.score = score;
        }

        @Override
        public String toString() {
            return string;
        }

        public Integer getScore() {
            return score;
        }
    }

    private Suit suit;
    private Value value;

    public Card(Suit suit, Value value) {
        this.suit = suit;
        this.value = value;
    }

    public Integer getScore() {
        return value.getScore();
    }

    @Override
    public String toString() {
        return suit.toString() + value.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (!(o instanceof Card)) {
            return false;
        }
        Card c = (Card) o;

        return c.suit == this.suit && c.value == this.value;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        switch (suit) {
        case CLUB:
            hash = 0;
            break;
        case DIAMOND:
            hash = 1;
            break;
        case HEART:
            hash = 2;
            break;
        case SPADE:
            hash = 3;
            break;
        }
        hash *= 31;
        hash += value.getScore();
        return hash;
    }

    public Suit getSuit() {
        return suit;
    }

    public Value getValue() {
        return value;
    }
}
