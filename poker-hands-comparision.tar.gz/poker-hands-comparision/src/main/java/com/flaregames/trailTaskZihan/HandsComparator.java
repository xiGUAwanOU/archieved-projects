package com.flaregames.trailTaskZihan;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HandsComparator implements Comparator<Hand> {
    private List<Rule> rules;

    public HandsComparator() {
        rules = Rule.getRules();
    }

    @Override
    public int compare(Hand h1, Hand h2) {
        Rule.MatchResult result1 = null;
        int order1 = Integer.MAX_VALUE;
        Rule.MatchResult result2 = null;
        int order2 = Integer.MAX_VALUE;

        for (Rule r : rules) {
            result1 = r.match(h1);
            if (result1.isMatch()) {
                order1 = r.getOrder();
            }

            result2 = r.match(h2);
            if (result2.isMatch()) {
                order2 = r.getOrder();
            }

            if (order1 != Integer.MAX_VALUE && order2 != Integer.MAX_VALUE) {
                break;
            }
        }

        if (order1 != order2) {
            return order2 - order1;
        }

        if (result1.getRank1() != result2.getRank1()) {
            return result1.getRank1() - result2.getRank1();
        }

        if (result1.getRank2() != result2.getRank2()) {
            return result1.getRank2() - result2.getRank2();
        }

        if (result2.getRank3() != result1.getRank3()) {
            return result1.getRank3() - result2.getRank3();
        }

        return 0;
    }

    public void sort(List<Hand> hands) {
        Collections.sort(hands, this);
    }
}
