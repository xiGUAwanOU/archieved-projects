package com.flaregames.trailTaskZihan;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public enum Rule {
    /**
     * Straight flush: 5 cards of the same suit with consecutive values. Ranked
     * by the highest card in the hand.
     */
    STRAIGHT_FLUSH(0) {
        @Override
        public MatchResult match(Hand hand) {
            if (!hasConsecutiveValues(hand)) {
                return new MatchResult(false);
            }
            if (!hasSameSuits(hand)) {
                return new MatchResult(false);
            }

            hand.setAppliedRule("Straight Flush");
            return new MatchResult(true);
        }
    },

    /**
     * Four of a kind: 4 cards with the same value. Ranked by the value of the 4
     * cards.
     */
    FOUR_OF_A_KIND(1) {
        @Override
        public MatchResult match(Hand hand) {
            List<List<Card>> cardsWithSameValue = detectSameValues(hand);
            if (cardsWithSameValue.size() != 1) {
                return new MatchResult(false);
            }
            if (cardsWithSameValue.get(0).size() != 4) {
                return new MatchResult(false);
            }

            Integer rank1 = cardsWithSameValue.get(0).get(0).getScore();

            hand.setAppliedRule("Four of a Kind");
            return new MatchResult(true, rank1);
        }
    },

    /**
     * Full House: 3 cards of the same value, with the remaining 2 cards forming
     * a pair. Ranked by the value of the 3 cards.
     */
    FULL_HOUSE(2) {
        @Override
        public MatchResult match(Hand hand) {
            List<List<Card>> cardsWithSameValue = detectSameValues(hand);

            if (cardsWithSameValue.size() != 2) {
                return new MatchResult(false);
            }
            if (cardsWithSameValue.get(0).size() != 3 && cardsWithSameValue.get(1).size() != 3) {
                return new MatchResult(false);
            }

            Integer rank1 = cardsWithSameValue.get(0).size() == 3 ? cardsWithSameValue.get(0).get(0).getScore()
                    : cardsWithSameValue.get(1).get(0).getScore();

            hand.setAppliedRule("Full House");
            return new MatchResult(true, rank1);
        }
    },

    /**
     * Flush: Hand contains 5 cards of the same suit. Hands which are both
     * flushes are ranked using the rules for High Card.
     */
    FLUSH(3) {
        @Override
        public MatchResult match(Hand hand) {
            if (hasConsecutiveValues(hand)) {
                return new MatchResult(false);
            }
            if (!hasSameSuits(hand)) {
                return new MatchResult(false);
            }

            Integer rank1 = maxRank(hand);

            hand.setAppliedRule("Flush");
            return new MatchResult(true, rank1);
        }
    },

    /**
     * Straight: Hand contains 5 cards with consecutive values. Hands which both
     * contain a straight are ranked by their highest card.
     */
    STRAIGHT(4) {
        @Override
        public MatchResult match(Hand hand) {
            if (!hasConsecutiveValues(hand)) {
                return new MatchResult(false);
            }

            if (hasSameSuits(hand)) {
                return new MatchResult(false);
            }

            Integer rank1 = maxRank(hand);

            hand.setAppliedRule("Straight");
            return new MatchResult(true, rank1);
        }
    },

    /**
     * Three of a Kind: Three of the cards in the hand have the same value.
     * Hands which both contain three of a kind are ranked by the value of the 3
     * cards
     */
    THREE_OF_A_KIND(5) {
        @Override
        public MatchResult match(Hand hand) {
            List<List<Card>> cardsWithSameValue = detectSameValues(hand);
            if (cardsWithSameValue.size() != 1) {
                return new MatchResult(false);
            }
            if (cardsWithSameValue.get(0).size() != 3) {
                return new MatchResult(false);
            }

            Integer rank1 = cardsWithSameValue.get(0).get(0).getScore();

            hand.setAppliedRule("Three of a Kind");
            return new MatchResult(true, rank1);
        }
    },

    /**
     * Two Pairs: The hand contains 2 different pairs. Hands which both contain
     * 2 pairs are ranked by the value of their highest pair. Hands with the
     * same highest pair are ranked by the value of their other pair. If these
     * values are the same the hands are ranked by the value of the remaining
     * card.
     */
    TWO_PAIRS(6) {
        @Override
        public MatchResult match(Hand hand) {
            List<List<Card>> cardsWithSameValue = detectSameValues(hand);
            if (cardsWithSameValue.size() != 2) {
                return new MatchResult(false);
            }
            if (cardsWithSameValue.get(0).size() != 2 || cardsWithSameValue.get(0).size() != 2) {
                return new MatchResult(false);
            }

            Integer rank1 = cardsWithSameValue.get(0).get(0).getScore();
            Integer rank2 = cardsWithSameValue.get(0).get(0).getScore();
            if (cardsWithSameValue.get(1).get(0).getScore() > rank1) {
                rank1 = cardsWithSameValue.get(1).get(0).getScore();
            } else {
                rank2 = cardsWithSameValue.get(1).get(0).getScore();
            }

            Integer rank3 = 0;
            for (Card c : hand) {
                if (!c.getScore().equals(rank1) && !c.getScore().equals(rank2)) {
                    rank3 = c.getScore();
                    break;
                }
            }

            hand.setAppliedRule("Two Pairs");
            return new MatchResult(true, rank1, rank2, rank3);
        }
    },

    /**
     * Pair: 2 of the 5 cards in the hand have the same value. Hands which both
     * contain a pair are ranked by the value of the cards forming the pair. If
     * these values are the same, the hands are ranked by the values of the
     * cards not forming the pair, in decreasing order.
     */
    PAIR(7) {
        @Override
        public MatchResult match(Hand hand) {
            List<List<Card>> cardsWithSameValue = detectSameValues(hand);
            if (cardsWithSameValue.size() != 1) {
                return new MatchResult(false);
            }
            if (cardsWithSameValue.get(0).size() != 2) {
                return new MatchResult(false);
            }

            Integer rank1 = cardsWithSameValue.get(0).get(0).getScore();

            Integer rank2 = 0;
            for (Card c : hand) {
                if (!c.getScore().equals(rank1) && c.getScore() > rank2) {
                    rank2 = c.getScore();
                }
            }

            hand.setAppliedRule("Pair");
            return new MatchResult(true, rank1, rank2);
        }
    },

    /**
     * High Card: Hands which do not fit any higher category are ranked by the
     * value of their highest card. If the highest cards have the same value,
     * the hands are ranked by the next highest, and so on.
     */
    HIGH_CARD(8) {
        @Override
        public MatchResult match(Hand hand) {
            if (hasConsecutiveValues(hand)) {
                return new MatchResult(false);
            }
            if (hasSameSuits(hand)) {
                return new MatchResult(false);
            }
            List<List<Card>> cardsWithSameValue = detectSameValues(hand);
            if (cardsWithSameValue.size() != 0) {
                return new MatchResult(false);
            }

            Integer rank1 = maxRank(hand);

            hand.setAppliedRule("High Card");
            return new MatchResult(true, rank1);
        }
    };

    private CardsComparator cardsComp;
    private int order;

    Rule(int order) {
        cardsComp = new CardsComparator();
        this.order = order;
    }

    public MatchResult match(Hand hand) {
        return null;
    }

    public int getOrder() {
        return order;
    }

    public static List<Rule> getRules() {
        List<Rule> rules = new ArrayList<Rule>();
        rules.addAll(Arrays.asList(values()));

        // Only for double check:
        Collections.sort(rules, new Comparator<Rule>() {
            @Override
            public int compare(Rule r1, Rule r2) {
                return r1.getOrder() - r2.getOrder();
            }
        });

        return rules;
    }

    public class MatchResult {
        private Integer rank1;
        private Integer rank2;
        private Integer rank3;
        private boolean match;

        public MatchResult(boolean match) {
            this.match = match;
            this.rank1 = null;
            this.rank2 = null;
            this.rank3 = null;
        }

        public MatchResult(boolean match, Integer rank1) {
            this.match = match;
            this.rank1 = rank1;
            this.rank2 = null;
            this.rank3 = null;
        }

        public MatchResult(boolean match, Integer rank1, Integer rank2) {
            this.match = match;
            this.rank1 = rank1;
            this.rank2 = rank2;
            this.rank3 = null;
        }

        public MatchResult(boolean match, Integer rank1, Integer rank2, Integer rank3) {
            this.match = match;
            this.rank1 = rank1;
            this.rank2 = rank2;
            this.rank3 = rank3;
        }

        public Integer getRank1() {
            return rank1;
        }

        public Integer getRank2() {
            return rank2;
        }

        public Integer getRank3() {
            return rank3;
        }

        public boolean isMatch() {
            return match;
        }
    }

    protected boolean hasSameSuits(Hand cards) {
        Card.Suit lastSuit = cards.get(0).getSuit();

        for (int i = 1; i < cards.size(); i++) {
            if (cards.get(i).getSuit() != lastSuit) {
                return false;
            }
        }

        return true;
    }

    protected boolean hasConsecutiveValues(Hand cards) {
        cardsComp.sort(cards);

        Integer lastScore = cards.get(0).getScore();

        for (int i = 1; i < cards.size(); i++) {
            if (!cards.get(i).getScore().equals(lastScore + 1)) {
                return false;
            }
            lastScore++;
        }

        return true;
    }

    protected List<List<Card>> detectSameValues(Hand cards) {
        List<List<Card>> result = new ArrayList<List<Card>>();

        cardsComp.sort(cards);
        for (int i = 0; i < cards.size() - 1; i++) {
            List<Card> sameValuedCards = new ArrayList<Card>();
            sameValuedCards.add(cards.get(i));

            int j = i + 1;
            for (; j < cards.size(); j++) {
                if (cards.get(j).getScore().equals(sameValuedCards.get(sameValuedCards.size() - 1).getScore())) {
                    sameValuedCards.add(cards.get(j));
                } else {
                    break;
                }
            }

            if (sameValuedCards.size() >= 2) {
                result.add(sameValuedCards);
                i = j - 1; // Don't forget there is still an i++
            }
        }

        return result;
    }

    protected Integer maxRank(Hand cards) {
        Integer result = new Integer(Integer.MIN_VALUE);
        for (Card c : cards) {
            if (c.getScore() > result) {
                result = c.getScore();
            }
        }

        return result;
    }
}
