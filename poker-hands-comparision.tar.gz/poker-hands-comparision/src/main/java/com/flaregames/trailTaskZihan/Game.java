package com.flaregames.trailTaskZihan;

import java.util.HashSet;
import java.util.Set;

public class Game {
    private HandsComparator handsComp;

    public Game() {
        handsComp = new HandsComparator();
    }

    public int compareHandPair(Hand h1, Hand h2) throws RuntimeException {
        validatePair(h1, h2);
        return handsComp.compare(h1, h2);
    }

    private void validatePair(Hand h1, Hand h2) throws RuntimeException {
        Set<Card> dealtCards = new HashSet<Card>();
        validateHand(h1, dealtCards);
        validateHand(h2, dealtCards);
    }

    private void validateHand(Hand h, Set<Card> dealtCards) throws RuntimeException {
        if (h.size() != 5) {
            throw new RuntimeException("There must be 5 cards in a hand: " + h.toString());
        }

        for (Card c : h) {
            if (dealtCards.contains(c)) {
                throw new RuntimeException("There are two same cards: " + c.toString());
            }
            dealtCards.add(c);
        }
    }
}
