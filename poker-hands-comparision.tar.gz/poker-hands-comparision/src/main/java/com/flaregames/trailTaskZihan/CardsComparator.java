package com.flaregames.trailTaskZihan;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CardsComparator implements Comparator<Card> {
    @Override
    public int compare(Card c1, Card c2) {
        return c1.getScore() - c2.getScore();
    }

    public void sort(List<Card> cards) {
        Collections.sort(cards, this);
    }
}
