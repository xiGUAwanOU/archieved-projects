package com.flaregames.trailTaskZihan;

import java.util.ArrayList;
import java.util.List;

public class Hand extends ArrayList<Card> implements List<Card> {
    private static final long serialVersionUID = -8360347443344143538L;

    private String appliedRule;

    public Hand() {
        appliedRule = "";
    }

    public void setAppliedRule(String appliedRule) {
        this.appliedRule = appliedRule;
    }

    public String getAppliedRule() {
        return appliedRule;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (Card c : this) {
            sb.append(c.toString());
            sb.append(" ");
        }

        return sb.toString().trim();
    }
}
