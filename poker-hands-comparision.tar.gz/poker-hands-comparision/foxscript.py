# This file should be read by foxmake.
import foxmake
import random
import os

def generateTestFile(self):
    suits = ['C', 'D', 'H', 'S']
    values = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
    
    content = ''
    for i in range(0, 6):
        line = ''
        
        taken = []
        for j in range(0, 2):
            for k in range(0, 5):
                si = random.randint(0, len(suits) - 1)
                vi = random.randint(0, len(values) - 1)
                while ((si * vi) in taken):
                    si = random.randint(0, len(suits) - 1)
                    vi = random.randint(0, len(values) - 1)
                taken.append(si * vi)
                
                line += suits[si] + values[vi] + ' '
            
            line += ': '
            
        content += line[:-3] + '\n'
    
    print(content)
    
    with open('test.txt', 'w') as f:
        f.write(content)

testFile = foxmake.Task.create('testFile')
testFile.doLast(generateTestFile)


def buildAndUnpackDistZip(self):
    os.system('gradle distZip')
    os.system('unzip build/distributions/poker-hands-comparision-0.0.1.zip -d build/distributions')

distZip = foxmake.Task.create('distZip')
distZip.doLast(buildAndUnpackDistZip)


def runProgram(self):
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision test.txt')

def removeFiles(self):
    os.system('rm -rf build/distributions test.txt')

run = foxmake.Task.create('run')
run.dependsOn('distZip')
run.dependsOn('testFile')
run.doLast(runProgram)
run.doLast(removeFiles)

def runProgramFine(self):
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision test-fine.txt')

runFine = foxmake.Task.create('runFine')
runFine.dependsOn('distZip')
runFine.doLast(runProgramFine)
runFine.doLast(removeFiles)


def runProgramWithError(self):
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-02.txt')
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-03.txt')
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-04.txt')
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-05.txt')
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-06.txt')
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-07.txt')
    os.system('build/distributions/poker-hands-comparision-0.0.1/bin/poker-hands-comparision src/test/resources/com/flaregames/trailTaskZihan/test-input-ERROR.txt')

runError = foxmake.Task.create('runWithError')
runError.dependsOn('distZip')
runError.doLast(runProgramWithError)
runError.doLast(removeFiles)
