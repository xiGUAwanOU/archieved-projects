# Poker Hands Comparision

To compile this project, please run following commands:

  ```console
$ git clone https://github.com/xiGUAwanOU/poker-hands-comparision
$ cd poker-hands-comparision
$ gradle distZip
  ```

Notice, you need [Gradle](http://gradle.org/) to run the last command above.

Then you could find the distribution ZIP file under `build/distributions/` folder.

Unzip it:

  ```console
$ cd build/distributions
$ unzip poker-hands-comparision-0.0.1.zip
  ```

Write an input file in this format as `test.txt`:

  ```text
H6 H3 D7 HQ CJ : S5 S9 S6 S8 DQ
S8 CA H8 DQ D7 : S9 HQ DJ S3 H6
D2 DK H7 H4 D3 : DJ S3 HA D7 S9
SK CT D9 ST D3 : DT SA DJ D8 H4
S3 S8 HA SQ C7 : DA HT H5 D6 D7
H4 CQ D4 HA H8 : HJ D5 SJ HT S7
  ```

Notice two hands are splitted by `:` symbol, use whitespace to split different cards in a hand.

Then run the program:

  ```console
$ poker-hands-comparision-0.0.1/bin/poker-hands-comparision test.txt
  ```

The result should be like this:

  ```text
Hand 1: H3 H6 D7 CJ HQ - High Card
Hand 2: S5 S6 S8 S9 DQ - High Card
Tie!

Hand 1: D7 S8 H8 DQ CA - Pair
Hand 2: S3 H6 S9 DJ HQ - High Card
Hand 1 wins!

Hand 1: D2 D3 H4 H7 DK - High Card
Hand 2: S3 D7 S9 DJ HA - High Card
Hand 2 wins!

Hand 1: D3 D9 CT ST SK - Pair
Hand 2: H4 D8 DT DJ SA - High Card
Hand 1 wins!

Hand 1: S3 C7 S8 SQ HA - High Card
Hand 2: H5 D6 D7 HT DA - High Card
Tie!

Hand 1: H4 D4 H8 CQ HA - Pair
Hand 2: D5 S7 HT HJ SJ - Pair
Hand 2 wins!
  ```
