﻿using UnityEngine;
using System.Collections.Generic;

public class TileScrollerHelper {
    private GameManager gameManager;
    private Queue<GameObject> tilesOnScreen;

    private float worldSpeedFactor;

    public TileScrollerHelper(float worldSpeedFactor) {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        tilesOnScreen = new Queue<GameObject>();
        this.worldSpeedFactor = worldSpeedFactor;
    }

    public bool IsEmpty() {
        return tilesOnScreen.Count == 0;
    }

    public void CreateRightMostGameObject(GameObject gameObject, Vector3 position) {
        tilesOnScreen.Enqueue(GameObject.Instantiate(gameObject, position, Quaternion.identity) as GameObject);
    }

    public GameObject PeekGameObject() {
        return tilesOnScreen.Peek();
    }

    public void DestroyLeftMostGameObject() {
        GameObject.Destroy(tilesOnScreen.Dequeue());
    }

    public void UpdateTilePosition() {
        foreach (GameObject tile in tilesOnScreen) {
            tile.transform.position += Vector3.left * worldSpeedFactor * gameManager.CurrentWorldSpeed * Time.deltaTime;
        }
    }
}