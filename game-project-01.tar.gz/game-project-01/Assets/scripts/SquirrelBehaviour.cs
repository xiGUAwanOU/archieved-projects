﻿using UnityEngine;
using System.Collections;

public class SquirrelBehaviour : MonoBehaviour {
    public float gravityAcceleration;
    public float jumpSpeed;
    public float maxJumpTime;

    private float restJumpTime;
    private float currentSpeed;
    private Animator animator;
    private bool isJumpDisabled;

    void Start() {
        restJumpTime = maxJumpTime;
        currentSpeed = 0;
        animator = GetComponent<Animator>();
        isJumpDisabled = true;
    }

    void Update() {
        UpdateCurrentSpeed();
        UpdateLifting();
        UpdatePosition();
        UpdateAnimation();
    }

    void OnTriggerEnter2D(Collider2D other) {
        GameObject.Find("GameManager").GetComponent<GameManager>().OnCollision();
    }

    private void UpdateCurrentSpeed() {
        currentSpeed += gravityAcceleration * Time.deltaTime;
        if (!IsInAir()) {
            currentSpeed = 0;
        }
    }

    private void UpdateLifting() {
        if (Input.GetKey(KeyCode.Space)) {
            if (restJumpTime > 0 && !isJumpDisabled) {
                currentSpeed = jumpSpeed;
                restJumpTime -= Time.deltaTime;
            }
        } else {
            restJumpTime = maxJumpTime;
            isJumpDisabled = true;
        }
    }

    private void UpdatePosition() {
        transform.position += Vector3.up * currentSpeed * Time.deltaTime;

        if (!IsInAir()) {
            transform.position += Vector3.up * (-transform.position.y);
            isJumpDisabled = false;
        }
    }

    private void UpdateAnimation() {
        if (!IsInAir() && !animator.GetCurrentAnimatorStateInfo(0).IsName("squirrel_run")) {
            animator.Play("squirrel_run");
        } else if (IsInAir() && !animator.GetCurrentAnimatorStateInfo(0).IsName("squirrel_jump")) {
            animator.Play("squirrel_jump");
        }
    }

    private bool IsInAir() {
        return transform.position.y > 0;
    }
}
