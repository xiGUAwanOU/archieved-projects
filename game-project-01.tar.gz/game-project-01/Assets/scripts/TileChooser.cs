﻿using UnityEngine;

public class TileChooser {
    private GameObject[] sprites;

    public TileChooser(GameObject[] sprites) {
        this.sprites = sprites;
    }

    public GameObject GetRandomTile() {
        return sprites[Random.Range(0, sprites.Length)];
    }
}
