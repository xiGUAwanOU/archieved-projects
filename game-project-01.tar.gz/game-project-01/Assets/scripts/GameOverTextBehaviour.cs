﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameOverTextBehaviour : MonoBehaviour {
    private GameManager gameManager;
    private Text text;

    void Start() {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        text = GetComponent<Text>();
    }

    void Update() {
        if (gameManager.IsGameOver && !text.enabled) {
            text.enabled = true;
        } else if (!gameManager.IsGameOver && text.enabled) {
            text.enabled = false;
        }
    }
}
