﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ScoreBehaviour : MonoBehaviour {
    private GameManager gameManager;
    private Text scoreNumberText;

    void Start() {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        scoreNumberText = GetComponent<Text>();
    }

    void Update() {
        scoreNumberText.text = ((int)(gameManager.Score / 10)).ToString();
    }
}
