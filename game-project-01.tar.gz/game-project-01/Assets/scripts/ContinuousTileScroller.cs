﻿using UnityEngine;
using System.Collections.Generic;

public class ContinuousTileScroller : MonoBehaviour {
    public float worldSpeedFactor;
    public GameObject[] tileTemplates;
    public int tileAmount;
    public float leftDestroyLine;

    private float tileWidth = 0;
    private TileScrollerHelper tileScrollerHelper;

    void Start() {
        InitTileWidth();
        InitTileScrollerHelper();
    }

    void Update() {
        UpdatePosition();
        UpdateRecycledTile();
    }

    private void InitTileWidth() {
        for (int i = 0; i < tileTemplates.Length; i++) {
            float currentTileWidth = tileTemplates[i].GetComponent<SpriteRenderer>().bounds.size.x;
            if (currentTileWidth > tileWidth) {
                tileWidth = currentTileWidth;
            }
        }
    }

    private void InitTileScrollerHelper() {
        tileScrollerHelper = new TileScrollerHelper(worldSpeedFactor);
        for (int i = 0; i < tileAmount; i++) {
            tileScrollerHelper.CreateRightMostGameObject(GetRandomTile(),
                new Vector3(leftDestroyLine + i * tileWidth, transform.position.y));
        }
    }

    private void UpdatePosition() {
        tileScrollerHelper.UpdateTilePosition();
    }

    private void UpdateRecycledTile() {
        if (tileScrollerHelper.PeekGameObject().transform.position.x > leftDestroyLine) {
            return;
        }

        tileScrollerHelper.DestroyLeftMostGameObject();
        tileScrollerHelper.CreateRightMostGameObject(GetRandomTile(),
            new Vector3(
                tileScrollerHelper.PeekGameObject().transform.position.x + (tileAmount - 1) * tileWidth,
                transform.position.y
            )
        );
    }

    private GameObject GetRandomTile() {
        return tileTemplates[Random.Range(0, tileTemplates.Length)];
    }
}
