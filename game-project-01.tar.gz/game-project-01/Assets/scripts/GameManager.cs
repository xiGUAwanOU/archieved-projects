﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Collections;

public class GameManager : MonoBehaviour {
    public float initialWorldSpeed;
    public float worldAcceleration;
    public float maxWorldSpeed;

    private float currentWorldSpeed;
    private float score;
    private bool isGameOver;

    public float CurrentWorldSpeed {
        get { return currentWorldSpeed; }
    }

    public int Score {
        get { return (int)score; }
    }

    public bool IsGameOver {
        get { return isGameOver; }
    }

    public void OnCollision() {
        isGameOver = true;
        Time.timeScale = 0;
    }

    void Start() {
        currentWorldSpeed = initialWorldSpeed;
        score = 0;
        isGameOver = false;
    }

    void Update() {
        UpdateWorldSpeed();
        UpdateScore();
        UpdateGameOver();
    }

    private void UpdateWorldSpeed() {
        currentWorldSpeed += worldAcceleration * Time.deltaTime;

        if (currentWorldSpeed > maxWorldSpeed) {
            currentWorldSpeed = maxWorldSpeed;
        }
    }

    private void UpdateScore() {
        score += currentWorldSpeed * Time.deltaTime;
    }

    private void UpdateGameOver() {
        if (isGameOver) {
            if (Input.GetKeyDown(KeyCode.Space)) {
                System.Threading.Thread.Sleep(1000);
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
                Time.timeScale = 1;
            }
        }
    }
}
