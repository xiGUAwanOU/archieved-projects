﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RandomTileScroller : MonoBehaviour {
    [System.Serializable]
    public class TileGroup {
        public GameObject[] tileTemplates;
        public int minTileNum;
        public int maxTileNum;
        public float tileDistance;
        public float[] heights;

        public GameObject GetRandomTile() {
            return tileTemplates[Random.Range(0, tileTemplates.Length)];
        }

        public float GetRandomHeight() {
            return heights[Random.Range(0, heights.Length)];
        }

        public int GetRandomTileNum() {
            return Random.Range(minTileNum, maxTileNum + 1);
        }
    }

    public TileGroup[] tileGroups;

    public float worldSpeedFactor;
    public float minSpawnTime;
    public float maxSpawnTime;

    public float rightSpawnLine;
    public float leftDestroyLine;

    private float nextSpawnTime;
    private float elapsedTimeSinceLastSpawn;
    private TileScrollerHelper tileScrollerHelper;

    void Start() {
        ResetSpawnTime();
        InitTileScrollerHelper();
    }

    void Update() {
        UpdatePosition();
        UpdateRecycledTile();
        UpdateSpawnTile();
    }

    private void InitTileScrollerHelper() {
        tileScrollerHelper = new TileScrollerHelper(worldSpeedFactor);
    }

    private void UpdatePosition() {
        tileScrollerHelper.UpdateTilePosition();
    }

    private void UpdateRecycledTile() {
        if (!tileScrollerHelper.IsEmpty() && tileScrollerHelper.PeekGameObject().transform.position.x < leftDestroyLine) {
            tileScrollerHelper.DestroyLeftMostGameObject();
        }
    }

    private void UpdateSpawnTile() {
        elapsedTimeSinceLastSpawn += Time.deltaTime;
        if (elapsedTimeSinceLastSpawn < nextSpawnTime) {
            return;
        }

        ResetSpawnTime();

        TileGroup tileGroupToGenerate = tileGroups[Random.Range(0, tileGroups.Length)];
        int tileNum = tileGroupToGenerate.GetRandomTileNum();
        for (int i = 0; i < tileNum; i++) {
            tileScrollerHelper.CreateRightMostGameObject(tileGroupToGenerate.GetRandomTile(),
                new Vector3(
                    rightSpawnLine + i * tileGroupToGenerate.tileDistance,
                    tileGroupToGenerate.GetRandomHeight()
                )
            );
        }
    }

    private void ResetSpawnTime() {
        nextSpawnTime = Random.Range(minSpawnTime, maxSpawnTime);
        elapsedTimeSinceLastSpawn = 0;
    }
}
