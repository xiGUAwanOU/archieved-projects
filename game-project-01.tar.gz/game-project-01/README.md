# Game Project 01

A simple game just remaking the T-Rex game in Chrome Web Browser.
