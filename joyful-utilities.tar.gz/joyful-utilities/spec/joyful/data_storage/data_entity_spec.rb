require "joyful/data_storage/data_entity"

module Joyful
  module DataStorage
    describe DataEntity do
      describe "has `id` method that" do
        it "returns specified ID" do
          entity = DataEntity.new("some-valid-id")
          expect(entity.id).to eq("some-valid-id")
        end

        it "returns random generated ID" do
          entity_1 = DataEntity.new
          entity_2 = DataEntity.new

          expect(entity_1.id).not_to eq(entity_2.id)
          expect(entity_1.id).to match(/[0-9a-z]{8}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{12}/)
        end
      end

      describe "has `clone` method that" do
        it "clones itself" do
          entity = DataEntity.new("some-valid-id")
          cloned_entity = entity.clone

          expect(entity).not_to be(cloned_entity)
          expect(entity.id).to eq(cloned_entity.id)
        end
      end
    end
  end
end
