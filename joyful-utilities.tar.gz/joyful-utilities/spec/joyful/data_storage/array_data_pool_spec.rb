require "joyful/data_storage/array_data_pool"
require "joyful/data_storage/common_data_pool_example"

module Joyful
  module DataStorage
    describe ArrayDataPool do
      include_examples "data pool", ArrayDataPool
    end
  end
end
