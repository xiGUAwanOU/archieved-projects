require "joyful/data_storage/data_entity"

class DataEntityMock < Joyful::DataStorage::DataEntity
  def initialize(name)
    super
    @name = name
  end

  attr_accessor :name
end
