require "joyful/data_storage/id_hash_data_pool"
require "joyful/data_storage/common_data_pool_example"

module Joyful
  module DataStorage
    describe IdHashDataPool do
      include_examples "data pool", IdHashDataPool
    end
  end
end
