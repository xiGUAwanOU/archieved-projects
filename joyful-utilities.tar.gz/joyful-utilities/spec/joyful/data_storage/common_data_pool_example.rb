require "joyful/data_storage/data_entity_mock"
require "joyful/data_storage/data_entity_predicate_mock"

shared_examples "data pool" do |data_pool_class| # rubocop:disable Metrics/BlockLength
  before :each do
    @data_pool = data_pool_class.new("DataEntityMockPool")
  end

  describe "has `upsert` method that" do
    it "inserts a new entity" do
      entity = DataEntityMock.new("name")
      @data_pool.upsert(entity)

      expect(@data_pool.find_one(entity.id).name).to eq("name")
    end

    it "updates an exissting entity" do
      entity = DataEntityMock.new("name")
      @data_pool.upsert(entity)

      entity.name = "another name"
      @data_pool.upsert(entity)

      expect(@data_pool.find_one(entity.id).name).to eq("another name")
    end
  end

  describe "has `delete` method that" do
    it "removes an entity" do
      entity = DataEntityMock.new("name")
      @data_pool.upsert(entity)
      @data_pool.delete(entity.id)

      expect(@data_pool.find_one(entity.id)).to be_nil
    end
  end

  describe "has `find_one` method that" do
    it "returns the cloned entity" do
      original_entity = DataEntityMock.new("name")
      @data_pool.upsert(original_entity)

      found_entity = @data_pool.find_one(original_entity.id)
      found_entity.name = "another names"

      expect(@data_pool.find_one(original_entity.id).name).to eq("name")
    end
  end

  describe "has `find_all` method that" do
    it "returns all the entities matches the predicate" do
      @data_pool.upsert(DataEntityMock.new("name 1"))
      @data_pool.upsert(DataEntityMock.new("name 2"))
      @data_pool.upsert(DataEntityMock.new("another name"))

      found_entities = @data_pool.find_all(DataEntityPredicateMock.new, name_prefix: "name")

      expect(found_entities.map(&:name)).to contain_exactly("name 1", "name 2")
    end

    it "returns entities as clones" do
      @data_pool.upsert(DataEntityMock.new("name"))
      @data_pool.upsert(DataEntityMock.new("another name"))

      found_entities = @data_pool.find_all(DataEntityPredicateMock.new, name_prefix: "name")
      found_entities.first.name = "random name"

      expect(@data_pool.find_all(DataEntityPredicateMock.new, name_prefix: "name").map(&:name))
        .to contain_exactly("name")
    end
  end
end
