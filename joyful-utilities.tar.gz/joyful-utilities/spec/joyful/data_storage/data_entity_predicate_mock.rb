require "joyful/data_storage/data_entity_predicate"

class DataEntityPredicateMock < Joyful::DataStorage::DataEntityPredicate
  def test(data_entity_mock, parameters)
    return data_entity_mock.name.start_with?(parameters[:name_prefix])
  end
end
