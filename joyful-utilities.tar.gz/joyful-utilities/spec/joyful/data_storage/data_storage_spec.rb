require "joyful/data_storage/data_storage"
require "joyful/data_storage/array_data_pool"

module Joyful
  module DataStorage
    describe DataStorage do
      before :each do
        @data_storage = DataStorage.new
      end

      describe "has `register_data_pool` method that" do
        it "registers a data pool" do
          data_pool = ArrayDataPool.new("name")
          @data_storage.register_data_pool(data_pool)

          expect(@data_storage.data_pool("name")).to be(data_pool)
        end

        it "raises error if data pool with same name has already been registered" do
          @data_storage.register_data_pool(ArrayDataPool.new("name"))

          expect{@data_storage.register_data_pool(ArrayDataPool.new("name"))}
            .to raise_error(DataStorageError, "Data pool with name 'name' already exists")
        end
      end
    end
  end
end
