require "joyful/utilities/clone_deep"

module Joyful
  module Utilities
    describe "clone_deep" do
      it "clones object deeply with same values" do
        array = [[3]]
        expect(Joyful::Utilities.clone_deep(array)[0][0]).to be(3)
      end

      it "creates cloned object that not mutable with original one" do
        array = [[3]]
        cloned_array = Joyful::Utilities.clone_deep(array)

        array[0][0] = 2

        expect(cloned_array[0][0]).to be(3)
      end
    end
  end
end
