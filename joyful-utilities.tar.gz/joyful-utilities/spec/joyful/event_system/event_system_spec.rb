require "joyful/event_system/event_system"
require "joyful/event_system/event"
require "joyful/event_system/event_handler_mock"

module Joyful
  module EventSystem
    describe EventSystem do
      before :each do
        @event_system = EventSystem.new

        @event_handler = EventHandlerMock.new([:foo])

        @event_system.register_handler(@event_handler)
      end

      after :each do
        @event_system.stop if @event_system.started?
      end

      it "is stopped after created" do
        expect(@event_system.started?).to be(false)
      end

      describe "has `broadcast` method that" do
        it "broadcasts an event so that the event handlers can process it" do
          @event_system.broadcast(Event.new(:foo, nil))
          @event_system.process_one

          expect(@event_handler.received_events.map(&:type)).to contain_exactly(:foo)
        end
      end

      describe "has `start` method that" do
        it "starts event processing" do
          @event_system.start

          expect(@event_system.started?).to be(true)

          @event_system.broadcast(Event.new(:foo, nil))
          sleep(0.1)

          expect(@event_handler.received_events.map(&:type)).to contain_exactly(:foo)
        end

        it "starts event processing with specified sleeping time" do
          @event_system.start(0.2)

          expect(@event_system.started?).to be(true)

          @event_system.broadcast(Event.new(:not_handled_event, nil))
          @event_system.broadcast(Event.new(:foo, nil))
          sleep(0.1)

          expect(@event_handler.received_events.map(&:type)).to be_empty
        end

        it "raises error if already started" do
          @event_system.start

          expect{@event_system.start}.to raise_error(EventSystemError, "Event system has already been started")
        end
      end

      describe "has `stop` method that" do
        it "stops event processing" do
          @event_system.start
          @event_system.stop

          expect(@event_system.started?).to be(false)

          @event_system.broadcast(Event.new(:foo, nil))
          sleep(0.1)

          expect(@event_handler.received_events.map(&:type)).to be_empty
        end

        it "raises error if already stopped" do
          expect{@event_system.stop}.to raise_error(EventSystemError, "Event system is not started")
        end
      end
    end
  end
end
