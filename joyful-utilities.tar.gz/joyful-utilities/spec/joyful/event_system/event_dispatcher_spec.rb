require "joyful/event_system/event_dispatcher"
require "joyful/event_system/event"
require "joyful/event_system/event_handler_mock"

module Joyful
  module EventSystem
    describe EventDispatcher do
      before :each do
        @event_dispatcher = EventDispatcher.new

        @event_handler_1 = EventHandlerMock.new([:foo, :bar])
        @event_handler_2 = EventHandlerMock.new([:bar, :baz])

        @event_dispatcher.register_handler(@event_handler_1)
        @event_dispatcher.register_handler(@event_handler_2)
      end

      describe "has `dispatch` method that" do
        it "dispatches event to corresponding handlers" do
          @event_dispatcher.dispatch(Event.new(:foo, nil))
          @event_dispatcher.dispatch(Event.new(:bar, nil))

          expect(@event_handler_1.received_events.map(&:type)).to contain_exactly(:foo, :bar)
          expect(@event_handler_2.received_events.map(&:type)).to contain_exactly(:bar)
        end

        it "does not dispatch events to unregistered handlers" do
          @event_dispatcher.unregister_handler(@event_handler_1)

          @event_dispatcher.dispatch(Event.new(:foo, nil))
          @event_dispatcher.dispatch(Event.new(:bar, nil))

          expect(@event_handler_1.received_events.map(&:type)).to be_empty
        end

        it "does not dispatch events to garbage collected handlers" do
          mutable_received_events = []
          event_handler = EventHandlerMock.new([:foo], mutable_received_events)

          @event_dispatcher.register_handler(event_handler)

          event_handler = nil # rubocop:disable Lint/UselessAssignment
          GC.start

          @event_dispatcher.dispatch(Event.new(:new, nil))

          expect(mutable_received_events).to be_empty
        end
      end
    end
  end
end
