require "joyful/event_system/event_queue"
require "joyful/event_system/event"

module Joyful
  module EventSystem
    describe EventQueue do
      before :each do
        @event_queue = EventQueue.new
      end

      describe "has `push` method that" do
        it "pushes events in order" do
          @event_queue.push(Event.new(:foo, nil))
          @event_queue.push(Event.new(:bar, nil))

          expect(@event_queue.peek.type).to eq(:foo)
        end
      end

      describe "has `poll` method that" do
        it "removes and returns first event if available" do
          @event_queue.push(Event.new(:foo, nil))
          @event_queue.push(Event.new(:bar, nil))
          first_event = @event_queue.poll

          expect(first_event.type).to eq(:foo)
          expect(@event_queue.peek.type).to eq(:bar)
        end

        it "returns nil if queue is empty" do
          expect(@event_queue.poll).to be_nil
        end
      end

      describe "has `peek` method that" do
        it "returns nil if queue is empty" do
          expect(@event_queue.peek).to be_nil
        end
      end
    end
  end
end
