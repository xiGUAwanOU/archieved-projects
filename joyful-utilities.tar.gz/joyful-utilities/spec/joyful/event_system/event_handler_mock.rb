require "joyful/event_system/event_handler"

class EventHandlerMock < Joyful::EventSystem::EventHandler
  def initialize(handled_events, mutable_received_events = [])
    super(handled_events)
    @received_events = mutable_received_events
  end

  attr_reader :received_events

  def handle(event)
    @received_events.push(event)
  end
end
