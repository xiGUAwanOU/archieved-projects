require "joyful/finite_state_machine/sub_state_machine"
require "joyful/finite_state_machine/state_machine"
require "joyful/finite_state_machine/state_processor_mock"

module Joyful
  module FiniteStateMachine
    describe "StateMachine and SubStateMachine" do
      before :each do
        @mutable_recorder = []

        @state_processor_1 = StateProcessorMock.new(:state_1, :state_2, "message from state 1", @mutable_recorder)

        @sub_state_processor_1 =
          StateProcessorMock.new(:sub_state_1, :sub_state_2, "message from sub state 1", @mutable_recorder)
        @sub_state_processor_2 =
          StateProcessorMock.new(:sub_state_2, :sub_state_3, "message from sub state 2", @mutable_recorder)
        @sub_state_processor_3 =
          StateProcessorMock.new(:sub_state_3, :sub_state_3, "message from sub state 3", @mutable_recorder)

        @sub_state_machine = SubStateMachine.new(StateMachine.build
          .add_state(:sub_state_1, @sub_state_processor_1).start_state(:sub_state_1)
          .add_state(:sub_state_2, @sub_state_processor_2)
          .add_state(:sub_state_3, @sub_state_processor_3).final_state(:sub_state_3)
          .initial_context([])
          .do, :state_2, :state_3)

        @state_processor_3 = StateProcessorMock.new(:state_3, :state_1, "message from state 3", @mutable_recorder)

        @state_machine = StateMachine.build
          .add_state(:state_1, @state_processor_1).start_state(:state_1)
          .add_state(:state_2, @sub_state_machine)
          .add_state(:state_3, @state_processor_3).final_state(:state_3)
          .initial_context([])
          .do
      end

      it "transfers between states and sub states and calls hook methods" do
        @mutable_recorder.clear

        @state_machine.start
        @state_machine.process("state_1 -> state_2: sub_state_1")
        @state_machine.process("state_2: sub_state_1 -> state_2: sub_state_2")
        @state_machine.process("state_2: sub_state_2 -> state_2: sub_state_3 (-> state_3)")
        @state_machine.process("state_3 -> state_1")
        @state_machine.process("state_1 -> state_2: sub_state_1")
        @state_machine.process("state_2: sub_state_1 -> state_2: sub_state_2")

        hook_method_calls = @mutable_recorder.map{|record| record.select{|key, _value| [:state, :method].include?(key)}}
        expect(hook_method_calls).to eq([
          # start
          { state: :state_1, method: :on_start },
          { state: :state_3, method: :on_start },

          # state_1 -> state_2: sub_state_1
          { state: :state_1, method: :on_entry },
          { state: :state_1, method: :next },
          { state: :state_1, method: :on_exit },
          { state: :sub_state_1, method: :on_start },
          { state: :sub_state_2, method: :on_start },
          { state: :sub_state_3, method: :on_start },
          { state: :sub_state_1, method: :on_entry },

          # state_2: sub_state_1 -> state_2: sub_state_2
          { state: :sub_state_1, method: :next },
          { state: :sub_state_1, method: :on_exit },
          { state: :sub_state_2, method: :on_entry },

          # state_2: sub_state_2 -> state_2: sub_state_3 (-> state_3)
          { state: :sub_state_2, method: :next },
          { state: :sub_state_2, method: :on_exit },
          { state: :sub_state_3, method: :on_entry },
          { state: :sub_state_1, method: :on_stop },
          { state: :sub_state_2, method: :on_stop },
          { state: :sub_state_3, method: :on_stop },
          { state: :state_3, method: :on_entry },

          # state_3 -> state_1
          { state: :state_3, method: :next },
          { state: :state_3, method: :on_exit },
          { state: :state_1, method: :on_entry },

          # state_1 -> state_2: sub_state_1
          { state: :state_1, method: :next },
          { state: :state_1, method: :on_exit },
          { state: :sub_state_1, method: :on_start },
          { state: :sub_state_2, method: :on_start },
          { state: :sub_state_3, method: :on_start },
          { state: :sub_state_1, method: :on_entry },

          # state_2: sub_state_1 -> state_2: sub_state_2
          { state: :sub_state_1, method: :next },
          { state: :sub_state_1, method: :on_exit },
          { state: :sub_state_2, method: :on_entry }
        ])
      end
    end
  end
end
