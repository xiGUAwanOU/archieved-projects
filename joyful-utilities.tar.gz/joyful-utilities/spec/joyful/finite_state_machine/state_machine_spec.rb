require "joyful/finite_state_machine/state_machine"
require "joyful/finite_state_machine/state_processor_mock"

module Joyful
  module FiniteStateMachine
    describe StateMachine do
      before :each do
        @hook_method_calls = []

        @state_processor_1 = StateProcessorMock.new(:state_1, :state_2, "message from state 1", @hook_method_calls)
        @state_processor_2 = StateProcessorMock.new(:state_2, :state_1, "message from state 2", @hook_method_calls)

        @state_machine = StateMachine.build
          .add_state(:state_1, @state_processor_1).start_state(:state_1)
          .add_state(:state_2, @state_processor_2).final_state(:state_2)
          .initial_context([])
          .do
      end

      it "is stopped after created" do
        expect(@state_machine.started?).to be(false)
      end

      describe "has `start` method that" do
        it "starts from the specified start state and calls hook methods" do
          @state_machine.start

          expect(@state_machine.started?).to be(true)
          expect(@hook_method_calls[0]).to eq(state: :state_1, method: :on_start, params: {})
          expect(@hook_method_calls[1]).to eq(state: :state_2, method: :on_start, params: {})
          expect(@hook_method_calls[2]).to eq(state: :state_1, method: :on_entry, params: { context: [] })
        end

        it "raises error while being started twice" do
          @state_machine.start

          expect{@state_machine.start}.to raise_error(StateMachineError, "State machine has already been started")
        end
      end

      describe "has `process` method that" do
        it "processes input, transfers from one state to another and calls hook methods" do
          @state_machine.start
          @hook_method_calls.clear
          @state_machine.process("state_1 -> state_2")

          expect(@hook_method_calls[0])
            .to eq(state: :state_1, method: :next, params: { input: "state_1 -> state_2", context: [] })
          expect(@hook_method_calls[1])
            .to eq(state: :state_1, method: :on_exit, params: { context: ["message from state 1"] })
          expect(@hook_method_calls[2])
            .to eq(state: :state_2, method: :on_entry, params: { context: ["message from state 1"] })
        end

        it "raises error while trying to process input but not started" do
          expect{@state_machine.process("input")}
            .to raise_error(StateMachineError, "State machine is not started")
        end

        it "raises error if next state is unknown" do
          state_machine = StateMachine.build
            .add_state(:state_1, @state_processor_1).start_state(:state_1)
            .initial_context([])
            .do
          state_machine.start

          expect{state_machine.process("state_1 -> state_2")}
            .to raise_error(StateMachineError, "State 'state_2' does not exist")
        end
      end

      describe "has `stop?` method that" do
        it "stops successfully at the final state and calls hook methods" do
          @state_machine.start
          @state_machine.process("state_1 -> state_2")
          @hook_method_calls.clear
          stopped = @state_machine.stop?

          expect(stopped).to be(true)
          expect(@state_machine.started?).to be(false)
          expect(@hook_method_calls[0]).to eq(state: :state_1, method: :on_stop, params: {})
          expect(@hook_method_calls[1]).to eq(state: :state_2, method: :on_stop, params: {})
        end

        it "does not stop at non-final state and does not call hook methods" do
          @state_machine.start
          @hook_method_calls.clear
          stopped = @state_machine.stop?

          expect(stopped).to be(false)
          expect(@state_machine.started?).to be(true)
          expect(@hook_method_calls).to be_empty
        end

        it "simply returns stopped status if already stopped and does not call hook methods" do
          stopped = @state_machine.stop?

          expect(stopped).to be(true)
          expect(@state_machine.started?).to be(false)
          expect(@hook_method_calls).to be_empty
        end
      end

      describe "has `stop!` method that" do
        it "stops immediately and calls hook methods" do
          @state_machine.start
          @hook_method_calls.clear
          @state_machine.stop!

          expect(@state_machine.started?).to be(false)
          expect(@hook_method_calls[0]).to eq(state: :state_1, method: :on_stop, params: {})
          expect(@hook_method_calls[1]).to eq(state: :state_2, method: :on_stop, params: {})
        end

        it "raises error if already stopped" do
          expect{@state_machine.stop!}.to raise_error(StateMachineError, "State machine is not started")
        end
      end
    end
  end
end
