require "joyful/finite_state_machine/sub_state_machine"
require "joyful/finite_state_machine/state_processor_mock"

module Joyful
  module FiniteStateMachine
    describe SubStateMachine do
      before :each do
        @hook_method_calls = []

        @state_processor_1 = StateProcessorMock.new(:state_1, :state_2, "message from state 1", @hook_method_calls)
        @state_processor_2 = StateProcessorMock.new(:state_2, :state_3, "message from state 2", @hook_method_calls)
        @state_processor_3 = StateProcessorMock.new(:state_3, :state_3, "message from state 3", @hook_method_calls)

        @sub_state_machine = SubStateMachine.new(StateMachine.build
          .add_state(:state_1, @state_processor_1).start_state(:state_1)
          .add_state(:state_2, @state_processor_2)
          .add_state(:state_3, @state_processor_3).final_state(:state_3)
          .initial_context([])
          .do, :parent_state_1, :parent_state_2)

        @sub_state_machine.on_start
      end

      describe "has `on_entry` method that" do
        it "starts sub state machine" do
          @sub_state_machine.on_entry(["random context"])

          expect(@hook_method_calls[0]).to eq(state: :state_1, method: :on_start, params: {})
          expect(@hook_method_calls[1]).to eq(state: :state_2, method: :on_start, params: {})
          expect(@hook_method_calls[2]).to eq(state: :state_3, method: :on_start, params: {})
          expect(@hook_method_calls[3]).to eq(state: :state_1, method: :on_entry, params: { context: [] })
        end

        it "does not start sub state machine again if sub state machine is still running" do
          @sub_state_machine.on_entry(["random context"])
          @sub_state_machine.next("state_1 -> state_2", ["random context"])
          @sub_state_machine.on_exit(["random context"])
          @hook_method_calls.clear
          @sub_state_machine.on_entry(["random context"])

          expect(@hook_method_calls).to be_empty
        end

        it "restarts after re-enter its state" do
          @sub_state_machine.on_entry(["random context"])
          @sub_state_machine.next("state_1 -> state_2", ["random context"])
          @sub_state_machine.on_exit(["random context"])
          @sub_state_machine.on_entry(["random context"])
          @sub_state_machine.next("state_2 -> state_3", ["random context"])
          @sub_state_machine.on_exit(["random context"])
          @hook_method_calls.clear
          @sub_state_machine.on_entry(["random context"])

          expect(@hook_method_calls[0]).to eq(state: :state_1, method: :on_start, params: {})
          expect(@hook_method_calls[1]).to eq(state: :state_2, method: :on_start, params: {})
          expect(@hook_method_calls[2]).to eq(state: :state_3, method: :on_start, params: {})
          expect(@hook_method_calls[3]).to eq(state: :state_1, method: :on_entry, params: { context: [] })
        end
      end

      describe "has `next` method that" do
        it "transfers from one state to another and stays at the same parent state" do
          @sub_state_machine.on_entry(["random context"])
          @hook_method_calls.clear
          next_state = @sub_state_machine.next("state_1 -> state_2", ["random context"])
          @sub_state_machine.on_exit(["random context"])

          expect(@hook_method_calls[0])
            .to eq(state: :state_1, method: :next, params: { input: "state_1 -> state_2", context: [] })
          expect(@hook_method_calls[1])
            .to eq(state: :state_1, method: :on_exit, params: { context: ["message from state 1"] })
          expect(@hook_method_calls[2])
            .to eq(state: :state_2, method: :on_entry, params: { context: ["message from state 1"] })

          expect(next_state).to be(:parent_state_1)
        end

        it "transfers to a final state and returns to target parent state" do
          @sub_state_machine.on_entry(["random context"])
          @sub_state_machine.next("state_1 -> state_2", ["random context"])
          @sub_state_machine.on_exit(["random context"])
          @hook_method_calls.clear
          @sub_state_machine.on_entry(["random context"])
          next_state = @sub_state_machine.next("state_2 -> state_3", ["random context"])
          @sub_state_machine.on_exit(["random context"])

          expect(@hook_method_calls[0])
            .to eq(state: :state_2, method: :next, params: {
              input: "state_2 -> state_3",
              context: ["message from state 1"]
            })
          expect(@hook_method_calls[1])
            .to eq(state: :state_2, method: :on_exit, params: {
              context: ["message from state 1", "message from state 2"]
            })
          expect(@hook_method_calls[2])
            .to eq(state: :state_3, method: :on_entry, params: {
              context: ["message from state 1", "message from state 2"]
            })

          expect(next_state).to be(:parent_state_2)
        end
      end

      describe "has `on_stop` method that" do
        it "stops sub state machine if it is started" do
          @sub_state_machine.on_entry(["random context"])
          @hook_method_calls.clear
          @sub_state_machine.on_stop

          expect(@hook_method_calls[0]).to eq(state: :state_1, method: :on_stop, params: {})
          expect(@hook_method_calls[1]).to eq(state: :state_2, method: :on_stop, params: {})
          expect(@hook_method_calls[2]).to eq(state: :state_3, method: :on_stop, params: {})
        end
      end
    end
  end
end
