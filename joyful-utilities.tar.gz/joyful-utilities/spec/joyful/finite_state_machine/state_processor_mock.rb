require "joyful/finite_state_machine/state_processor"
require "joyful/utilities/clone_deep"

class StateProcessorMock < Joyful::FiniteStateMachine::StateProcessor
  def initialize(state, next_state, appended_to_context, mutable_recorder)
    @state = state
    @next_state = next_state
    @appended_to_context = appended_to_context
    @mutable_recorder = mutable_recorder
  end

  def on_start
    @mutable_recorder.push(state: @state, method: :on_start, params: {})
  end

  def on_entry(context)
    @mutable_recorder
      .push(state: @state, method: :on_entry, params: { context: Joyful::Utilities.clone_deep(context) })
  end

  def next(input, context)
    @mutable_recorder
      .push(state: @state, method: :next, params: { input: input, context: Joyful::Utilities.clone_deep(context) })
    context.push(@appended_to_context)
    return @next_state
  end

  def on_exit(context)
    @mutable_recorder
      .push(state: @state, method: :on_exit, params: { context: Joyful::Utilities.clone_deep(context) })
  end

  def on_stop
    @mutable_recorder.push(state: @state, method: :on_stop, params: {})
  end
end
