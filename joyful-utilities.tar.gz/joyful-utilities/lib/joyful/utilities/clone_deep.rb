module Joyful
  module Utilities
    def self.clone_deep(object)
      return Marshal.load(Marshal.dump(object))
    end
  end
end
