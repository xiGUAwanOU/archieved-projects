module Joyful
  module DataStorage
    class DataStorageError < RuntimeError
      class << self
        def for_duplicated_data_pool(data_pool)
          return DataStorageError.new("Data pool with name '#{data_pool.name}' already exists")
        end
      end
    end
  end
end
