module Joyful
  module DataStorage
    class DataEntityPredicate
      def test(_data_entity, _parameters)
        raise(NotImplementedError, "test in Joyful::DataStorage::Predicate must be implemented")
      end
    end
  end
end
