require "securerandom"

require "joyful/utilities/clone_deep"

module Joyful
  module DataStorage
    class DataEntity
      def initialize(id = nil)
        @id = id.nil? ? SecureRandom.uuid : id
      end

      attr_reader :id

      def clone
        return Joyful::Utilities.clone_deep(self)
      end
    end
  end
end
