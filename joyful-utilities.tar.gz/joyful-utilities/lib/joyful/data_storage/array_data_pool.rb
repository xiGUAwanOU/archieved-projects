require "joyful/data_storage/data_pool"

module Joyful
  module DataStorage
    class ArrayDataPool < DataPool
      def initialize(name)
        super(name)
        @data_entities = []
      end

      def upsert(data_entity)
        delete(data_entity.id)
        @data_entities.push(data_entity)
      end

      def delete(id)
        @data_entities.delete_if{|data_entity| data_entity.id == id}
      end

      def find_one(id)
        return @data_entities.select{|data_entity| data_entity.id == id}.first.clone
      end

      def find_all(data_entity_predicate, parameters)
        return @data_entities
            .select{|data_entity| data_entity_predicate.test(data_entity, parameters)}
            .map(&:clone)
      end
    end
  end
end
