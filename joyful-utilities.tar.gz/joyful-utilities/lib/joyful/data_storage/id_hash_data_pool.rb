require "joyful/data_storage/data_pool"

module Joyful
  module DataStorage
    class IdHashDataPool < DataPool
      def initialize(name)
        super(name)
        @data_entities = {}
      end

      def upsert(data_entity)
        @data_entities[data_entity.id] = data_entity
      end

      def delete(id)
        @data_entities.delete(id)
      end

      def find_one(id)
        return @data_entities[id].clone
      end

      def find_all(data_entity_predicate, parameters)
        return @data_entities.values
            .select{|data_entity| data_entity_predicate.test(data_entity, parameters)}
            .map(&:clone)
      end
    end
  end
end
