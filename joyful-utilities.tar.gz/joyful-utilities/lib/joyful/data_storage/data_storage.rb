require "joyful/data_storage/errors/data_storage_error"

module Joyful
  module DataStorage
    class DataStorage
      def initialize
        @data_pools = {}
      end

      def register_data_pool(data_pool)
        raise(DataStorageError.for_duplicated_data_pool(data_pool)) if @data_pools.has_key?(data_pool.name)
        @data_pools[data_pool.name] = data_pool
      end

      def data_pool(name)
        return @data_pools[name]
      end
    end
  end
end
