module Joyful
  module DataStorage
    class DataPool
      def initialize(name)
        @name = name
      end

      attr_reader :name

      def upsert(_data_entity)
        raise(NotImplementedError, "upsert in Joyful::DataStorage::DataPool must be implemented")
      end

      def delete(_id)
        raise(NotImplementedError, "delete in Joyful::DataStorage::DataPool must be implemented")
      end

      def find_one(_id)
        raise(NotImplementedError, "find_one in Joyful::DataStorage::DataPool must be implemented")
      end

      def find_all(_data_entity_predicate, _parameters)
        raise(NotImplementedError, "find_all in Joyful::DataStorage::DataPool must be implemented")
      end
    end
  end
end
