require "joyful/finite_state_machine/state_processor"
require "joyful/finite_state_machine/state_machine"

module Joyful
  module FiniteStateMachine
    class SubStateMachine < StateProcessor
      def initialize(state_machine, own_state, next_state)
        @state_machine = state_machine
        @own_state = own_state
        @next_state = next_state
      end

      def on_start
      end

      def on_entry(_context)
        @state_machine.start unless @state_machine.started?
      end

      def next(input, _context)
        @state_machine.process(input)
        if @state_machine.stop?
          return @next_state
        else
          return @own_state
        end
      end

      def on_exit(_context)
      end

      def on_stop
        @state_machine.stop! if @state_machine.started?
      end
    end
  end
end
