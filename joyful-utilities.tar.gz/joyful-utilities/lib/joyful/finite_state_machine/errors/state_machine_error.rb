module Joyful
  module FiniteStateMachine
    class StateMachineError < RuntimeError
      class << self
        def for_not_started
          return StateMachineError.new("State machine is not started")
        end

        def for_already_started
          return StateMachineError.new("State machine has already been started")
        end

        def for_unknown_state(unknown_state)
          return StateMachineError.new("State '#{unknown_state}' does not exist")
        end
      end
    end
  end
end
