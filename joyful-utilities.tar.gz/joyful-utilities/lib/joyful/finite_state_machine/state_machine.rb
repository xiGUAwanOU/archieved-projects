require "joyful/finite_state_machine/errors/state_machine_error"

require "joyful/utilities/clone_deep"

module Joyful
  module FiniteStateMachine
    class StateMachine
      def initialize(state_definitions, start_state, final_states, initial_context)
        @state_definitions = state_definitions
        @start_state = start_state
        @final_states = final_states
        @initial_context = initial_context

        @current_state = nil
        @mutable_context = nil
      end

      def start
        raise(StateMachineError.for_already_started) if started?
        @state_definitions.each_value(&:on_start)
        @mutable_context = Joyful::Utilities.clone_deep(@initial_context)
        enter_next_state(@start_state)
      end

      def process(input)
        raise(StateMachineError.for_not_started) unless started?
        next_state = current_state_processor.next(input, @mutable_context)
        current_state_processor.on_exit(@mutable_context)
        enter_next_state(next_state)
      end

      def stop?
        stop! if @final_states.include?(@current_state)
        return !started?
      end

      def stop!
        raise(StateMachineError.for_not_started) unless started?
        @state_definitions.each_value(&:on_stop)
        @current_state = nil
        @mutable_context = nil
      end

      def started?
        return !@current_state.nil?
      end

      private def current_state_processor
        return @state_definitions[@current_state]
      end

      private def enter_next_state(new_state)
        raise(StateMachineError.for_unknown_state(new_state)) unless @state_definitions.has_key?(new_state)
        @current_state = new_state
        current_state_processor.on_entry(@mutable_context)
      end

      class << self
        def build
          return Builder.new
        end

        class Builder
          def initialize
            @state_definitions = {}
            @start_state = nil
            @final_states = []
            @initial_context = nil
          end

          def add_state(state, state_processor)
            @state_definitions[state] = state_processor
            return self
          end

          def start_state(start_state)
            @start_state = start_state
            return self
          end

          def final_state(final_state)
            @final_states.push(final_state)
            return self
          end

          def initial_context(initial_context)
            @initial_context = initial_context
            return self
          end

          def do
            return StateMachine.new(@state_definitions, @start_state, @final_states, @initial_context)
          end
        end
      end
    end
  end
end
