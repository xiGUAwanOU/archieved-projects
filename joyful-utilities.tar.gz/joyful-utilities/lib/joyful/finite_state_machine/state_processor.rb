module Joyful
  module FiniteStateMachine
    class StateProcessor
      def on_start
        raise(NotImplementedError, "on_start in Joyful::FiniteStateMachine::StateProcessor must be implemented")
      end

      def on_entry(_context)
        raise(NotImplementedError, "on_entry in Joyful::FiniteStateMachine::StateProcessor must be implemented")
      end

      def next(_input, _context)
        raise(NotImplementedError, "next in Joyful::FiniteStateMachine::StateProcessor must be implemented")
      end

      def on_exit(_context)
        raise(NotImplementedError, "on_exit in Joyful::FiniteStateMachine::StateProcessor must be implemented")
      end

      def on_stop(_context)
        raise(NotImplementedError, "on_stop in Joyful::FiniteStateMachine::StateProcessor must be implemented")
      end
    end
  end
end
