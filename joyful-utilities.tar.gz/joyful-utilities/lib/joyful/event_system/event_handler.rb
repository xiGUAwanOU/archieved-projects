module Joyful
  module EventSystem
    class EventHandler
      def initialize(handled_types)
        @handled_types = handled_types
      end

      attr_reader :handled_types

      def handle(_event)
        raise(NotImplementedError, "handle in Joyful::EventSystem::EventHandler must be implemented")
      end
    end
  end
end
