require "monitor"

module Joyful
  module EventSystem
    class EventQueue < Monitor
      def initialize
        super
        @queue = []
      end

      def push(obj)
        synchronize do
          @queue.push(obj)
        end
      end

      def peek
        synchronize do
          return @queue.first
        end
      end

      def poll
        synchronize do
          return @queue.shift
        end
      end
    end
  end
end
