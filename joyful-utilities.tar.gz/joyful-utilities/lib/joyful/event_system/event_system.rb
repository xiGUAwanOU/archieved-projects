require "joyful/event_system/event_queue"
require "joyful/event_system/event_dispatcher"

require "joyful/event_system/errors/event_system_error"

module Joyful
  module EventSystem
    class EventSystem
      def initialize
        @event_queue = EventQueue.new
        @event_dispatcher = EventDispatcher.new

        @event_processing_thread = nil
        @continue_event_processing = true
      end

      def broadcast(event)
        @event_queue.push(event)
      end

      def register_handler(event_handler)
        @event_dispatcher.register_handler(event_handler)
      end

      def unregister_handler
        @event_dispatcher.unregister_handler(event_handler)
      end

      def process_one
        @event_dispatcher.dispatch(@event_queue.poll) if @event_queue.peek
      end

      def start(sleeping_time = 0)
        raise(EventSystemError.for_already_started) if started?

        @continue_event_processing = true
        @event_processing_thread = Thread.new do
          while @continue_event_processing
            process_one
            sleep(sleeping_time)
          end
        end
      end

      def started?
        return !@event_processing_thread.nil?
      end

      def stop
        raise(EventSystemError.for_not_started) unless started?

        @continue_event_processing = false
        @event_processing_thread.join
        @event_processing_thread = nil
      end
    end
  end
end
