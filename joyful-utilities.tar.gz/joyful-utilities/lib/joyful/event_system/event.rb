module Joyful
  module EventSystem
    class Event
      def initialize(type, payload)
        @type = type
        @payload = payload
      end

      attr_reader :type, :payload
    end
  end
end
