module Joyful
  module EventSystem
    class EventSystemError < RuntimeError
      class << self
        def for_not_started
          return EventSystemError.new("Event system is not started")
        end

        def for_already_started
          return EventSystemError.new("Event system has already been started")
        end
      end
    end
  end
end
