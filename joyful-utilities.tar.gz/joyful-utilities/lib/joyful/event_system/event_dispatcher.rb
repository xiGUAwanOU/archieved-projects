require "weakref"

module Joyful
  module EventSystem
    class EventDispatcher
      def initialize
        @event_handlers = {}
      end

      def register_handler(event_handler)
        event_handler.handled_types.each do |handled_type|
          @event_handlers[handled_type] = [] unless @event_handlers.has_key?(handled_type)
          @event_handlers[handled_type].push(WeakRef.new(event_handler))
        end
      end

      def unregister_handler(event_handler)
        event_handler.handled_types.each do |handled_type|
          @event_handlers[handled_type].delete(event_handler) if @event_handlers.has_key?(handled_type)
        end
      end

      def dispatch(event)
        event_type = event.type
        return unless @event_handlers.has_key?(event_type)

        alive_event_handlers = []
        @event_handlers[event_type].each do |event_handler_ref|
          if event_handler_ref.weakref_alive?
            event_handler_ref.handle(event)
            alive_event_handlers.push(event_handler_ref)
          end
        end

        @event_handlers[event_type] = alive_event_handlers
      end
    end
  end
end
