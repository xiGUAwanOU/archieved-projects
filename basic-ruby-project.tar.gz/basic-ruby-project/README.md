# Basic Ruby Project

Use following command to create a new ruby project (replace `<NEW_PROJECT_NAME>` with the valid project folder name):

```console
$ curl -s https://raw.githubusercontent.com/xiGUAwanOU/basic-ruby-project/master/init.sh | sh -s <NEW_PROJECT_NAME>
```
