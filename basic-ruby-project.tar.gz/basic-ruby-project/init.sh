git clone https://github.com/xiGUAwanOU/basic-ruby-project.git $1
cd $1
rm -rf .git init.sh README.md
git init
echo "# $1" > README.md
