$LOAD_PATH.unshift(__dir__) unless $LOAD_PATH.include?(__dir__)
