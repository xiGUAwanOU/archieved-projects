package travel.blog.server.services;

import org.junit.Ignore;
import org.junit.Test;

public class AuthServiceTest {
    @Test
    @Ignore("This method is only for manually calculating the secure password for development environment.")
    public void calculateSecurePassword() {
        System.out.println(AuthService.getSha1HashedBase64String("nopassword"));
    }
}
