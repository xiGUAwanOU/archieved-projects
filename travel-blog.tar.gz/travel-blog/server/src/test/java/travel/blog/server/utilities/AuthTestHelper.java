package travel.blog.server.utilities;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

import travel.blog.server.models.User;

public class AuthTestHelper {
    private static final String USERNAME = "whoever";
    private static final String PASSWORD = "whatever";
    private static final String SECURE_PASSWORD = "2Gnbf+YvsHwloEA+yupVAxdEtfs=";

    public static User getUser() {
        return new User("00000000-0000-0000-0000-000000000000", USERNAME, PASSWORD, SECURE_PASSWORD);
    }

    public static String getSignedJwt() {
        return JWT.create().withIssuer("travel-blog").withClaim("username", USERNAME).sign(Algorithm.HMAC256("nosecret"));
    }
}
