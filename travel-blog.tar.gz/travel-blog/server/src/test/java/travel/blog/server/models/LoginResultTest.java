package travel.blog.server.models;

import org.junit.Test;

import java.util.Optional;

import travel.blog.server.utilities.AbstractJsonTest;

public class LoginResultTest extends AbstractJsonTest<LoginResult> {
    @Test
    public void deserialize_HasCorrectJson() {
        assertDeserializedEqualToJsonFile(new LoginResult(true, Optional.of("JWT for test")), "loginResult.json");
    }
}