package travel.blog.server.models;

import org.junit.Test;

import travel.blog.server.utilities.AbstractJsonTest;

public class ArticleTest extends AbstractJsonTest<Article> {
    @Test
    public void deserializeAndSerialize_HasSameValues() {
        assertSameBeingDeserializedAndSerialized(Article.class, "article.json");
    }
}