package travel.blog.server.utilities;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.Map;

import travel.blog.server.configurations.JacksonConfiguration;

public class GraphQLResponse {
    private static final ObjectMapper OBJECT_MAPPER = new JacksonConfiguration().getObjectMapper();

    private final Map<String, Object> responseData;

    @JsonCreator
    public GraphQLResponse(@JsonProperty("data") Map<String, Object> responseMap) {
        this.responseData = responseMap;
    }

    public <T> T get(String objectName, Class<T> objectClass) {
        String json = serialize(responseData.get(objectName));

        try {
            return OBJECT_MAPPER.readValue(json, objectClass);
        } catch (IOException e) {
            throw new RuntimeException("Cannot deserialize object");
        }
    }

    public <T> T get(String objectName, TypeReference<T> typeReference) {
        String json = serialize(responseData.get(objectName));

        try {
            return OBJECT_MAPPER.readValue(json, typeReference);
        } catch (IOException e) {
            throw new RuntimeException("Cannot deserialize object");
        }
    }

    private String serialize(Object object) {
        try {
            return OBJECT_MAPPER.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Cannot serialize object");
        }
    }
}
