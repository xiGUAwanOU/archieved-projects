package travel.blog.server.utilities;

import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

public class GraphQLTestHelper {
    private final TestRestTemplate testRestTemplate;
    private final Optional<String> signedJwt;

    public GraphQLTestHelper(TestRestTemplate testRestTemplate) {
        this.testRestTemplate = testRestTemplate;
        this.signedJwt = Optional.empty();
    }

    public GraphQLTestHelper(TestRestTemplate testRestTemplate, String singedJwt) {
        this.testRestTemplate = testRestTemplate;
        this.signedJwt = Optional.of(singedJwt);
    }

    public ResponseEntity<GraphQLResponse> query(String graphQLQuery) {
        return query(graphQLQuery, Collections.emptyMap());
    }

    public ResponseEntity<GraphQLResponse> query(String graphQLQuery, Map<String, Object> variables) {
        MultiValueMap<String, Object> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("query", graphQLQuery);
        queryParams.add("variables", variables);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        signedJwt.ifPresent(jwt -> headers.set("Authorization", "Bearer " + jwt));

        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(queryParams, headers);

        return testRestTemplate.postForEntity("/api/graphql", request, GraphQLResponse.class);
    }
}
