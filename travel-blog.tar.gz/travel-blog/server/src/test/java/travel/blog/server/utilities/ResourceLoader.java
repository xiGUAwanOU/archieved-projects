package travel.blog.server.utilities;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import travel.blog.server.configurations.JacksonConfiguration;

public class ResourceLoader {
    private static final ObjectMapper OBJECT_MAPPER = new JacksonConfiguration().getObjectMapper();

    public static String load(Class<?> testClass, String filename) {
        try {
            return new String(Files.readAllBytes(Paths.get(testClass.getResource(filename).toURI())), StandardCharsets.UTF_8);
        } catch (IOException | URISyntaxException e) {
            throw new RuntimeException(String.format("Cannot read resource file '%s'.", filename));
        }
    }

    public static <T> T loadJson(Class<T> testClass, String filename) {
        try {
            return OBJECT_MAPPER.readValue(load(testClass, filename), testClass);
        } catch (IOException e) {
            throw new RuntimeException("Cannot deserialize object");
        }
    }
}
