package travel.blog.server.resolvers;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import travel.blog.server.models.Article;
import travel.blog.server.repositories.ArticleRepository;
import travel.blog.server.repositories.UserRepository;
import travel.blog.server.utilities.AbstractIntegrationTest;
import travel.blog.server.utilities.AuthTestHelper;
import travel.blog.server.utilities.GraphQLResponse;
import travel.blog.server.utilities.GraphQLTestHelper;
import travel.blog.server.utilities.ResourceLoader;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = RANDOM_PORT)
@ActiveProfiles("test")
public class MutationResolverIntegrationTest extends AbstractIntegrationTest {
    private static final String CREATE_ARTICLE = ResourceLoader.load(MutationResolverIntegrationTest.class, "createArticle.graphql");
    private static final String UPDATE_ARTICLE = ResourceLoader.load(MutationResolverIntegrationTest.class, "updateArticle.graphql");
    private static final String DELETE_ARTICLE = ResourceLoader.load(MutationResolverIntegrationTest.class, "deleteArticle.graphql");

    @Autowired
    private ArticleRepository articleRepository;

    @Autowired
    private UserRepository userRepository;

    private GraphQLTestHelper graphQLTestHelper;

    @Before
    public void setup() {
        articleRepository.deleteAll();

        userRepository.deleteAll();
        userRepository.insert(AuthTestHelper.getUser());

        graphQLTestHelper = new GraphQLTestHelper(testRestTemplate, AuthTestHelper.getSignedJwt());
    }

    @Test
    public void createArticle_ArticleInsertedInDB() {
        Article article = ResourceLoader.loadJson(Article.class, "article.json").withId(null);

        ResponseEntity<GraphQLResponse> response = graphQLTestHelper.query(CREATE_ARTICLE, Collections.singletonMap("article", article));

        String articleId = response.getBody().get("createArticle", Article.class).getId();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(articleRepository.findById(articleId)).hasValueSatisfying(
                articleValue -> assertThat(articleValue).isEqualToComparingFieldByFieldRecursively(article.withId(articleId)));
    }

    @Test
    public void updateArticle_ArticleUpdatedInDB() {
        Article article = ResourceLoader.loadJson(Article.class, "article.json").withRandomId();

        articleRepository.insert(article);

        Article updatedArticle = new Article(null, "Updated Title for Test", article.getDate(), article.getPlace(),
                article.getIntroduction(), article.getContent(), article.getThumbnailImageUrl(), article.getMusicPlayer());

        Map<String, Object> variables = new HashMap<>();
        variables.put("id", article.getId());
        variables.put("article", updatedArticle);

        ResponseEntity<GraphQLResponse> response = graphQLTestHelper.query(UPDATE_ARTICLE, variables);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(articleRepository.findById(article.getId())).hasValueSatisfying(
                articleValue -> assertThat(articleValue).isEqualToComparingFieldByFieldRecursively(updatedArticle.withId(article.getId())));
    }

    @Test
    public void deleteArticle_ArticleRemovedFromDB() {
        Article article = ResourceLoader.loadJson(Article.class, "article.json").withRandomId();

        articleRepository.insert(article);

        ResponseEntity<GraphQLResponse> response = graphQLTestHelper.query(DELETE_ARTICLE, Collections.singletonMap("id", article.getId()));
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(articleRepository.findById(article.getId())).isEmpty();
    }
}