package travel.blog.server.utilities;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@JsonTest
public abstract class AbstractJsonTest<T> {
    protected static final String JSON_ERROR_MESSAGE = "Error occurs while handling JSON content";

    @Autowired
    private JacksonTester<T> json;

    protected void assertSameBeingDeserializedAndSerialized(Class<T> testedClass, String jsonFilename) {
        String jsonString = ResourceLoader.load(testedClass, jsonFilename);

        try {
            assertThat(json.write(json.parseObject(jsonString))).isEqualToJson(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(JSON_ERROR_MESSAGE);
        }
    }

    protected void assertDeserializedEqualToJsonFile(T object, String jsonFilename) {
        String jsonString = ResourceLoader.load(object.getClass(), jsonFilename);

        try {
            assertThat(json.write(object)).isEqualToJson(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(JSON_ERROR_MESSAGE);
        }
    }
}
