package travel.blog.server.resolvers;

import com.fasterxml.jackson.core.type.TypeReference;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

import travel.blog.server.models.Article;
import travel.blog.server.repositories.ArticleRepository;
import travel.blog.server.utilities.AbstractIntegrationTest;
import travel.blog.server.utilities.GraphQLResponse;
import travel.blog.server.utilities.GraphQLTestHelper;
import travel.blog.server.utilities.ResourceLoader;

import static org.assertj.core.api.Assertions.assertThat;

public class QueryResolverIntegrationTest extends AbstractIntegrationTest {
    private static final String QUERY_ALL_ARTICLES = ResourceLoader.load(QueryResolverIntegrationTest.class, "queryArticles.graphql");
    private static final String QUERY_ONE_ARTICLES_WITH_ID = ResourceLoader.load(QueryResolverIntegrationTest.class,
            "queryArticle.graphql");

    @Autowired
    private ArticleRepository articleRepository;

    private GraphQLTestHelper graphQLTestHelper;

    @Before
    public void setup() {
        articleRepository.deleteAll();

        graphQLTestHelper = new GraphQLTestHelper(testRestTemplate);
    }

    @Test
    public void articles_WithoutAnyArticles_ReturnEmptyArray() {
        ResponseEntity<GraphQLResponse> response = graphQLTestHelper.query(QUERY_ALL_ARTICLES);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().get("articles", new TypeReference<List<Article>>() {
        })).isEmpty();
    }

    @Test
    public void articles_WithArticlesInDB_ReturnsAllArticles() {
        Article article = ResourceLoader.loadJson(Article.class, "article.json").withRandomId();

        articleRepository.insert(article);

        ResponseEntity<GraphQLResponse> response = graphQLTestHelper.query(QUERY_ALL_ARTICLES);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().get("articles", new TypeReference<List<Article>>() {
        })).hasOnlyOneElementSatisfying(articleValue -> assertThat(articleValue).isEqualToComparingFieldByFieldRecursively(article));
    }

    @Test
    public void article_WithArticlesInDB_ReturnsArticleMatchingId() {
        Article article1 = ResourceLoader.loadJson(Article.class, "article.json").withRandomId();
        Article article2 = ResourceLoader.loadJson(Article.class, "article.json").withRandomId();

        articleRepository.insert(article1);
        articleRepository.insert(article2);

        ResponseEntity<GraphQLResponse> response = graphQLTestHelper.query(QUERY_ONE_ARTICLES_WITH_ID,
                Collections.singletonMap("id", article1.getId()));

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().get("article", Article.class)).isEqualToComparingFieldByFieldRecursively(article1);
    }
}