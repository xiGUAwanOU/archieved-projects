package travel.blog.server.models;

import org.junit.Test;

import travel.blog.server.utilities.AbstractJsonTest;

public class UserTest extends AbstractJsonTest<User> {
    @Test
    public void deserializeAndSerialize_HasSameValues() {
        assertSameBeingDeserializedAndSerialized(User.class, "user.json");
    }
}