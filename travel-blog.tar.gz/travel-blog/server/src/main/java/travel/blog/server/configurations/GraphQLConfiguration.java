package travel.blog.server.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import graphql.servlet.GraphQLErrorHandler;
import travel.blog.server.services.JacksonFriendlyGraphQLErrorHandler;

@Configuration
public class GraphQLConfiguration {
    @Bean
    @Primary
    public GraphQLErrorHandler getGraphQLErrorHandler() {
        return new JacksonFriendlyGraphQLErrorHandler();
    }
}
