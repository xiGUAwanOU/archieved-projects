package travel.blog.server.exceptions;

import java.util.List;

import graphql.GraphQLError;
import graphql.language.SourceLocation;

public abstract class GraphQLException extends RuntimeException implements GraphQLError {
    public GraphQLException(String message) {
        super(message);
    }

    public GraphQLException(String message, Throwable cause) {
        super(message, cause);
    }

    @Override
    public List<SourceLocation> getLocations() {
        return null;
    }
}
