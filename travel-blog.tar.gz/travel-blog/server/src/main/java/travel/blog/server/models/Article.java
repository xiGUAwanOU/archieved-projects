package travel.blog.server.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.hibernate.validator.constraints.URL;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;
import java.util.UUID;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;

public class Article {
    public static class Properties {
        public static final String ID = "id";
        public static final String TITLE = "title";
        public static final String DATE = "date";
        public static final String PLACE = "place";
        public static final String INTRODUCTION = "introduction";
        public static final String CONTENT = "content";
        public static final String THUMBNAIL_IMAGE_URL = "thumbnailImageUrl";
        public static final String MUSIC_PLAYER = "musicPlayer";
    }

    @Id
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(Properties.ID)
    private final String id;

    @JsonProperty(Properties.TITLE)
    private final String title;

    @JsonProperty(Properties.DATE)
    private final LocalDate date;

    @JsonProperty(Properties.PLACE)
    private final Place place;

    @JsonProperty(Properties.INTRODUCTION)
    private final String introduction;

    @JsonProperty(Properties.CONTENT)
    private final String content;

    @JsonProperty(Properties.THUMBNAIL_IMAGE_URL)
    @URL
    private final String thumbnailImageUrl;

    @JsonProperty(Properties.MUSIC_PLAYER)
    private final String musicPlayer;

    public Article(@JsonProperty(Properties.ID) String id, @JsonProperty(Properties.TITLE) String title,
            @JsonProperty(Properties.DATE) LocalDate date, @JsonProperty(Properties.PLACE) Place place,
            @JsonProperty(Properties.INTRODUCTION) String introduction, @JsonProperty(Properties.CONTENT) String content,
            @JsonProperty(Properties.THUMBNAIL_IMAGE_URL) String thumbnailImageUrl,
            @JsonProperty(Properties.MUSIC_PLAYER) String musicPlayer) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.introduction = introduction;
        this.content = content;
        this.thumbnailImageUrl = thumbnailImageUrl;
        this.place = place;
        this.musicPlayer = musicPlayer;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public LocalDate getDate() {
        return date;
    }

    public Place getPlace() {
        return place;
    }

    public String getIntroduction() {
        return introduction;
    }

    public String getContent() {
        return content;
    }

    public String getThumbnailImageUrl() {
        return thumbnailImageUrl;
    }

    public String getMusicPlayer() {
        return musicPlayer;
    }

    public Article withRandomId() {
        return withId(UUID.randomUUID().toString());
    }

    public Article withId(String id) {
        return new Article(id, title, date, place, introduction, content, thumbnailImageUrl, musicPlayer);
    }

    public static class Place {
        public static class Properties {
            public static final String NAME = "name";
            public static final String LONGITUDE = "longitude";
            public static final String LATITUDE = "latitude";
        }

        @JsonProperty(Properties.NAME)
        @NotEmpty
        private final String name;

        @JsonProperty(Properties.LONGITUDE)
        @DecimalMin("-180.0")
        @DecimalMax("180.0")
        private final double longitude;

        @JsonProperty(Properties.LATITUDE)
        @DecimalMin("-90.0")
        @DecimalMax("90.0")
        private final double latitude;

        @JsonCreator
        public Place(@JsonProperty(Properties.NAME) String name, @JsonProperty(Properties.LONGITUDE) double longitude,
                @JsonProperty(Properties.LATITUDE) double latitude) {
            this.name = name;
            this.longitude = longitude;
            this.latitude = latitude;
        }

        public String getName() {
            return name;
        }

        public double getLongitude() {
            return longitude;
        }

        public double getLatitude() {
            return latitude;
        }
    }
}
