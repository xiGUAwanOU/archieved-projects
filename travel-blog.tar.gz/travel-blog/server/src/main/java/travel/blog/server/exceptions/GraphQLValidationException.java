package travel.blog.server.exceptions;

import graphql.ErrorType;

public class GraphQLValidationException extends GraphQLException {
    public GraphQLValidationException(String message) {
        super(message);
    }

    @Override
    public ErrorType getErrorType() {
        return ErrorType.ValidationError;
    }
}
