package travel.blog.server.exceptions;

import graphql.ErrorType;

public class GraphQLEntityNotFoundException extends GraphQLException {
    public GraphQLEntityNotFoundException(String entityName, String id) {
        this(String.format("Cannot find %s with ID %s", entityName, id));
    }

    public GraphQLEntityNotFoundException(String message) {
        super(message);
    }

    @Override
    public ErrorType getErrorType() {
        return ErrorType.DataFetchingException;
    }
}
