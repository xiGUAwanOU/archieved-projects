package travel.blog.server.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Optional;

public class LoginResult {
    public static class Properties {
        public static final String SUCCESSFUL = "successful";
        public static final String JWT = "jwt";
    }

    @JsonProperty(Properties.SUCCESSFUL)
    private final boolean successful;

    @JsonProperty(Properties.JWT)
    private final Optional<String> jwt;

    public LoginResult(boolean successful, Optional<String> jwt) {
        this.successful = successful;
        this.jwt = jwt;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public Optional<String> getJwt() {
        return jwt;
    }

    public static LoginResult failed() {
        return new LoginResult(false, Optional.empty());
    }

    public static LoginResult ok(String jwt) {
        return new LoginResult(true, Optional.of(jwt));
    }
}
