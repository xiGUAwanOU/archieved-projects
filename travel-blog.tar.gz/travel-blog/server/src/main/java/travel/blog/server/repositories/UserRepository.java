package travel.blog.server.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

import travel.blog.server.models.User;

public interface UserRepository extends MongoRepository<User, String> {
    List<User> findByUsername(String username);
}
