package travel.blog.server.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import travel.blog.server.models.Article;

public interface ArticleRepository extends MongoRepository<Article, String> {
}
