package travel.blog.server.resolvers;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import graphql.schema.DataFetchingEnvironment;
import travel.blog.server.models.Article;
import travel.blog.server.repositories.ArticleRepository;
import travel.blog.server.services.GraphQLAuthService;
import travel.blog.server.services.GraphQLValidationService;

@Component
public class MutationResolver implements GraphQLMutationResolver {
    private final GraphQLAuthService authService;
    private final GraphQLValidationService validator;

    private final ArticleRepository articleRepository;

    @Autowired
    public MutationResolver(GraphQLAuthService authService, GraphQLValidationService validator, ArticleRepository articleRepository) {
        this.authService = authService;
        this.validator = validator;

        this.articleRepository = articleRepository;
    }

    public Article createArticle(Article article, DataFetchingEnvironment environment) {
        authService.authorize(environment);
        validator.validate(article);

        return articleRepository.insert(article.withRandomId());
    }

    public Article updateArticle(String id, Article article, DataFetchingEnvironment environment) {
        authService.authorize(environment);
        validator.validate(article);

        return articleRepository.save(article.withId(id));
    }

    public void deleteArticle(String id, DataFetchingEnvironment environment) {
        authService.authorize(environment);
        articleRepository.deleteById(id);
    }
}
