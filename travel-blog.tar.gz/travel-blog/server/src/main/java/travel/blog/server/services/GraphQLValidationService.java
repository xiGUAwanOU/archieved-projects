package travel.blog.server.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import travel.blog.server.exceptions.GraphQLValidationException;

@Service
public class GraphQLValidationService {
    private final Validator validator;

    @Autowired
    public GraphQLValidationService(Validator validator) {
        this.validator = validator;
    }

    public <T> void validate(T object) {
        List<ConstraintViolation<T>> constraintViolations = new ArrayList<>(validator.validate(object));

        if (!constraintViolations.isEmpty()) {
            String errorMessage = String.format("Data is invalid for type %s: %s", object.getClass().getSimpleName(),
                    constraintViolations.stream().map(this::buildErrorMessageForSingleViolation).collect(Collectors.joining(", ")));
            throw new GraphQLValidationException(errorMessage);
        }
    }

    private <T> String buildErrorMessageForSingleViolation(ConstraintViolation<T> constraintViolation) {
        return String.format("%s %s", constraintViolation.getPropertyPath().toString(), constraintViolation.getMessage());
    }
}
