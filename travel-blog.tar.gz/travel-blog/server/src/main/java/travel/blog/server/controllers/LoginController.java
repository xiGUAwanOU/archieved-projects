package travel.blog.server.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import travel.blog.server.models.LoginResult;
import travel.blog.server.models.User;
import travel.blog.server.services.AuthService;

@RestController
@RequestMapping("/api/login")
public class LoginController {
    private final AuthService authService;

    @Autowired
    public LoginController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping
    public ResponseEntity<LoginResult> login(@RequestBody User user) {
        LoginResult result = authService.login(user);

        return (result.isSuccessful() ? ResponseEntity.status(HttpStatus.OK) : ResponseEntity.status(HttpStatus.FORBIDDEN)).body(result);
    }
}
