package travel.blog.server.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.stream.Collectors;

import graphql.ErrorType;
import graphql.GraphQLError;
import graphql.language.SourceLocation;

public class JacksonFriendlyGraphQLError implements GraphQLError {
    public static class Properties {
        public static final String MESSAGE = "message";
        public static final String LOCATIONS = "locations";
        public static final String TYPE = "type";
    }

    private final GraphQLError error;

    public JacksonFriendlyGraphQLError(GraphQLError unserializableError) {
        this.error = unserializableError;
    }

    @Override
    @JsonProperty(Properties.MESSAGE)
    public String getMessage() {
        return error.getMessage();
    }

    @Override
    @JsonProperty(Properties.LOCATIONS)
    public List<SourceLocation> getLocations() {
        return error.getLocations().stream().map(JacksonFriendlySourceLocation::new).collect(Collectors.toList());
    }

    @Override
    @JsonProperty(Properties.TYPE)
    public ErrorType getErrorType() {
        return error.getErrorType();
    }

    public static class JacksonFriendlySourceLocation extends SourceLocation {
        public static class Properties {
            public static final String LINE = "line";
            public static final String COLUMN = "column";
            public static final String SOURCE_NAME = "sourceName";
        }

        public JacksonFriendlySourceLocation(SourceLocation unserializableSourceLocation) {
            super(unserializableSourceLocation.getLine(), unserializableSourceLocation.getColumn(),
                    unserializableSourceLocation.getSourceName());
        }

        @JsonProperty(Properties.LINE)
        public int getLine() {
            return super.getLine();
        }

        @JsonProperty(Properties.COLUMN)
        public int getColumn() {
            return super.getColumn();
        }

        @JsonProperty(Properties.SOURCE_NAME)
        public String getSourceName() {
            return super.getSourceName();
        }
    }
}
