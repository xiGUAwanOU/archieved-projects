package travel.blog.server.exceptions;

import graphql.ErrorType;

public class GraphQLAuthException extends GraphQLException {
    public GraphQLAuthException() {
        super("Operation is not authorized");
    }

    @Override
    public ErrorType getErrorType() {
        return ErrorType.DataFetchingException;
    }
}
