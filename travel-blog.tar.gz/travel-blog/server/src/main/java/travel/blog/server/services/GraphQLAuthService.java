package travel.blog.server.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import graphql.schema.DataFetchingEnvironment;
import graphql.servlet.GraphQLContext;
import travel.blog.server.exceptions.GraphQLAuthException;

@Service
public class GraphQLAuthService {
    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";

    private final AuthService authService;

    @Autowired
    public GraphQLAuthService(AuthService authService) {
        this.authService = authService;
    }

    public void authorize(DataFetchingEnvironment environment) {
        String jwt = extractJwt(environment);

        if (!authService.authorize(jwt)) {
            throw new GraphQLAuthException();
        }
    }

    private String extractJwt(DataFetchingEnvironment environment) {
        String authenticationHeader = environment.<GraphQLContext>getContext().getHttpServletRequest()
                .orElseThrow(GraphQLAuthException::new)
                .getHeader(AUTHORIZATION_HEADER);

        return Optional.ofNullable(authenticationHeader)
                .map(header -> header.substring(BEARER_PREFIX.length()))
                .orElseThrow(GraphQLAuthException::new);
    }
}
