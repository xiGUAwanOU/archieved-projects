package travel.blog.server.resolvers;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.List;

import travel.blog.server.exceptions.GraphQLEntityNotFoundException;
import travel.blog.server.models.Article;
import travel.blog.server.repositories.ArticleRepository;

@Component
public class QueryResolver implements GraphQLQueryResolver {
    private final ArticleRepository articleRepository;

    @Autowired
    public QueryResolver(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    public List<Article> articles() {
        return articleRepository.findAll(Sort.by(Article.Properties.DATE).descending());
    }

    public Article article(String id) {
        return articleRepository.findById(id).orElseThrow(() -> new GraphQLEntityNotFoundException("article", id));
    }
}
