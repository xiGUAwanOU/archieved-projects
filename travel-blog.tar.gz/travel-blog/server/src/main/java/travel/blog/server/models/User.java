package travel.blog.server.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class User {
    public static class Properties {
        public static final String ID = "id";
        public static final String USERNAME = "username";
        public static final String PASSWORD = "password";
        public static final String SECURE_PASSWORD = "securePassword";
    }

    @JsonProperty(Properties.ID)
    private final String id;

    @JsonProperty(Properties.USERNAME)
    private final String username;

    @JsonProperty(Properties.PASSWORD)
    private final String password;

    @JsonProperty(Properties.SECURE_PASSWORD)
    private final String securePassword;

    @JsonCreator
    public User(@JsonProperty(Properties.ID) String id, @JsonProperty(Properties.USERNAME) String username,
            @JsonProperty(Properties.PASSWORD) String password, @JsonProperty(Properties.SECURE_PASSWORD) String securePassword) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.securePassword = securePassword;
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getSecurePassword() {
        return securePassword;
    }
}
