package travel.blog.server.services;

import java.util.List;
import java.util.stream.Collectors;

import graphql.GraphQLError;
import graphql.servlet.DefaultGraphQLErrorHandler;
import travel.blog.server.models.JacksonFriendlyGraphQLError;

public class JacksonFriendlyGraphQLErrorHandler extends DefaultGraphQLErrorHandler {
    @Override
    public List<GraphQLError> processErrors(List<GraphQLError> errors) {
        return super.processErrors(errors).stream().map(JacksonFriendlyGraphQLError::new).collect(Collectors.toList());
    }
}
