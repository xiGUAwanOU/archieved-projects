package travel.blog.server.services;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Verification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import travel.blog.server.models.LoginResult;
import travel.blog.server.models.User;
import travel.blog.server.repositories.UserRepository;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final String serverSecret;
    private final long timeToLive;

    @Autowired
    public AuthService(UserRepository userRepository, @Value("${jwt.serverSecret}") String serverSecret,
            @Value("${jwt.timeToLive}") int timeToLive) {
        this.userRepository = userRepository;
        this.serverSecret = serverSecret;
        this.timeToLive = timeToLive;
    }

    public LoginResult login(User user) {
        List<User> storedUsers = userRepository.findByUsername(user.getUsername());

        if (storedUsers.size() != 1) {
            return LoginResult.failed();
        }

        if (!getSha1HashedBase64String(user.getPassword()).equals(storedUsers.get(0).getSecurePassword())) {
            return LoginResult.failed();
        }

        return LoginResult.ok(signJwt(user.getUsername()));
    }

    public boolean authorize(String jwt) {
        Optional<String> optionalUsername = verifyJwt(jwt);

        return optionalUsername.map(username -> !userRepository.findByUsername(username).isEmpty()).orElse(false);
    }

    private String signJwt(String username) {
        JWTCreator.Builder builder = JWT.create().withIssuer("travel-blog").withClaim("username", username);

        if (timeToLive != 0) {
            Date expiresAt = Date.from(Instant.now().plusSeconds(timeToLive));
            builder.withExpiresAt(expiresAt);
        }

        return builder.sign(getAlgorithm());
    }

    private Optional<String> verifyJwt(String jwt) {
        try {
            Verification verification = JWT.require(getAlgorithm()).withIssuer("travel-blog");

            if (timeToLive != 0) {
                verification.acceptExpiresAt(0);
            }

            return Optional.ofNullable(verification.build().verify(jwt).getClaim("username").asString());
        } catch (JWTVerificationException e) {
            return Optional.empty();
        }
    }

    private Algorithm getAlgorithm() {
        return Algorithm.HMAC256(serverSecret);
    }

    static String getSha1HashedBase64String(String original) {
        try {
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            sha1.update(original.getBytes(Charset.forName("UTF-8")));

            return Base64Utils.encodeToString(sha1.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Cannot find SHA-1 algorithm, which unexpected.");
        }
    }
}
