#!/usr/bin/env bash

./gradlew clean
./gradlew bootJar
tar czf travel-blog.tar.gz build/*
