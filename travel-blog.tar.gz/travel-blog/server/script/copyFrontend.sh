#!/usr/bin/env bash

rm -rf src/main/resources/public
mkdir src/main/resources/public
mkdir src/main/resources/public/admin
touch src/main/resources/public/.gitkeep
touch src/main/resources/public/admin/.gitkeep

cd ..

cd client
yarn build
cp -r dist/* ../server/src/main/resources/public
cd ..

cd admin
yarn build
cp -r dist/* ../server/src/main/resources/public/admin
cd ..
