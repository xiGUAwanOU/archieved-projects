#!/usr/bin/env bash
./gradlew clean bootRun --args='--spring.profiles.active=dev'