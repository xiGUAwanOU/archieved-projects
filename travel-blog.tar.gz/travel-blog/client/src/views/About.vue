<template>
  <div class="about">
    <h1>About</h1>
    <p>
      Welcome to our website Captain Bonbon. This page is filled up with the information about this website organized
      in an FAQ format.
    </p>

    <h3>What is this website for?</h3>
    <p>
      This is basically a place recording when and where we have been to, what we have seen and what we have
      expirenced, with some homebrew music.
    </p>

    <h3>Who are we?</h3>
    <p>
      We are two geeks, programmers, enthusiasts of travelling, nature and animal lovers. She is also a photographer,
      trying to take pictures for all the cute animals; while he is a hobby musician mainly playing guitars.
    </p>

    <h3>Who is Captain Bonbon?</h3>
    <p>
      Bonbon is the name of our pet, a Djungarian hamster. Bonbon cannot travel with us, because changing the
      environment will stress hamsters out. To take care of Bonbon while we are not at home, we built a feeding
      machine which can be controlled with our mobile phones when we are not at home. In our minds, Bonbon is like the
      captain who guides us to our destinations.
    </p>

    <h3>How do we travel?</h3>
    <p>
      We used to take trains to get around, but now we mainly travel by car (after we both have had the driving
      licenses). We also do a lot of hiking. In the night, we camp somewhere or stay in a small hotel. We tend to
      avoid big cities, because we prefer nature.
    </p>

    <h3>Best travel expirence?</h3>
    <p>
      We have expirenced an unforgettable night in the Hardangervidda, Norway. We planned to hike for 20 to 25
      kilometers in a day, which is usually OK for us. However, we had a big trouble to keep the speed, because there
      is barely road, only rocks, muds and streams. We set up our tent in a valley, since it was getting dark and we
      have no choice at that time.
    </p>
    <p>
      In the evening the wind started becoming stronger and stronger, totally out of our control. The tent was
      deformed in the strong wind, so we have to support our tent with our own body, and still the tent just seemed
      like about to be blown away. We stayed in the tent with scare for the whole night. Luckily the tent was sturdy
      enough, otherwise this website won't even exist.
    </p>
    <p>
      After years we can still remember the situation at that night. We definitely won't do that again, but we both
      have the opinion that this is our best travel expirence.
    </p>

    <hr/>

    <h1>关于</h1>
    <p>
      欢迎来到我们的小站——Captain Bonbon，这个页面以问答的形式介绍了一些与我们的小站有关的信息。
    </p>

    <h3>这个小站是用来干什么的？</h3>
    <p>
      大概就是一个我们用来记录我们什么时候去了哪里，看到了什么，以及做了什么的地方，并且还有一些自己写的小曲子作为背景音乐。
    </p>

    <h3>我们是谁？</h3>
    <p>
      我们是两个技术控、程序员、旅行爱好者、自然爱好者兼动物爱好者。她同时也是一个摄影爱好者，总是尝试给可爱的小动物们拍照。他是一个<!--
      -->业余音乐创作者，主要的乐器是吉他。
    </p>

    <h3>Bonbon船长是谁？</h3>
    <p>
      Bonbon是我们的宠物仓鼠的名字。因为频繁换环境会给仓鼠压力，所以我们不能带着Bonbon一起旅行。为此，我们做了一个手机控制的自动喂<!--
      -->食器，以便能在我们出门的时候照料Bonbon。在我们心中，Bonbon就像是一位能够引领我们到达旅行目的地的船长一样的存在。
    </p>

    <h3>我们怎么旅行呢？</h3>
    <p>
      以前我们经常坐火车，不过现在我们都有了驾照，所以基本上都是开车出门了。我们也经常在野外徒步。晚上的时候，我们一般是在某个地方搭<!--
      -->帐篷、或者是呆在一个小旅馆里面过夜。我们比较倾向于避开大城市，因为相比起大城市，我们还是更喜欢大自然的感觉。
    </p>

    <h3>最棒的旅行经历是什么？</h3>
    <p>
      我们在挪威的哈当厄尔高原体验了人生中最难忘的一次旅行。我们本来计划在一天之内徒步20到25公里左右的距离，一般情况下这样的距离对<!--
      -->我们来说不成问题，不过实际上我们的速度完全跟不上。因为那里几乎没有路，全是石头、烂泥和小溪。我们最后在一个山谷里面搭了帐篷，<!--
      -->这也是无奈之举，因为那时天色已经晚了。
    </p>
    <p>
      晚上的时候，风突然变大了，大到完全无法控制的程度。我们的帐篷都被强风吹变了形，所以我们必须用身体支撑住帐篷。即便是这样，帐篷也<!--
      -->是看起来要被强风吹飞的样子。我们就在恐惧中撑着帐篷在强风中过了一整夜。所幸帐篷够结实，不然的话也就没人去建这个小站了。
    </p>
    <p>
      几年之后我们仍会回忆起那个夜晚的情形。如果让我们再来一次，我们肯定不干，不过我们都认为那次的旅行经历绝对是目前为止最棒的一次了。
    </p>
  </div>
</template>

<style scoped>
h1 {
  color: var(--text-color-on-light-highlight);
  font-size: 3em;
  margin: 20px 0;
}
</style>
