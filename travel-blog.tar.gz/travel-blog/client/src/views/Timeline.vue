<template>
  <div class="timeline">
    <div class="timeline-top">
      <div>NOW</div>
      <svg version="1.1" baseProfile="full" width="9" height="30" xmlns="http://www.w3.org/2000/svg">
        <rect class="timeline-line" x="3" y1="0" width="4" height="100%"/>
      </svg>
    </div>

    <div class="timeline-yearly-items" v-for="year in sortedYears" :key="year">
      <div v-for="article in articlesByYear[year]" :key="article.id" class="timeline-item">
        <div class="timeline-item-line">
          <svg version="1.1" baseProfile="full" width="9" height="100%" xmlns="http://www.w3.org/2000/svg">
            <circle class="timeline-dot" cx="5" cy="10" r="4"/>
            <rect class="timeline-line" x="3" y="20" width="4" height="100%"/>
          </svg>
        </div>
        <router-link class="timeline-item-body" :to="{ name: 'articleView', params: { id: article.id } }">
          <svg class="timeline-item-body-tail"
              version="1.1" baseProfile="full" width="10" height="10" xmlns="http://www.w3.org/2000/svg">
            <polygon class="timeline-body-tail" points="0,0 10,0 10,10"/>
          </svg>
          <div class="timeline-item-body-content">
            <img class="timeline-item-body-thumbnail" :src="article.thumbnailImageUrl"/>
            <div class="timeline-item-body-text">
              <h2 class="timeline-item-title">{{ article.title }}</h2>
              <div class="timeline-item-place">{{ article.place.name }}</div>
              <div class="timeline-item-introduction">{{ article.introduction }}</div>
            </div>
            <div class="timeline-item-body-date">{{ article.date | date }}</div>
          </div>
        </router-link>
      </div>

      <div class="timeline-year">
        <div>{{ year }}</div>
        <svg version="1.1" baseProfile="full" width="9" height="20" xmlns="http://www.w3.org/2000/svg">
          <rect class="timeline-line" x="3" y1="0" width="4" height="100%"/>
        </svg>
      </div>
    </div>

    <div class="timeline-bottom">
      <svg version="1.1" baseProfile="full" width="9" height="200" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop class="gradient-stop-1" offset="10%"/>
            <stop class="gradient-stop-2" offset="100%"/>
          </linearGradient>
        </defs>
        <rect class="timeline-line-gradient" x="3" y="0" width="4" height="100%"/>
      </svg>
    </div>
  </div>
</template>

<script>
import moment from 'moment'

import ArticleService from '@/services/ArticleService'

export default {
  name: 'timeline',

  data() {
    return {
      articles: []
    }
  },

  computed: {
    articlesByYear() {
      let articlesByYear = {}
      this.articles.forEach(article => {
        let year = moment(article.date, 'YYYY-MM-DD').year()
        if (!articlesByYear[year]) {
          articlesByYear[year] = []
        }
        articlesByYear[year].push(article)
      })

      return articlesByYear
    },

    sortedYears() {
      return [...Object.keys(this.articlesByYear)].sort().reverse()
    }
  },

  created() {
    this.loadData()
  },

  methods: {
    async loadData() {
      this.articles = (await ArticleService.getAll()).data.data.articles
    }
  }
}
</script>

<style scoped>
.timeline {
  display: flex;
  flex-direction: column;
}

.timeline-item {
  display: flex;
}

.timeline-top, .timeline-year, .timeline-item-line, .timeline-bottom {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 48px;
  min-width: 48px;
}

.timeline-line {
  shape-rendering: crispEdges;
  fill: var(--background-color-dark);
}

.timeline-line-gradient {
  shape-rendering: crispEdges;
  fill: url(#gradient);
}

.gradient-stop-1 {
  stop-color: var(--background-color-dark);
}

.gradient-stop-2 {
  stop-color: transparent;
}

.timeline-dot {
  fill: var(--background-color-dark);
}

.timeline-item-body {
  flex-grow: 1;
  display: flex;
  margin: 10px 0 20px -10px;
  text-decoration: none;
  cursor: pointer;
}

.timeline-item-body-tail {
  flex: 0 0 10px;
}

.timeline-body-tail {
  fill: var(--background-color-dark);
}

.timeline-item-body-content {
  flex-grow: 1;
  display: flex;
  border-radius: 0 6px 6px 6px;
  overflow: hidden;
  background-color: var(--background-color-dark);
  color: var(--text-color-on-dark);
}

.timeline-item-body-thumbnail {
  flex: 0 0 250px;
  align-self: flex-start;
  width: 250px;
}

.timeline-item-body-text {
  flex-grow: 1;
  padding: 0.5em 1em;
}

.timeline-item-title {
  margin: 0 0 12px 0;
}

.timeline-item-place {
  margin: 12px 0;
}

.timeline-item-body-date {
  padding: 1em 0.2em;
  background-color: var(--background-color-contrast);
  writing-mode: vertical-rl;
}

@media all and (max-width: 700px) {
  .timeline-item-body-content {
    flex-direction: column;
    margin-right: 20px;
  }

  .timeline-item-body-thumbnail {
    flex: auto;
    width: 100%;
  }

  .timeline-item-body-text {
    padding: 0.5em 0.5em;
  }

  .timeline-item-body-date {
    padding: 0.2em 1em;
    writing-mode: horizontal-tb;
  }
}

.timeline-item:hover .timeline-dot {
  fill: var(--background-color-contrast);
}

.timeline-item:hover .timeline-body-tail {
  fill: var(--background-color-dark-highlight);
}

.timeline-item:hover .timeline-item-body-content {
  background-color: var(--background-color-dark-highlight);
}

.timeline-item:hover .timeline-item-body-thumbnail {
  filter: brightness(1.1);
}
</style>
