<template>
  <div v-if="article" class="article-view">
    <h1 class="article-title">{{ article.title }}</h1>
    <div class="article-metadata">{{ article.date | date }} @ {{ article.place.name }}</div>
    <div class="article-content" :inner-html.prop="renderedContent"/>
  </div>
</template>

<script>
import marked from 'marked'

import ArticleService from '@/services/ArticleService'

export default {
  name: 'articleView',

  props: {
    id: { type: String, required: true }
  },

  data() {
    return {
      article: null
    }
  },

  computed: {
    renderedContent() {
      return this.render(this.article.content)
    }
  },

  created() {
    this.loadData()
  },

  methods: {
    async loadData() {
      this.article = (await ArticleService.getById(this.id)).data.data.article
    },

    render(markdown) {
      if (!markdown) {
        return ''
      }

      let renderer = new marked.Renderer()

      renderer.image = (href, title, text) => {
        return `
        <div class="article-photo-card">
          <img class="article-photo-card-image" src="${href}" alt="${text}"/>
          <div class="article-photo-card-text">${text}</div>
        </div>
        `
      }

      return marked(markdown, { renderer })
    }
  }
}
</script>

<style scoped>
.article-title {
  color: var(--text-color-on-light-highlight);
  font-size: 3em;
  margin: 20px 0;
}

.article-metadata {
  color: var(--text-color-on-light-highlight);
  margin: 20px 0 40px 0;
}

.article-content >>> .article-photo-card {
  margin: 10px auto;
  text-align: center;
}

.article-content >>> .article-photo-card-image {
  display: block;
  position: relative;
  margin: 0 auto;
  max-width: 640px;
  max-height: 640px;
  width: auto;
  height: auto;
}

.article-content >>> .article-photo-card-text {
  padding: 8px;
  font-size: 0.8em;
  color: var(--text-color-on-light-weak);
}
</style>
