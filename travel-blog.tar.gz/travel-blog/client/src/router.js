import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'timeline',
      component: () => import(/* webpackChunkName: "timeline" */ '@/views/Timeline')
    },
    {
      path: '/about',
      name: 'about',
      component: () => import(/* webpackChunkName: "about" */ '@/views/About')
    },
    {
      path: '/article/:id',
      name: 'articleView',
      props: true,
      component: () => import(/* webpackChunkName: "articleView" */ '@/views/ArticleView')
    }
  ],
  scrollBehavior(to, from, savedPosition) {
    return to.hash ? { selector: to.hash, offset: { x: 0, y: 15 } } : { x: 0, y: 0 }
  }
})
