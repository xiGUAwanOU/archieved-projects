<template>
  <div class="main-menu">
    <router-link class="main-menu-nav-link" :to="{ name: 'timeline' }">Timeline</router-link>
    <router-link class="main-menu-nav-link" :to="{ name: 'about' }">About</router-link>
  </div>
</template>

<style scoped>
.main-menu {
  display: flex;
  justify-content: flex-end;
}

.main-menu-nav-link {
  display: block;
  margin-left: 3px;
  padding: 0.2em 0.7em 0.05em 0.7em;
  background-color: var(--background-color-dark);
  color: var(--text-color-on-dark);
  text-decoration: none;
  border-bottom: 3px solid transparent;
  border-radius: 0 0 6px 6px;
}

.main-menu-nav-link:hover, .main-menu-nav-link:active{
  background-color: var(--background-color-dark-highlight);
  color: var(--text-color-on-dark);
  border-bottom: 3px solid var(--text-color-on-dark-highlight);
}
</style>
