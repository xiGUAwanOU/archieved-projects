<template>
  <div class="page-header">
    <span class="page-header-site-title">Captain</span>
    <div class="page-header-site-logo-mask">
      <img class="page-header-site-logo" :src="require('@/assets/logo.png')" alt="Site logo"/>
    </div>
    <span class="page-header-site-title">Bonbon</span>
  </div>
</template>

<style scoped>
.page-header {
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.page-header-site-title {
  font-size: 40px;
  font-weight: bold;
}

.page-header-site-logo-mask {
  display: inline-block;
  min-width: 100px;
  width: 100px;
  height: 80px;
  margin: 0 20px;
  overflow-y: hidden;
  cursor: pointer;
}

.page-header-site-logo {
  position: relative;
  top: 0;
  width: 100%;
  transition: 2s cubic-bezier(.57,.75,.99,-0.18) 2s;
}

.page-header-site-logo-mask:hover .page-header-site-logo {
  top: 55px;
  transition: 0.15s;
}

@media all and (max-width: 500px) {
  .page-header {
    justify-content: flex-start;
  }

  .page-header-site-title {
    display: none;
  }
}
</style>
