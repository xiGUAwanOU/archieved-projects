import GraphQLService from '@/services/GraphQLService'

const GET_ALL_QUERY = `query {
  articles {
    id
    title
    date
    place {
      name
      latitude
      longitude
    }
    introduction
    thumbnailImageUrl
  }
}`

const GET_BY_ID_QUERY = `query($id: ID!) {
  article(id: $id) {
    id
    title
    date
    place {
      name
      latitude
      longitude
    }
    content
    musicPlayer
  }
}`

class ArticleService extends GraphQLService {
  getAll() {
    return this.query(GET_ALL_QUERY)
  }

  getById(id) {
    return this.query(GET_BY_ID_QUERY, { id })
  }
}

export default new ArticleService()
