import axios from 'axios'

export default class GraphQLService {
  query(query, variables) {
    let formData = new FormData()
    formData.set('query', query)
    if (variables) {
      formData.set('variables', JSON.stringify(variables))
    }

    return axios({
      method: 'post',
      url: '/api/graphql',
      timeout: 5000,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: formData
    })
  }
}
