<template>
  <div id="app">
    <page-header/>
    <hr/>
    <main-menu/>
    <div class="page-content">
      <router-view/>
    </div>
    <button class="top-button" @click="toTop">Top</button>
  </div>
</template>

<script>
import PageHeader from '@/components/PageHeader'
import MainMenu from '@/components/MainMenu'

export default {
  components: {
    PageHeader,
    MainMenu
  },
  methods: {
    toTop() {
      window.scrollTo(0, 0)
    }
  }
}
</script>

<style>
@import './assets/colors.css';
@import './assets/fonts.css';

body {
  min-width: 300px;
  background-color: var(--background-color-light);
  color: var(--text-color-on-light);
  font-family: var(--text-font-family);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

hr {
  margin: 0;
  border: 0;
  height: 1px;
  background: var(--background-color-dark);
}

a, a:link, a:visited {
  color: var(--text-color-on-light-highlight);
  text-decoration: none;
}
a:hover, a:active {
  color: var(--text-color-on-light-highlight);
  text-decoration: underline;
}
</style>

<style scoped>
#app {
  max-width: 900px;
  margin: 0 auto;
}

.page-content {
  margin: 3em 0 20em 0;
}

.top-button {
  position: fixed;
  bottom: -1px;
  left: calc(50vw - 25px);
  width: 50px;
  padding: 3px 0 5px 0;
  background-color: var(--background-color-dark);
  color: var(--text-color-on-dark);
  font-size: 0.7em;
  text-decoration: none;
  border: 0;
  border-top: 3px solid transparent;
  border-radius: 6px 6px 0 0;
  outline: none;
  cursor: pointer;
}

.top-button:hover, .top-button:active{
  background-color: var(--background-color-dark-highlight);
  color: var(--text-color-on-dark);
  border-top: 3px solid var(--text-color-on-dark-highlight);
}
</style>
