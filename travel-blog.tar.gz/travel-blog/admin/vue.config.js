module.exports = {
  baseUrl: '/admin/',
  devServer: {
    port: 8081,
    proxy: {
      '/api': {
        target: 'http://localhost:9000'
      }
    }
  }
}
