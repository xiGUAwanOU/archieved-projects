<template>
  <div class="breadcrumb">
    <el-row>
      <el-col :span="24">
        <div class="box breadcrumb-container">
          <el-breadcrumb separator="/">
            <el-breadcrumb-item v-for="definition in definitions" :key="definition.name" :to="definition.routerTarget">
              {{definition.name}}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  props: {
    definitions: { type: Array, required: true }
  }
}
</script>

<style scoped>
.breadcrumb-container {
  background-color: #eee;
}
</style>
