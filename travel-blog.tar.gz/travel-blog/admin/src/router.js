import Vue from 'vue'
import Router from 'vue-router'
import ArticleEditor from '@/views/ArticleEditor'
import ArticleList from '@/views/ArticleList'
import Login from '@/views/Login'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'login',
      component: Login
    }, {
      path: '/list',
      name: 'articleList',
      component: ArticleList
    }, {
      path: '/create',
      name: 'createArticle',
      component: ArticleEditor
    }, {
      path: '/edit/:id',
      name: 'editArticle',
      props: true,
      component: ArticleEditor
    }
  ]
})
