import axios from 'axios'

const JWT_LOCAL_STORAGE_KEY = 'jwt'

class AuthService {
  constructor() {
    this.recover()
  }

  isLoggedIn() {
    return this.jwt !== null
  }

  recover() {
    this.jwt = readJwtFromLocalStorage()
    setAuthHeader(this.jwt)
  }

  async login(username, password) {
    try {
      this.jwt = (await loginQuery(username, password)).data.jwt
      setAuthHeader(this.jwt)
      storeJwtToLocalStorage(this.jwt)
    } catch (error) {
      this.logout()
      throw error
    }
  }

  logout() {
    this.jwt = null
    unsetAuthHeader()
    clearJwtInLocalStorage()
  }
}

async function loginQuery(username, password) {
  return axios({
    method: 'post',
    url: '/api/login',
    timeout: 5000,
    data: { username, password }
  })
}

function setAuthHeader(jwt) {
  axios.defaults.headers.common['Authorization'] = 'Bearer ' + jwt
}

function unsetAuthHeader() {
  delete axios.defaults.headers.common['Authorization']
}

function storeJwtToLocalStorage(jwt) {
  localStorage.setItem(JWT_LOCAL_STORAGE_KEY, jwt)
}

function readJwtFromLocalStorage() {
  return localStorage.getItem(JWT_LOCAL_STORAGE_KEY)
}

function clearJwtInLocalStorage() {
  localStorage.removeItem(JWT_LOCAL_STORAGE_KEY)
}

export default new AuthService()
