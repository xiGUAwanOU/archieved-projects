import GraphQLService from '@/services/GraphQLService'

const GET_ALL_QUERY = `query {
  articles {
    id
    title
    date
  }
}`

const GET_BY_ID_QUERY = `query($id: ID!) {
  article(id: $id) {
    id
    title
    date
    place {
      name
      latitude
      longitude
    }
    introduction
    content
    thumbnailImageUrl
    musicPlayer
  }
}`

const CREATE_QUERY = `mutation($article: ArticleInput!) {
  createArticle(articleInput: $article) { id }
}`

const UPDATE_QUERY = `mutation($id: ID!, $article: ArticleInput!) {
  updateArticle(id: $id, articleInput: $article) { id }
}`

const DELETE_QUERY = `mutation($id: ID!) {
  deleteArticle(id: $id)
}`

class ArticleService extends GraphQLService {
  getAll() {
    return this.query(GET_ALL_QUERY)
  }

  getById(id) {
    return this.query(GET_BY_ID_QUERY, { id })
  }

  create(article) {
    return this.query(CREATE_QUERY, { article })
  }

  update(id, article) {
    return this.query(UPDATE_QUERY, { id, article })
  }

  delete(id) {
    return this.query(DELETE_QUERY, { id })
  }
}

export default new ArticleService()
