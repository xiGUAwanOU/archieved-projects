<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
body {
  margin: 0;
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.box {
  margin: 0.4em 0;
  padding: 0.75em 1.25em;
  border-radius: 4px;
}

.input-box {
  margin: 1em 0;
  border-radius: 4px;
}

.input-box > label {
  display: block;
  font-weight: bold;
}

.input-box div {
  margin: 0.2em 0;
}

.action-button {
  display: inline-block;
  margin: 0 0.2em;
  color: #409eff;
  text-decoration: none;
  cursor: pointer;
}
</style>

<style scoped>
#app {
  max-width: 900px;
  min-height: 100vh;
  margin: 0 auto;
  padding: 1em;
}
</style>
