<template>
  <div class="article-editor">
    <breadcrumb :definitions="breadcrumbDefinitions"/>

    <div class="input-box">
      <label>Title</label>
      <el-input placeholder="Title" v-model="article.title"/>
    </div>

    <div class="input-box">
      <label>Date</label>
      <el-date-picker placeholder="Date" v-model="article.date" type="date" value-format="yyyy-MM-dd"/>
    </div>

    <div class="input-box">
      <label>Place</label>
      <el-input placeholder="Name" v-model="article.place.name"/>
      <el-row :gutter="5">
        <el-col :xs="24" :sm="12">
          <el-input type="number" placeholder="Latitude (N, S)" v-model.number="article.place.latitude"
              :min="-90.0" :max="90.0"/>
        </el-col>
        <el-col :xs="24" :sm="12">
          <el-input type="number" placeholder="Longitude (E, W)" v-model.number="article.place.longitude"
              :min="-180.0" :max="180.0"/>
        </el-col>
      </el-row>
    </div>

    <div class="input-box">
      <label>Introduction</label>
      <el-input placeholder="Introduction" v-model="article.introduction"/>
    </div>

    <div class="input-box">
      <label>Thumbnail URL</label>
      <el-input placeholder="Thumbnail URL" v-model="article.thumbnailImageUrl"/>
    </div>

    <div class="input-box">
      <label>Music Player HTML Code</label>
      <el-input type="textarea" :rows="5"  placeholder="Music Player" v-model="article.musicPlayer"/>
    </div>

    <div class="input-box">
      <label>Content</label>
      <el-input type="textarea" :rows="15" placeholder="Content" v-model="article.content"/>
    </div>

    <el-button @click="cancel">Cancel</el-button>
    <el-button type="primary" @click="createOrUpdate">Save</el-button>

    <div class="input-box">
      <label>Debug</label>
      <pre class="article-editor-debug-json">{{ article }}</pre>
    </div>
  </div>
</template>

<script>
import ArticleService from '@/services/ArticleService'

import Breadcrumb from '@/components/Breadcrumb'

export default {
  components: {
    Breadcrumb
  },

  props: {
    id: { type: String }
  },

  data() {
    return {
      article: {
        title: '',
        date: '',
        place: { name: '', latitude: '', longitude: '' },
        introduction: '',
        thumbnailImageUrl: '',
        musicPlayer: '',
        content: ''
      }
    }
  },

  computed: {
    isEditing() {
      return this.id
    },

    breadcrumbDefinitions() {
      return [
        {
          name: 'Articles List',
          routerTarget: { name: 'articleList' }
        }, {
          name: `${this.isEditing ? 'Edit' : 'Create'} Article`
        }
      ]
    }
  },

  created() {
    if (this.isEditing) {
      this.loadData()
    }
  },

  methods: {
    async loadData() {
      this.article = (await ArticleService.getById(this.id)).data.data.article
      delete this.article.id
    },

    async createOrUpdate() {
      if (this.isEditing) {
        await ArticleService.update(this.id, this.article)
        this.$router.push({ name: 'articleList' })
      } else {
        await ArticleService.create(this.article)
        this.$router.push({ name: 'articleList' })
      }
    },

    cancel() {
      this.$router.push({ name: 'articleList' })
    }
  }
}
</script>

<style scoped>
.article-editor-debug-json {
  border-radius: 4px;
  padding: 1em;
  background-color: #eee;
  font-family: "Lucida Console", Monaco, monospace;
  font-size: 12px;
}
</style>
