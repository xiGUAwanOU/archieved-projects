<template>
  <div class="login">
    <breadcrumb :definitions="[{ name: 'Login' }]"/>

    <div v-if="failed" class="input-box">
      <span class="login-error-message">Login failed! Please try again.</span>
    </div>

    <form>
      <div class="input-box">
        <label>Username</label>
        <el-input placeholder="Username" @keyup.enter.native="login" v-model="username"/>
      </div>

      <div class="input-box">
        <label>Password</label>
        <el-input type="password" placeholder="Password" @keyup.enter.native="login" v-model="password"/>
      </div>

      <el-button type="primary" @click="login">Login</el-button>
    </form>
  </div>
</template>

<script>
import AuthService from '@/services/AuthService'

import Breadcrumb from '@/components/Breadcrumb'

export default {
  components: {
    Breadcrumb
  },

  data() {
    return {
      username: '',
      password: '',
      failed: false
    }
  },

  created() {
    if (AuthService.isLoggedIn()) {
      this.$router.push({ name: 'articleList' })
    }
  },

  methods: {
    async login() {
      try {
        await AuthService.login(this.username, this.password)
        this.$router.push({ name: 'articleList' })
      } catch (error) {
        this.failed = true
      }
    }
  }
}
</script>

<style scoped>
.login-error-message {
  color: red;
}
</style>
