<template>
  <div class="article-list">
    <breadcrumb :definitions="[{ name: 'Article List' }]"/>

    <div class="input-box">
      <el-button type="primary" icon="el-icon-plus" @click="createArticle">Create</el-button>
    </div>
    <el-table :data="articles" empty-text="No Article">
      <el-table-column width="100" prop="date" label="Date"/>
      <el-table-column prop="title" label="Title"/>
      <el-table-column width="80" label="Actions">
        <template slot-scope="scope">
          <router-link :to="{ name: 'editArticle', params: { id: scope.row.id } }" class="el-icon-edit action-button"/>
          <i @click="deleteArticle(scope.row.id)" class="el-icon-delete action-button"/>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import ArticleService from '@/services/ArticleService'
import AuthService from '@/services/AuthService'

import Breadcrumb from '@/components/Breadcrumb'

export default {
  components: {
    Breadcrumb
  },

  data() {
    return {
      articles: []
    }
  },

  created() {
    if (!AuthService.isLoggedIn()) {
      this.$router.push({ name: 'login' })
    }

    this.loadData()
  },

  methods: {
    async loadData() {
      this.articles = (await ArticleService.getAll()).data.data.articles
    },

    createArticle() {
      this.$router.push({ name: 'createArticle' })
    },

    async deleteArticle(id) {
      await ArticleService.delete(id)
      this.loadData()
    }
  }
}
</script>

<style scoped>

</style>
