import Vue from 'vue'
import Element from 'element-ui'
import App from '@/App.vue'
import axios from 'axios'
import router from '@/router'
import AuthService from '@/services/AuthService'

import 'element-ui/lib/theme-chalk/index.css'

Vue.use(Element)

Vue.config.productionTip = false

axios.interceptors.response.use((response) => {
  if (response.data.errors && response.data.errors.some(error => error.message.includes('Operation is not authorized'))) {
    AuthService.logout()
  }
  return response
}, (error) => {
  if (error.response.statusCode === 403) {
    AuthService.logout()
  }
  return Promise.reject(error)
})

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
