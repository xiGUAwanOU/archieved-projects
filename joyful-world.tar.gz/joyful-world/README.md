# Joyful World
Previously a research branch of [Joyful Utilites](https://github.com/xiGUAwanOU/joyful-utilities). Now a separated project.  Implemented actor model with respect to the natural law.
