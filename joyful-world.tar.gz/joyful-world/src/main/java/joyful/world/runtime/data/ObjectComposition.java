package joyful.world.runtime.data;

import java.util.HashMap;
import java.util.Map;

public class ObjectComposition {
    private final Map<String, Object> objects = new HashMap<>();

    public <T> void set(String key, T object) {
        objects.put(key, object);
    }

    public <T> T get(String key, Class<T> valueClass) {
        return valueClass.cast(objects.get(key));
    }
}
