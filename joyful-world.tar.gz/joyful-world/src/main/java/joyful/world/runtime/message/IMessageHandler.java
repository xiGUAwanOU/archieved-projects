package joyful.world.runtime.message;

public interface IMessageHandler<M extends IMessage> {

    void handle(M message);

    Class<M> getMessageClass();

}
