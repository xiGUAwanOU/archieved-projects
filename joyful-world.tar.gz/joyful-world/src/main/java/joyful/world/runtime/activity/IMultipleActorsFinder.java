package joyful.world.runtime.activity;

import java.util.List;

import joyful.world.runtime.actor.Actor;

public interface IMultipleActorsFinder extends IFinder {
    void callback(List<Actor> actors);
}
