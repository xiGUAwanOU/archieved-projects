package joyful.world.runtime.actor;

import java.util.Set;

import joyful.world.runtime.activity.IAction;
import joyful.world.runtime.activity.IMultipleActorsFinder;
import joyful.world.runtime.activity.INotification;
import joyful.world.runtime.activity.ISingleActorFinder;

public interface IWorldInteractor {
    void spawnActor(Actor actor);

    void destroyActor(Actor actor);

    void findOne(ISingleActorFinder finder);

    void findAll(IMultipleActorsFinder finder);

    void sendNotification(ActorId source, Set<ActorId> targets, INotification notification);

    void sendAction(ActorId source, Set<ActorId> targets, IAction action);
}
