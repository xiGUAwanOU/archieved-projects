package joyful.world.runtime.message;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MessageQueue {
    private final Queue<IMessage> messageQueue = new ConcurrentLinkedQueue<>();

    public void enqueue(IMessage message) {
        messageQueue.add(message);
    }

    public List<IMessage> dequeueAll() {
        List<IMessage> messages = new ArrayList<>(messageQueue);
        messageQueue.removeAll(messages);

        return messages;
    }
}
