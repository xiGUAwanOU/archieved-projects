package joyful.world.runtime.message;

public interface IMessage {
}
