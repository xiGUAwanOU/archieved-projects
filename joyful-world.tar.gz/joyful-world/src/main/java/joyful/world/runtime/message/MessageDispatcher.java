package joyful.world.runtime.message;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class MessageDispatcher {
    private final Map<Class<? extends IMessage>, List<WeakReference<IMessageHandler<? extends IMessage>>>> messageHandlers =
            new HashMap<>();

    public void registerHandler(IMessageHandler<? extends IMessage> messageHandler) {
        Class<? extends IMessage> messageClass = messageHandler.getMessageClass();

        if (!messageHandlers.containsKey(messageClass)) {
            messageHandlers.put(messageClass, new LinkedList<>());
        }

        messageHandlers.get(messageClass).add(new WeakReference<>(messageHandler));
    }

    public void unregisterHandler(IMessageHandler<? extends IMessage> messageHandler) {
        Class<? extends IMessage> messageClass = messageHandler.getMessageClass();

        if (!messageHandlers.containsKey(messageClass)) {
            return;
        }

        messageHandlers.put(messageClass, messageHandlers.get(messageClass)
                .stream()
                .filter(messageHandlerWeakReference -> Objects.nonNull(messageHandlerWeakReference.get()))
                .filter(messageHandlerWeakReference -> !messageHandlerWeakReference.get().equals(messageHandler))
                .collect(Collectors.toList()));
    }

    public <M extends IMessage> void dispatch(M message) {
        Class<? extends IMessage> messageClass = message.getClass();

        messageHandlers.keySet()
                .stream()
                .filter(handleableClass -> handleableClass.isAssignableFrom(messageClass))
                .forEach(handleableClass -> invokeMessageHandlers(handleableClass, message));
    }

    @SuppressWarnings("unchecked")
    private <M extends IMessage> void invokeMessageHandlers(Class<? extends IMessage> messageClass, M message) {
        messageHandlers.put(messageClass, messageHandlers.get(messageClass)
                .stream()
                .filter(messageHandlerWeakReference -> Objects.nonNull(messageHandlerWeakReference.get()))
                .peek(messageHandlerWeakReference -> ((IMessageHandler<M>) messageHandlerWeakReference.get()).handle(message))
                .collect(Collectors.toList()));
    }
}
