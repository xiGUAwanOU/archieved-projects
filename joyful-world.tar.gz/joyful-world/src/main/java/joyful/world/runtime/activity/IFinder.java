package joyful.world.runtime.activity;

import joyful.world.runtime.actor.Actor;

public interface IFinder {
    boolean test(Actor actor);
}
