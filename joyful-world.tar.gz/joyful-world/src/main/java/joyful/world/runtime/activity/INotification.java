package joyful.world.runtime.activity;

import joyful.world.runtime.message.IMessage;

public interface INotification extends IMessage {
}
