package joyful.world.runtime.actor;

import java.util.UUID;

public class ActorId {
    private final UUID value;

    public ActorId() {
        this.value = UUID.randomUUID();
    }

    @Override
    public String toString() {
        return value.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ActorId actorId = (ActorId) o;

        return value.equals(actorId.value);
    }

    @Override
    public int hashCode() {
        return value.hashCode();
    }
}
