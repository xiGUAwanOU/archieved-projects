package joyful.world.runtime.blueprint;

import joyful.world.runtime.actor.Actor;

public interface IBlueprint<T extends Actor> {
    T build();
}
