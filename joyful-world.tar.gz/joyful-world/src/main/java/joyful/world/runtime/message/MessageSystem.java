package joyful.world.runtime.message;

public class MessageSystem {
    private final MessageQueue messageQueue = new MessageQueue();
    private final MessageDispatcher messageDispatcher = new MessageDispatcher();

    public void registerHandler(IMessageHandler<? extends IMessage> messageHandler) {
        messageDispatcher.registerHandler(messageHandler);
    }

    public void unregisterHandler(IMessageHandler<? extends IMessage> messageHandler) {
        messageDispatcher.unregisterHandler(messageHandler);
    }

    public void broadcast(IMessage message) {
        messageQueue.enqueue(message);
    }

    public void processAll() {
        messageQueue.dequeueAll().forEach(messageDispatcher::dispatch);
    }
}
