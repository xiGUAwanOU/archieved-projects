package joyful.world.runtime.actor;

import joyful.world.runtime.activity.IAction;
import joyful.world.runtime.activity.IMultipleActorsFinder;
import joyful.world.runtime.activity.INotification;
import joyful.world.runtime.data.ObjectComposition;
import joyful.world.runtime.message.IMessageHandler;
import joyful.world.runtime.message.MessageDispatcher;

public abstract class Actor {
    private final ActorId id;

    private final ObjectComposition privateComponents = new ObjectComposition();
    private final ObjectComposition protectedComponents = new ObjectComposition();
    private final ObjectComposition publicComponents = new ObjectComposition();

    private final MessageDispatcher notificationDispatcher = new MessageDispatcher();

    protected final IWorldInteractor worldInteractor;

    public Actor(IWorldInteractor worldInteractor) {
        this(new ActorId(), worldInteractor);
    }

    public Actor(ActorId id, IWorldInteractor worldInteractor) {
        this.id = id;
        this.worldInteractor = worldInteractor;
    }

    public abstract void setUp();

    public abstract void loop(long loopTimeMillis);

    public abstract void tearDown();

    public ActorId getId() {
        return id;
    }

    public <T> T getPrivateComponent(String key, Class<T> valueClass) {
        return privateComponents.get(key, valueClass);
    }

    public <T> T getProtectedComponent(String key, Class<T> valueClass) {
        return protectedComponents.get(key, valueClass);
    }

    public <T> T getPublicComponent(String key, Class<T> valueClass) {
        return publicComponents.get(key, valueClass);
    }

    public void setPrivateComponents(String key, Object value) {
        privateComponents.set(key, value);
    }

    public void setProtectedComponents(String key, Object value) {
        privateComponents.set(key, value);
    }

    public void setPublicComponents(String key, Object value) {
        privateComponents.set(key, value);
    }

    public void registerNotificationHandler(IMessageHandler<? extends INotification> notificationDispatcher) {
        this.notificationDispatcher.registerHandler(notificationDispatcher);
    }

    public void acceptNotification(INotification notification) {
        notificationDispatcher.dispatch(notification);
    }

    public boolean acceptFinder(IMultipleActorsFinder finder) {
        return finder.test(this);
    }

    public void acceptAction(IAction action) {
        action.applyToTarget(this);
    }
}
