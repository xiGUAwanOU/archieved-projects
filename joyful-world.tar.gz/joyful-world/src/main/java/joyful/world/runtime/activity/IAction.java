package joyful.world.runtime.activity;

import joyful.world.runtime.actor.Actor;

public interface IAction {
    void applyToSource(Actor actor);

    void applyToTarget(Actor actor);
}
