package joyful.world.runtime.message;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.ref.WeakReference;

import static org.assertj.core.api.Assertions.assertThat;

class MessageDispatcherTest {
    private MessageDispatcher messageDispatcher;
    private MessageHandlerMock messageHandlerMock;
    private AnotherMessageHandlerMock anotherMessageHandlerMock;

    @BeforeEach
    void setUp() {
        messageDispatcher = new MessageDispatcher();
        messageHandlerMock = new MessageHandlerMock();
        anotherMessageHandlerMock = new AnotherMessageHandlerMock();

        messageDispatcher.registerHandler(messageHandlerMock);
        messageDispatcher.registerHandler(anotherMessageHandlerMock);
    }

    @Test
    void registerHandler_WithReferencesToHandlerRemoved_DoesNotPreventGc() throws Exception {
        WeakReference<AnotherMessageHandlerMock> weakReference = new WeakReference<>(anotherMessageHandlerMock);

        assertThat(weakReference.get()).isNotNull();

        anotherMessageHandlerMock = null;

        System.gc();
        Thread.sleep(100);

        assertThat(weakReference.get()).isNull();
    }

    @Test
    void unregisterHandler_HandlerDoesNotReceiveDispatchedMessage() {
        messageDispatcher.unregisterHandler(anotherMessageHandlerMock);
        messageDispatcher.dispatch(new AnotherMessageMock(42));

        Assertions.assertThat(anotherMessageHandlerMock.getHandledMessages()).isEmpty();
    }

    @Test
    void dispatch_WithDifferentTypes_HandlerReceivesDispatchedMessage() {
        messageDispatcher.dispatch(new MessageMock("whatever"));
        messageDispatcher.dispatch(new AnotherMessageMock(42));

        Assertions.assertThat(messageHandlerMock.getHandledMessages()).extracting(MessageMock::getPayload).containsExactly("whatever");
        Assertions.assertThat(anotherMessageHandlerMock.getHandledMessages()).extracting(AnotherMessageMock::getPayload).containsExactly(42);
    }

    @Test
    void dispatch_WithSubMessageType_HandlerReceivesDispatchedMessage() {
        messageDispatcher.dispatch(new SubMessageMock("whatever"));

        Assertions.assertThat(messageHandlerMock.getHandledMessages()).extracting(MessageMock::getPayload).containsExactly("whatever");
        assertThat(messageHandlerMock.getHandledMessages().get(0)).isExactlyInstanceOf(SubMessageMock.class);
    }
}