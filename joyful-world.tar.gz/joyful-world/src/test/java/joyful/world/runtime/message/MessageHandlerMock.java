package joyful.world.runtime.message;

import java.util.ArrayList;
import java.util.List;

public class MessageHandlerMock implements IMessageHandler<MessageMock> {
    private final List<MessageMock> handledMessages = new ArrayList<>();

    @Override
    public void handle(MessageMock message) {
        handledMessages.add(message);
    }

    @Override
    public Class<MessageMock> getMessageClass() {
        return MessageMock.class;
    }

    public List<MessageMock> getHandledMessages() {
        return handledMessages;
    }
}
