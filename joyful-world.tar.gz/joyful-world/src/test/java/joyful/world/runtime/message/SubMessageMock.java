package joyful.world.runtime.message;

public class SubMessageMock extends MessageMock {
    public SubMessageMock(String payload) {
        super(payload);
    }
}
