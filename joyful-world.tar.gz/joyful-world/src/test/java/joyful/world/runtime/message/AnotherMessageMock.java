package joyful.world.runtime.message;

public class AnotherMessageMock implements IMessage {
    private final int payload;

    public AnotherMessageMock(int payload) {
        this.payload = payload;
    }

    public int getPayload() {
        return payload;
    }
}
