package joyful.world.runtime.message;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MessageQueueTest {
    private MessageQueue messageQueue;

    @BeforeEach
    void setUp() {
        messageQueue = new MessageQueue();
    }

    @Test
    void dequeueAll_QueueIsEmpty_ReturnEmptyListWithoutBlocking() {
        Assertions.assertThat(messageQueue.dequeueAll()).isEmpty();
    }

    @Test
    void dequeueAll_QueueIsNotEmpty_ReturnMessagesAndClearQueue() {
        messageQueue.enqueue(new MessageMock("doesn't matter"));

        Assertions.assertThat(messageQueue.dequeueAll()).hasOnlyOneElementSatisfying(
                message -> assertThat(message).isExactlyInstanceOf(MessageMock.class));
        Assertions.assertThat(messageQueue.dequeueAll()).isEmpty();
    }
}