package joyful.world.runtime.actor;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ActorIdTest {
    @Test
    void constructor_AlwaysCreateWithDifferentUuid() {
        assertThat(new ActorId()).isNotEqualTo(new ActorId());
    }

    @Test
    void constructor_AlwaysCreateWithDifferentHashCode() {
        assertThat(new ActorId().hashCode()).isNotEqualTo(new ActorId().hashCode());
    }
}