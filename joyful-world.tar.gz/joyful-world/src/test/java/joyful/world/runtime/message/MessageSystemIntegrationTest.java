package joyful.world.runtime.message;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MessageSystemIntegrationTest {
    private MessageHandlerMock messageHandlerMock;
    private AnotherMessageHandlerMock anotherMessageHandlerMock;
    private MessageGeneratingMessageHandlerMock messageGeneratingMessageHandlerMock;

    private MessageSystem messageSystem;

    @BeforeEach
    void setUp() {
        messageSystem = new MessageSystem();

        messageHandlerMock = new MessageHandlerMock();
        anotherMessageHandlerMock = new AnotherMessageHandlerMock();
        messageGeneratingMessageHandlerMock = new MessageGeneratingMessageHandlerMock(messageSystem);
    }

    @Test
    void processAllMessages_WithMessageHandlerRegistered_DispatchAllMessagesToTheCorrespondingHandler() {
        messageSystem.registerHandler(messageHandlerMock);
        messageSystem.registerHandler(anotherMessageHandlerMock);
        messageSystem.broadcast(new MessageMock("whatever"));
        messageSystem.broadcast(new AnotherMessageMock(42));

        messageSystem.processAll();

        assertThat(messageHandlerMock.getHandledMessages()).extracting(MessageMock::getPayload).containsExactly("whatever");
        Assertions.assertThat(anotherMessageHandlerMock.getHandledMessages()).extracting(AnotherMessageMock::getPayload).containsExactly(42);
    }

    @Test
    void processAllMessages_WithMessageHandlerUnregistered_DoesNotDispatchMessageToUnregisteredHandler() {
        messageSystem.registerHandler(messageHandlerMock);
        messageSystem.unregisterHandler(messageHandlerMock);
        messageSystem.broadcast(new MessageMock("whatever"));

        messageSystem.processAll();

        assertThat(messageHandlerMock.getHandledMessages()).isEmpty();
    }

    @Test
    void processAllMessages_MessageHandlerGeneratesNewMessage_OnlyProcessAllMessagesAddedBeforeProcessing() {
        messageSystem.registerHandler(messageGeneratingMessageHandlerMock);
        messageSystem.broadcast(new MessageMock("whatever"));

        messageSystem.processAll();

        assertThat(messageGeneratingMessageHandlerMock.getHandledMessages()).hasSize(1)
                .extracting(MessageMock::getPayload)
                .containsExactly("whatever");
    }
}