package joyful.world.runtime.data;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ObjectCompositionTest {
    @Test
    void addAndGetObjects_ReturnsTheExpectedObject() {
        ObjectComposition objectComposition = new ObjectComposition();
        objectComposition.set("someField", "Hello world!");
        objectComposition.set("someOtherField", 42);

        assertThat(objectComposition.get("someField", String.class)).isEqualTo("Hello world!");
        assertThat(objectComposition.get("someOtherField", Integer.class)).isEqualTo(42);
    }
}
