package joyful.world.runtime.message;

public class MessageMock implements IMessage {
    private final String payload;

    public MessageMock(String payload) {
        this.payload = payload;
    }

    public String getPayload() {
        return payload;
    }
}
