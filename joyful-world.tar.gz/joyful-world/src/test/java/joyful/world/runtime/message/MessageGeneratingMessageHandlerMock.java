package joyful.world.runtime.message;

import java.util.ArrayList;
import java.util.List;

public class MessageGeneratingMessageHandlerMock implements IMessageHandler<MessageMock> {
    private final List<MessageMock> handledMessages = new ArrayList<>();
    private final MessageSystem messageSystem;

    public MessageGeneratingMessageHandlerMock(MessageSystem messageSystem) {
        this.messageSystem = messageSystem;
    }

    @Override
    public void handle(MessageMock message) {
        handledMessages.add(message);
        messageSystem.broadcast(message);
    }

    @Override
    public Class<MessageMock> getMessageClass() {
        return MessageMock.class;
    }

    public List<MessageMock> getHandledMessages() {
        return handledMessages;
    }
}
