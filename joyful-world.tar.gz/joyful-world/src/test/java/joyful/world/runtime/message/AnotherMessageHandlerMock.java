package joyful.world.runtime.message;

import java.util.ArrayList;
import java.util.List;

public class AnotherMessageHandlerMock implements IMessageHandler<AnotherMessageMock> {
    private final List<AnotherMessageMock> handledMessages = new ArrayList<>();

    @Override
    public void handle(AnotherMessageMock message) {
        handledMessages.add(message);
    }

    @Override
    public Class<AnotherMessageMock> getMessageClass() {
        return AnotherMessageMock.class;
    }

    public List<AnotherMessageMock> getHandledMessages() {
        return handledMessages;
    }
}
