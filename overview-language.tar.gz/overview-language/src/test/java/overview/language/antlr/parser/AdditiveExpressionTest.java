package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class AdditiveExpressionTest {
    private static final Function<OverviewParser, ParseTree> ADDITIVE_EXPRESSION = OverviewParser::additiveExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.additiveExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.additiveExpression().getChild(2);

    @Test
    void parseAdditiveExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1+2", ADDITIVE_EXPRESSION)).containsSubsequence("integerLiteral 1", "+",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 - 2", ADDITIVE_EXPRESSION)).containsSubsequence("integerLiteral 1", "-",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 + 2 - 3", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", "+",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 + 2 - 3", SECOND_OPERAND)).containsSubsequence("integerLiteral 3");
    }

    @Test
    void parseAdditiveExpression_ValidInput_HasLowerPrecedenceThanMultiplicativeExpressions() {
        assertThat(ParserTestHelper.parseToAstString("1 + 2 * 3", SECOND_OPERAND)).containsSubsequence("multiplicativeExpression",
                "integerLiteral 2", "*", "integerLiteral 3");
    }
}
