package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class BitwiseAndExpressionTest {
    private static final Function<OverviewParser, ParseTree> BITWISE_AND_EXPRESSION = OverviewParser::bitwiseAndExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.bitwiseAndExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.bitwiseAndExpression().getChild(2);

    @Test
    void parseBitwiseAndExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1&2", BITWISE_AND_EXPRESSION)).containsSubsequence("integerLiteral 1", "&",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 & 2", BITWISE_AND_EXPRESSION)).containsSubsequence("integerLiteral 1", "&",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 & 2 & 3", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", "&",
                "integerLiteral 2");
    }

    @Test
    void parseBitwiseAndExpression_ValidInput_HasLowerPrecedenceThanEqualityExpressions() {
        assertThat(ParserTestHelper.parseToAstString("true & 1 == 2", SECOND_OPERAND)).containsSubsequence("integerLiteral 1", "==",
                "integerLiteral 2");
    }
}
