package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class BitwiseOrExpressionTest {
    private static final Function<OverviewParser, ParseTree> BITWISE_OR_EXPRESSION = OverviewParser::bitwiseOrExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.bitwiseOrExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.bitwiseOrExpression().getChild(2);

    @Test
    void parseBitwiseOrExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1|2", BITWISE_OR_EXPRESSION)).containsSubsequence("integerLiteral 1", "|",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 | 2", BITWISE_OR_EXPRESSION)).containsSubsequence("integerLiteral 1", "|",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 | 2 | 3", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", "|",
                "integerLiteral 2");
    }

    @Test
    void parseBitwiseOrExpression_ValidInput_HasLowerPrecedenceThanBitwiseXorExpressions() {
        assertThat(ParserTestHelper.parseToAstString("1 | 2 ^ 3", SECOND_OPERAND)).containsSubsequence("integerLiteral 2", "^",
                "integerLiteral 3");
    }
}
