package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class ComparisonExpression {
    private static final Function<OverviewParser, ParseTree> COMPARISON_EXPRESSION = OverviewParser::comparisonExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.comparisonExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.comparisonExpression().getChild(2);

    @Test
    void parseComparisonExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1 > 2", COMPARISON_EXPRESSION)).containsSubsequence("integerLiteral 1", ">",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 < 2", COMPARISON_EXPRESSION)).containsSubsequence("integerLiteral 1", "<",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1>=2", COMPARISON_EXPRESSION)).containsSubsequence("integerLiteral 1", ">=",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1<=2", COMPARISON_EXPRESSION)).containsSubsequence("integerLiteral 1", "<=",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("false < true < true", FIRST_OPERAND)).containsSubsequence("booleanLiteral false", "<",
                "booleanLiteral true");
        assertThat(ParserTestHelper.parseToAstString("false < true < true", SECOND_OPERAND)).containsSubsequence("booleanLiteral true");
    }

    @Test
    void parseComparisonExpression_ValidInput_HasLowerPrecedenceThanShiftExpressions() {
        assertThat(ParserTestHelper.parseToAstString("16 > 1 << 2", SECOND_OPERAND)).containsSubsequence("integerLiteral 1", "<<",
                "integerLiteral 2");
    }
}
