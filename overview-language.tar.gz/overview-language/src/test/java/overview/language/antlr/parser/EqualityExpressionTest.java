package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class EqualityExpressionTest {
    private static final Function<OverviewParser, ParseTree> EQUALITY_EXPRESSION = OverviewParser::equalityExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.equalityExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.equalityExpression().getChild(2);

    @Test
    void parseEqualityExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1==2", EQUALITY_EXPRESSION)).containsSubsequence("integerLiteral 1", "==",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 != 2", EQUALITY_EXPRESSION)).containsSubsequence("integerLiteral 1", "!=",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 is 2", EQUALITY_EXPRESSION)).containsSubsequence("integerLiteral 1", "is",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 == 2 == false", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", "==",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 == 2 == false", SECOND_OPERAND)).containsSubsequence("booleanLiteral false");
    }

    @Test
    void parseEqualityExpression_ValidInput_HasLowerPrecedenceThanComparisonExpressions() {
        assertThat(ParserTestHelper.parseToAstString("true == 1 < 2", SECOND_OPERAND)).containsSubsequence("integerLiteral 1", "<",
                "integerLiteral 2");
    }
}
