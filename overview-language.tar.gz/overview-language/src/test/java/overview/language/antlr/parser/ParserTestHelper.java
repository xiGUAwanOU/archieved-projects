package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;
import overview.language.antlr.lexer.LexerTestHelper;

class ParserTestHelper {
    public static String parseToAstString(String sourceCode, Function<OverviewParser, ParseTree> parseTreeExtractor) {
        OverviewParser parser = new OverviewParser(LexerTestHelper.parseToTokenStream(sourceCode));
        return parseTreeExtractor.apply(parser).toStringTree(parser);
    }
}
