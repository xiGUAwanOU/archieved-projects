package overview.language.antlr.lexer;

import org.antlr.v4.runtime.ANTLRErrorListener;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.Parser;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.Recognizer;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenSource;
import org.antlr.v4.runtime.atn.ATNConfigSet;
import org.antlr.v4.runtime.dfa.DFA;

import java.util.BitSet;
import java.util.List;
import java.util.stream.Collectors;

import overview.language.antlr.OverviewLexer;

public class LexerTestHelper {
    public static List<Integer> parseToTokenTypes(String sourceCode) {
        return parseToTokens(sourceCode).stream().map(Token::getType).collect(Collectors.toList());
    }

    public static List<Token> parseToTokens(String sourceCode) {
        return parseToTokenStream(sourceCode).getTokens()
                .stream()
                .filter(token -> OverviewLexer.EOF != token.getType())
                .collect(Collectors.toList());
    }

    public static CommonTokenStream parseToTokenStream(String sourceCode) {
        OverviewLexer lexer = new OverviewLexer(CharStreams.fromString(sourceCode));
        lexer.addErrorListener(new ParseErrorListenerForTest());
        return new TokenDrainingTokenStream(lexer);
    }

    public static class LexerError extends RuntimeException {
        public LexerError(String message) {
            super(message);
        }
    }

    private static class TokenDrainingTokenStream extends CommonTokenStream {
        private static final int DEFAULT_FETCHING_NUMBER = 100;

        private TokenDrainingTokenStream(TokenSource tokenSource) {
            super(tokenSource);
        }

        @Override
        public List<Token> getTokens() {
            // Have to drain tokens before return tokens.
            // Don't know why the original author of ANTLR4 has provided a getTokens() method without fetching any tokens.
            drainTokens();
            return super.getTokens();
        }

        private void drainTokens() {
            int numOfFetchedTokens;
            do {
                numOfFetchedTokens = fetch(DEFAULT_FETCHING_NUMBER);
            } while (numOfFetchedTokens == DEFAULT_FETCHING_NUMBER);
        }
    }

    private static class ParseErrorListenerForTest implements ANTLRErrorListener {
        @Override
        public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg,
                RecognitionException e) {
            throw new LexerError(msg);
        }

        @Override
        public void reportAmbiguity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts,
                ATNConfigSet configs) {
            throw new UnsupportedOperationException("This method is not yet implemented");
        }

        @Override
        public void reportAttemptingFullContext(Parser recognizer, DFA dfa, int startIndex, int stopIndex, BitSet conflictingAlts,
                ATNConfigSet configs) {
            throw new UnsupportedOperationException("This method is not yet implemented");
        }

        @Override
        public void reportContextSensitivity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, int prediction,
                ATNConfigSet configs) {
            throw new UnsupportedOperationException("This method is not yet implemented");
        }
    }
}
