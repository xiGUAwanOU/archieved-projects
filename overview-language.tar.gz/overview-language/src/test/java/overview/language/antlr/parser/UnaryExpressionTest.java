package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class UnaryExpressionTest {
    private static final Function<OverviewParser, ParseTree> UNARY_EXPRESSION = OverviewParser::unaryExpression;
    private static final Function<OverviewParser, ParseTree> OPERAND = parser -> parser.unaryExpression().getChild(1);

    @Test
    void parseUnaryExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("+1", UNARY_EXPRESSION)).containsSubsequence("+", "integerLiteral 1");
        assertThat(ParserTestHelper.parseToAstString("- 1", UNARY_EXPRESSION)).containsSubsequence("-", "integerLiteral 1");
        assertThat(ParserTestHelper.parseToAstString("~ 1", UNARY_EXPRESSION)).containsSubsequence("~", "integerLiteral 1");

        assertThat(ParserTestHelper.parseToAstString("+-1", OPERAND)).containsSubsequence("-", "integerLiteral 1");
    }
}
