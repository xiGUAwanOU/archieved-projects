package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class BitwiseXorExpressionTest {
    private static final Function<OverviewParser, ParseTree> BITWISE_XOR_EXPRESSION = OverviewParser::bitwiseXorExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.bitwiseXorExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.bitwiseXorExpression().getChild(2);

    @Test
    void parseBitwiseXorExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1^2", BITWISE_XOR_EXPRESSION)).containsSubsequence("integerLiteral 1", "^",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 ^ 2", BITWISE_XOR_EXPRESSION)).containsSubsequence("integerLiteral 1", "^",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 ^ 2 ^ 3", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", "^",
                "integerLiteral 2");
    }

    @Test
    void parseBitwiseXorExpression_ValidInput_HasLowerPrecedenceThanBitwiseAndExpressions() {
        assertThat(ParserTestHelper.parseToAstString("1 ^ 2 & 3", SECOND_OPERAND)).containsSubsequence("integerLiteral 2", "&",
                "integerLiteral 3");
    }
}
