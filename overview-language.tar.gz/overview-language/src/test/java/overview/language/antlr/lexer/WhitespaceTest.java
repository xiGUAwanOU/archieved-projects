package overview.language.antlr.lexer;

import org.junit.jupiter.api.Test;

import overview.language.antlr.OverviewLexer;

import static org.assertj.core.api.Assertions.assertThat;

public class WhitespaceTest {
    @Test
    void parseWhitespace_AllKindsOfWhitespaceAreIgnored() {
        assertThat(LexerTestHelper.parseToTokenTypes("null\ntrue\tfalse\r\n42\r0xFF 0o7777  0b11111111")).containsExactly(
                OverviewLexer.NULL_LITERAL, OverviewLexer.TRUE_LITERAL, OverviewLexer.FALSE_LITERAL, OverviewLexer.DEC_INTEGER_LITERAL,
                OverviewLexer.HEX_INTEGER_LITERAL, OverviewLexer.OCT_INTEGER_LITERAL, OverviewLexer.BIN_INTEGER_LITERAL);
    }
}
