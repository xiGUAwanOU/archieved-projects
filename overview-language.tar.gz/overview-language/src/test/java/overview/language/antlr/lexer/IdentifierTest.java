package overview.language.antlr.lexer;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import overview.language.antlr.OverviewLexer;

import static org.assertj.core.api.Assertions.assertThat;

class IdentifierTest {
    @Test
    void parseIdentifier_ValidInput_ReturnsCorrectTokenType() {
        Assertions.assertThat(LexerTestHelper.parseToTokenTypes("_").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
        assertThat(LexerTestHelper.parseToTokenTypes("a").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
        assertThat(LexerTestHelper.parseToTokenTypes("_a").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
        assertThat(LexerTestHelper.parseToTokenTypes("a0").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
        assertThat(LexerTestHelper.parseToTokenTypes("FooBar").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
        assertThat(LexerTestHelper.parseToTokenTypes("fooBar").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
        assertThat(LexerTestHelper.parseToTokenTypes("foo_bar").get(0)).isEqualTo(OverviewLexer.IDENTIFIER);
    }
}
