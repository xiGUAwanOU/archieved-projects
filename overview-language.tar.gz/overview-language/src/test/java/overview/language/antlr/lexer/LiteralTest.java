package overview.language.antlr.lexer;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import overview.language.antlr.OverviewLexer;

import static org.assertj.core.api.Assertions.assertThat;

class LiteralTest {
    @Test
    void parseNullLiteral_ValidInput_ReturnsCorrectTokenType() {
        Assertions.assertThat(LexerTestHelper.parseToTokenTypes("null").get(0)).isEqualTo(OverviewLexer.NULL_LITERAL);
    }

    @Test
    void parseBooleanLiteral_ValidInput_ReturnsCorrectTokenType() {
        assertThat(LexerTestHelper.parseToTokenTypes("true").get(0)).isEqualTo(OverviewLexer.TRUE_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("false").get(0)).isEqualTo(OverviewLexer.FALSE_LITERAL);
    }

    @Test
    void parseIntegerLiteral_ValidInput_ReturnsCorrectTokenType() {
        assertThat(LexerTestHelper.parseToTokenTypes("0").get(0)).isEqualTo(OverviewLexer.DEC_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("123456789").get(0)).isEqualTo(OverviewLexer.DEC_INTEGER_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes("0b0").get(0)).isEqualTo(OverviewLexer.BIN_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0b1").get(0)).isEqualTo(OverviewLexer.BIN_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0b0010").get(0)).isEqualTo(OverviewLexer.BIN_INTEGER_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes("0o0").get(0)).isEqualTo(OverviewLexer.OCT_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0o1234567").get(0)).isEqualTo(OverviewLexer.OCT_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0o0777").get(0)).isEqualTo(OverviewLexer.OCT_INTEGER_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes("0x0").get(0)).isEqualTo(OverviewLexer.HEX_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0x123456789").get(0)).isEqualTo(OverviewLexer.HEX_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0xAaBbCcDdEeFf").get(0)).isEqualTo(OverviewLexer.HEX_INTEGER_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0x0Bad").get(0)).isEqualTo(OverviewLexer.HEX_INTEGER_LITERAL);
    }

    @Test
    void parseFloatLiteral_ValidInput_ReturnsCorrectTokenType() {
        assertThat(LexerTestHelper.parseToTokenTypes("99.99").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("099.99").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("990.99").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("99.099").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("99.990").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0.99").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("00.99").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("99.0").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("99.00").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes("99.").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("099.").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("990.").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0.").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("00.").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes(".99").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(".099").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(".990").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(".0").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(".00").get(0)).isEqualTo(OverviewLexer.PLAIN_FLOAT_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes("3.0e+11").get(0)).isEqualTo(OverviewLexer.EXPONENT_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("3.e-11").get(0)).isEqualTo(OverviewLexer.EXPONENT_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(".3e011").get(0)).isEqualTo(OverviewLexer.EXPONENT_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("3e110").get(0)).isEqualTo(OverviewLexer.EXPONENT_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0e0").get(0)).isEqualTo(OverviewLexer.EXPONENT_FLOAT_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes("0e00").get(0)).isEqualTo(OverviewLexer.EXPONENT_FLOAT_LITERAL);
    }

    @Test
    void parseStringLiteral_ValidInput_ReturnsCorrectTokenType() {
        assertThat(LexerTestHelper.parseToTokenTypes(quote("")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(quote("hello  world")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
        assertThat(LexerTestHelper.parseToTokens(quote("hello  world")).get(0).getText()).contains("hello  world");

        assertThat(LexerTestHelper.parseToTokenTypes(quote("foo\\\\bar")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(quote("foo\\\"bar\\\"")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(quote("foo\\tbar")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(quote("foo\\rbar")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
        assertThat(LexerTestHelper.parseToTokenTypes(quote("foo\\nbar")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes(quote("\\x{00B0}")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);

        assertThat(LexerTestHelper.parseToTokenTypes(quote("中文字符 ÄäÖöÜüß")).get(0)).isEqualTo(OverviewLexer.STRING_LITERAL);
    }

    private String quote(String originalString) {
        return "\"" + originalString + "\"";
    }
}