package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class MultiplicativeExpressionTest {
    private static final Function<OverviewParser, ParseTree> MULTIPLICATIVE_EXPRESSION = OverviewParser::multiplicativeExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.multiplicativeExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.multiplicativeExpression().getChild(2);

    @Test
    void parseMultiplicativeExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1*2", MULTIPLICATIVE_EXPRESSION)).containsSubsequence("integerLiteral 1", "*",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 / 2", MULTIPLICATIVE_EXPRESSION)).containsSubsequence("integerLiteral 1", "/",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 % 2", MULTIPLICATIVE_EXPRESSION)).containsSubsequence("integerLiteral 1", "%",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 * 2 / 3", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", "*",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 * 2 / 3", SECOND_OPERAND)).containsSubsequence("integerLiteral 3");
    }

    @Test
    void parseMultiplicativeExpression_ValidInput_HasLowerPrecedenceThanUnaryExpressions() {
        assertThat(ParserTestHelper.parseToAstString("1 * -2", SECOND_OPERAND)).containsSubsequence("unaryExpression", "-",
                "integerLiteral 2");
    }
}
