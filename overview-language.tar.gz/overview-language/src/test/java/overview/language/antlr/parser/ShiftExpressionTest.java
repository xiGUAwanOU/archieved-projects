package overview.language.antlr.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.jupiter.api.Test;

import java.util.function.Function;

import overview.language.antlr.OverviewParser;

import static org.assertj.core.api.Assertions.assertThat;

class ShiftExpressionTest {
    private static final Function<OverviewParser, ParseTree> SHIFT_EXPRESSION = OverviewParser::shiftExpression;
    private static final Function<OverviewParser, ParseTree> FIRST_OPERAND = parser -> parser.shiftExpression().getChild(0);
    private static final Function<OverviewParser, ParseTree> SECOND_OPERAND = parser -> parser.shiftExpression().getChild(2);

    @Test
    void parseShiftExpression_ValidInput_GenerateCorrectAst() {
        assertThat(ParserTestHelper.parseToAstString("1<<2", SHIFT_EXPRESSION)).containsSubsequence("integerLiteral 1", "<<",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 >> 2", SHIFT_EXPRESSION)).containsSubsequence("integerLiteral 1", ">>",
                "integerLiteral 2");

        assertThat(ParserTestHelper.parseToAstString("1 >> 2 << 3", FIRST_OPERAND)).containsSubsequence("integerLiteral 1", ">>",
                "integerLiteral 2");
        assertThat(ParserTestHelper.parseToAstString("1 << 2 >> 3", SECOND_OPERAND)).containsSubsequence("integerLiteral 3");
    }

    @Test
    void parseShiftExpression_ValidInput_HasLowerPrecedenceThanAdditiveExpressions() {
        assertThat(ParserTestHelper.parseToAstString("128 >> 1 + 2", SECOND_OPERAND)).containsSubsequence("integerLiteral 1", "+",
                "integerLiteral 2");
    }
}
