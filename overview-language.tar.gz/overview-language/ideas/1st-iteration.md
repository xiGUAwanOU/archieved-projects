# 1st Iteration
Be able to parse the following grammar features

## State transferring and decision logic
Pure business logic, cannot store any shared states.
* [ ] Basic calculations
  * [ ] Operator expressions
  * [ ] Array access
  * [ ] Field access
  * [ ] Method invocation
* [ ] `if (<cond>) { ... } elseif (<cond>) { ... } else { ... }` conditions
* [ ] `for (<var> in <list>) { ... }` loops
* [ ] `while (<cond>) { ... }` loops
* [ ] Functions
* [ ] Function receivers (for something similar to object-oriented language)

## Data structures and distributed data storage
* [ ] Primitive types: `Integer`, `Float`, `Boolean`, `String`, `List`, `Map`, `Null`
* [x] Literal types: `Integer`, `Float`, `Boolean`, `String`, `Null`
* [ ] Compounded type: `structure`
* [ ] Optional types: suffixed with `?`

## Actor definition
* [ ] Keyword: `actor`
* [ ] Fields (attributes): `private`, `public`
* [ ] Entry: `main(...) {...}`
* [ ] Accepting action: `accept Action1, Action2 from Actor1, Actor2`

## Action definition
* [ ] Keyword: `action`
* [ ] Update attributes of source actor and target actor

## Error handling
* [ ] `try { ... } catch (<errortype> as <error>) { ... } finally { ... }`

## Typing system
Some typing system features
* [ ] Static typed
* [ ] Keep the runtime type information (for polymorphism)

-------

# For Next Iteration
* namespace: kicked out from this iteration, because not sure if we need a dedicated namespace. Actually `system`, `entity` and `structure` are natural namespaces.
