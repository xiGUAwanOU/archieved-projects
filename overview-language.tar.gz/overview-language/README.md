# Overview Language
A programming language project which emphasised the concurrency and the relationship between different components in an application.
